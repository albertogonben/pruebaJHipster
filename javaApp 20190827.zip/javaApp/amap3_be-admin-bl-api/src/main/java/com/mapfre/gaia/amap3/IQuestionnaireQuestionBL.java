package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IQuestionnaireQuestionBL {

	/**
	 * Get all questionnaire question
	 */
	List<QuestionnaireQuestionBO> getAll();
	
	/**
	 * Add a questionnaire question
	 */
	QuestionnaireQuestionBO add(QuestionnaireQuestionBO questionnaireQuestionBo);

	/**
	 * Update a questionnaire question
	 */
	QuestionnaireQuestionBO update(Long questionnaireQuestionId, QuestionnaireQuestionBO questionnaireQuestionBo);

    /**
     * Delete a questionnaire question
     */
    boolean delete(Long questionnaireQuestionId);

}
