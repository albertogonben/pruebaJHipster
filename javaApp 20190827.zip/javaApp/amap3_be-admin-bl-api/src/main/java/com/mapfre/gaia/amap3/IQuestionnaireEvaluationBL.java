package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IQuestionnaireEvaluationBL {

	/**
	 * Get all questionnaire evaluation
	 */
	List<QuestionnaireEvaluationBO> getAll();
	
	/**
	 * Add a questionnaire evaluation
	 */
	QuestionnaireEvaluationBO add(QuestionnaireEvaluationBO questionnaireEvaluationBo);

	/**
	 * Update a questionnaire evaluation
	 */
	QuestionnaireEvaluationBO update(Long questionnaireEvaluationId, QuestionnaireEvaluationBO questionnaireEvaluationBo);

    /**
     * Delete a questionnaire evaluation
     */
    boolean delete(Long questionnaireEvaluationId);

}
