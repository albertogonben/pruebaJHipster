package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IOrganizationalStructureCountryBL {

	/**
	 * Get all organizational structure country
	 */
	List<OrganizationalStructureCountryBO> getAll();
	
	/**
	 * Add a organizational structure country
	 */
	OrganizationalStructureCountryBO add(OrganizationalStructureCountryBO organizationalStructureCountryBo);

	/**
	 * Update a organizational structure country
	 */
	OrganizationalStructureCountryBO update(Long organizationalStructureCountryId, OrganizationalStructureCountryBO organizationalStructureCountryBo);

    /**
     * Delete a organizational structure country
     */
    boolean delete(Long organizationalStructureCountryId);

}
