package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IImputationTimeBL {

	/**
	 * Get all imputation time
	 */
	List<ImputationTimeBO> getAll();
	
	/**
	 * Add a imputation time
	 */
	ImputationTimeBO add(ImputationTimeBO imputationTimeBo);

	/**
	 * Update a imputation time
	 */
	ImputationTimeBO update(Long imputationTimeId, ImputationTimeBO imputationTimeBo);

    /**
     * Delete a imputation time
     */
    boolean delete(Long imputationTimeId);

}
