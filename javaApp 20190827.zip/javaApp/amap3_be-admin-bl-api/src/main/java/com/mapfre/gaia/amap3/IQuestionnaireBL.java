package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IQuestionnaireBL {

	/**
	 * Get all questionnaire
	 */
	List<QuestionnaireBO> getAll();
	
	/**
	 * Add a questionnaire
	 */
	QuestionnaireBO add(QuestionnaireBO questionnaireBo);

	/**
	 * Update a questionnaire
	 */
	QuestionnaireBO update(Long questionnaireId, QuestionnaireBO questionnaireBo);

    /**
     * Delete a questionnaire
     */
    boolean delete(Long questionnaireId);

}
