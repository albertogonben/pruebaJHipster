package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ICurrencyBL {
    
    /**
     * Get all currencies
     * @return
     */
    List<CurrencyBO> getlAll();
    
    /**
     * Creation of a currency
     * @param input
     * @return
     */
    CurrencyBO save(CurrencyBO input);
    
    /**
     * Update of a currency
     * @param id
     * @param input
     * @return
     */
    CurrencyBO update(Long currencyId, CurrencyBO input);
    
    /**
     * Delete a currency
     */
    boolean delete(Long currencyId);
}
