package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IQuestionBL {

	/**
	 * Get all question
	 */
	List<QuestionBO> getAll();
	
	/**
	 * Add a question
	 */
	QuestionBO add(QuestionBO questionBo);

	/**
	 * Update a question
	 */
	QuestionBO update(Long questionId, QuestionBO questionBo);

    /**
     * Delete a question
     */
    boolean delete(Long questionId);

}
