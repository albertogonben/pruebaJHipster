package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.OrganizationalStructureCountry;
import com.mapfre.gaia.amap3.repositories.OrganizationalStructureCountryRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class OrganizationalStructureCountryBLImpl implements IOrganizationalStructureCountryBL {

	private OrganizationalStructureCountryRepository organizationalStructureCountryRepository;
	private MapperFacade mapperOrganizationalStructureCountry;

	@Autowired
	public OrganizationalStructureCountryBLImpl(OrganizationalStructureCountryRepository organizationalStructureCountryRepository) {
		this.organizationalStructureCountryRepository = organizationalStructureCountryRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		mapperFactory.classMap(OrganizationalStructureCountry.class, OrganizationalStructureCountryBO.class).byDefault().register();
		this.mapperOrganizationalStructureCountry = mapperFactory.getMapperFacade();

	}

	@Override
	public List<OrganizationalStructureCountryBO> getAll() {
		log.debug("OrganizationalStructureCountryBLImpl:getAll [START]");
		
		List<OrganizationalStructureCountryBO> organizationalStructureCountrys = new ArrayList<OrganizationalStructureCountryBO>();

		List<OrganizationalStructureCountry> organizationalStructureCountryEntities = organizationalStructureCountryRepository.findAll();
		for (OrganizationalStructureCountry organizationalStructureCountryEntity : organizationalStructureCountryEntities) {
			organizationalStructureCountrys.add(mapperOrganizationalStructureCountry.map(organizationalStructureCountryEntity, OrganizationalStructureCountryBO.class));
		}
		log.debug("OrganizationalStructureCountryBLImpl:getAll [END]");
		return organizationalStructureCountrys;
	}

	//TODO No necesario
	@Override
	public OrganizationalStructureCountryBO add(OrganizationalStructureCountryBO organizationalStructureCountryBO) {
		log.debug("OrganizationalStructureCountryBLImpl:add [START]");
		OrganizationalStructureCountry organizationalStructureCountryEntity = mapperOrganizationalStructureCountry.map(organizationalStructureCountryBO, OrganizationalStructureCountry.class);

		Util.getDateUser(organizationalStructureCountryEntity, "INSERT");

		log.debug("OrganizationalStructureCountryBLImpl:add [END]");
		return mapperOrganizationalStructureCountry.map(organizationalStructureCountryRepository.save(organizationalStructureCountryEntity), OrganizationalStructureCountryBO.class);
	}

	@Override
	public OrganizationalStructureCountryBO update(Long organizationalStructureCountryId, OrganizationalStructureCountryBO organizationalStructureCountryBO) {
		log.debug("OrganizationalStructureCountryBLImpl:update [START]");
		OrganizationalStructureCountry organizationalStructureCountryEntity = organizationalStructureCountryRepository.getOne(organizationalStructureCountryId);
				
		if (organizationalStructureCountryEntity != null) {

			Util.getDateUser(organizationalStructureCountryEntity, "UPDATE");
			
			log.debug("OrganizationalStructureCountryBLImpl:update [END]");
			return mapperOrganizationalStructureCountry.map(organizationalStructureCountryRepository.save(organizationalStructureCountryEntity), OrganizationalStructureCountryBO.class);
		}

		return null;
	}

	//TODO No necesario
	@Override
	public boolean delete(Long organizationalStructureCountryId) {
		log.debug("OrganizationalStructureCountryBLImpl:delete [START]");
		OrganizationalStructureCountry organizationalStructureCountryEntity = organizationalStructureCountryRepository.getOne(organizationalStructureCountryId);
		if (organizationalStructureCountryEntity != null) {
			
			organizationalStructureCountryRepository.delete(organizationalStructureCountryEntity);
			
			log.debug("OrganizationalStructureCountryBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
