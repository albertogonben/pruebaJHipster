package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.TypeChange;
import com.mapfre.gaia.amap3.mapper.StringDateMapper;
import com.mapfre.gaia.amap3.repositories.TypeChangeRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.ConverterFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class TypeChangeBLImpl implements ITypeChangeBL {

	private TypeChangeRepository typeChangeRepository;
	private MapperFacade mapperTypeChange;

	@Autowired
	public TypeChangeBLImpl(TypeChangeRepository typeChangeRepository) {
		this.typeChangeRepository = typeChangeRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		ConverterFactory converterFactory = mapperFactory.getConverterFactory();
		converterFactory.registerConverter("StringDateMapper", new StringDateMapper());
		
		mapperFactory.classMap(TypeChange.class, TypeChangeBO.class).fieldMap("dateChange", "dateChange")
		.converter("StringDateMapper").add().byDefault().register();
		this.mapperTypeChange = mapperFactory.getMapperFacade();

	}

	@Override
	public List<TypeChangeBO> getAll() {
		log.debug("TypeChangeBLImpl:getAll [START]");
		
		List<TypeChangeBO> typeChanges = new ArrayList<TypeChangeBO>();

		List<TypeChange> typeChangeEntities = typeChangeRepository.findAll();
		for (TypeChange typeChangeEntity : typeChangeEntities) {
			typeChanges.add(mapperTypeChange.map(typeChangeEntity, TypeChangeBO.class));
		}
		log.debug("TypeChangeBLImpl:getAll [END]");
		return typeChanges;
	}

	@Override
	public TypeChangeBO add(TypeChangeBO typeChangeBO) {
		log.debug("TypeChangeBLImpl:add [START]");
		TypeChange typeChangeEntity = mapperTypeChange.map(typeChangeBO, TypeChange.class);

		Util.getDateUser(typeChangeEntity, "INSERT");

		log.debug("TypeChangeBLImpl:add [END]");
		return mapperTypeChange.map(typeChangeRepository.save(typeChangeEntity), TypeChangeBO.class);
	}

	@Override
	public TypeChangeBO update(Long typeChangeId, TypeChangeBO typeChangeBO) {
		log.debug("TypeChangeBLImpl:update [START]");
		TypeChange typeChangeEntity = typeChangeRepository.getOne(typeChangeId);
				
		TypeChange typeChangeAux = mapperTypeChange.map(typeChangeBO, TypeChange.class);
		
		if (typeChangeEntity != null) {

			typeChangeEntity.setCodTypeChange(typeChangeAux.getCodTypeChange());
			typeChangeEntity.setDateChange(typeChangeAux.getDateChange());
			typeChangeEntity.setCurrency(typeChangeAux.getCurrency());
			typeChangeEntity.setMrkActive(typeChangeAux.getMrkActive());
			typeChangeEntity.setNrmChange(typeChangeAux.getNrmChange());
			
			Util.getDateUser(typeChangeEntity, "UPDATE");
			
			log.debug("TypeChangeBLImpl:update [END]");
			return mapperTypeChange.map(typeChangeRepository.save(typeChangeEntity), TypeChangeBO.class);
		}

		return null;
	}

	//TODO No necesario
	@Override
	public boolean delete(Long typeChangeId) {
		log.debug("TypeChangeBLImpl:delete [START]");
		TypeChange typeChangeEntity = typeChangeRepository.getOne(typeChangeId);
		if (typeChangeEntity != null) {
			
			typeChangeEntity.setMrkActive(new BigDecimal(0));
			Util.getDateUser(typeChangeEntity, "UPDATE");
			typeChangeRepository.save(typeChangeEntity);
			
//			typeChangeRepository.delete(typeChangeEntity);
			
			log.debug("TypeChangeBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
