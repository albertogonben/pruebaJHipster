package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.EntamapUnitBusiness;
import com.mapfre.gaia.amap3.repositories.EntamapUnitBusinessRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class EntamapUnitBusinessBLImpl implements IEntamapUnitBusinessBL {

	private EntamapUnitBusinessRepository typeConceptImpRepository;
	private MapperFacade mapperEntamapUnitBusiness;

	@Autowired
	public EntamapUnitBusinessBLImpl(EntamapUnitBusinessRepository typeConceptImpRepository) {
		this.typeConceptImpRepository = typeConceptImpRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		mapperFactory.classMap(EntamapUnitBusiness.class, EntamapUnitBusinessBO.class).byDefault().register();
		this.mapperEntamapUnitBusiness = mapperFactory.getMapperFacade();

	}

	@Override
	public List<EntamapUnitBusinessBO> getAll() {
		log.debug("EntamapUnitBusinessBLImpl:getAll [START]");
		
		List<EntamapUnitBusinessBO> typeConceptImps = new ArrayList<EntamapUnitBusinessBO>();

		List<EntamapUnitBusiness> typeConceptImpEntities = typeConceptImpRepository.findAll();
		for (EntamapUnitBusiness typeConceptImpEntity : typeConceptImpEntities) {
			typeConceptImps.add(mapperEntamapUnitBusiness.map(typeConceptImpEntity, EntamapUnitBusinessBO.class));
		}
		log.debug("EntamapUnitBusinessBLImpl:getAll [END]");
		return typeConceptImps;
	}

	//TODO No necesario
	@Override
	public EntamapUnitBusinessBO add(EntamapUnitBusinessBO typeConceptImpBO) {
		log.debug("EntamapUnitBusinessBLImpl:add [START]");
		EntamapUnitBusiness typeConceptImpEntity = mapperEntamapUnitBusiness.map(typeConceptImpBO, EntamapUnitBusiness.class);

		Util.getDateUser(typeConceptImpEntity, "INSERT");

		log.debug("EntamapUnitBusinessBLImpl:add [END]");
		return mapperEntamapUnitBusiness.map(typeConceptImpRepository.save(typeConceptImpEntity), EntamapUnitBusinessBO.class);
	}

	@Override
	public EntamapUnitBusinessBO update(Long typeConceptImpId, EntamapUnitBusinessBO typeConceptImpBO) {
		log.debug("EntamapUnitBusinessBLImpl:update [START]");
		EntamapUnitBusiness typeConceptImpEntity = typeConceptImpRepository.getOne(typeConceptImpId);
				
		if (typeConceptImpEntity != null) {

			Util.getDateUser(typeConceptImpEntity, "UPDATE");
			
			log.debug("EntamapUnitBusinessBLImpl:update [END]");
			return mapperEntamapUnitBusiness.map(typeConceptImpRepository.save(typeConceptImpEntity), EntamapUnitBusinessBO.class);
		}

		return null;
	}

	//TODO No necesario
	@Override
	public boolean delete(Long typeConceptImpId) {
		log.debug("EntamapUnitBusinessBLImpl:delete [START]");
		EntamapUnitBusiness typeConceptImpEntity = typeConceptImpRepository.getOne(typeConceptImpId);
		if (typeConceptImpEntity != null) {
			
			typeConceptImpRepository.delete(typeConceptImpEntity);
			
			log.debug("EntamapUnitBusinessBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
