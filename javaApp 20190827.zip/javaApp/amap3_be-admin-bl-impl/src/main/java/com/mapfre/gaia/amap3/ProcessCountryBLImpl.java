package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.ProcessCountry;
import com.mapfre.gaia.amap3.repositories.ProcessCountryRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

@Slf4j
@Service
@Transactional
public class ProcessCountryBLImpl implements IProcessCountryBL {

	private ProcessCountryRepository processCountryRepository;
	private MapperFacade mapperProcessCountry;

	@Autowired
	public ProcessCountryBLImpl(ProcessCountryRepository processCountryRepository, MapperFacade mapper) {
		this.processCountryRepository = processCountryRepository;
		this.mapperProcessCountry = mapper;

	}

	@Override
	public List<ProcessCountryBO> getAll() {
		log.debug("ProcessCountryBLImpl:getAll [START]");

		List<ProcessCountryBO> processCountrys = new ArrayList<ProcessCountryBO>();

		List<ProcessCountry> processCountryEntities = processCountryRepository.findAll();
		for (ProcessCountry processCountryEntity : processCountryEntities) {
			processCountrys.add(mapperProcessCountry.map(processCountryEntity, ProcessCountryBO.class));
		}
		log.debug("ProcessCountryBLImpl:getAll [END]");
		return processCountrys;
	}

	@Override
	public ProcessCountryBO add(ProcessCountryBO processCountryBO) {
		log.debug("ProcessCountryBLImpl:add [START]");
		ProcessCountry processCountryEntity = mapperProcessCountry.map(processCountryBO, ProcessCountry.class);

		processCountryEntity.setNmrVersion(new BigDecimal(1));

		Util.getDateUser(processCountryEntity, "INSERT");

		log.debug("ProcessCountryBLImpl:add [END]");
		return mapperProcessCountry.map(processCountryRepository.save(processCountryEntity), ProcessCountryBO.class);
	}

	@Override
	public ProcessCountryBO update(Long processCountryId, ProcessCountryBO processCountryBO) {
		log.debug("ProcessCountryBLImpl:update [START]");
		ProcessCountry processCountryEntity = processCountryRepository.getOne(processCountryId);

		ProcessCountry processCountryEntityAux = mapperProcessCountry.map(processCountryBO, ProcessCountry.class);

		if (processCountryEntity != null) {

			String cdProcess = processCountryEntity.getCdProceso();
			BigDecimal nmrVersion = processCountryEntity.getNmrVersion();

			Util.getDateUser(processCountryEntity, "UPDATE");

			processCountryRepository.save(processCountryEntity);

			processCountryEntityAux.setCdProceso(cdProcess);
			processCountryEntityAux.setDateVersion(new Date());
			processCountryEntityAux.setNmrVersion(nmrVersion.add(new BigDecimal(1)));

			Util.getDateUser(processCountryEntityAux, "INSERT");

			log.debug("ProcessCountryBLImpl:update [START]");
			return mapperProcessCountry.map(processCountryRepository.save(processCountryEntityAux),
					ProcessCountryBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long processCountryId) {
		log.debug("ProcessCountryBLImpl:delete [START]");
		ProcessCountry processCountryEntity = processCountryRepository.getOne(processCountryId);
		if (processCountryEntity != null) {

			processCountryRepository.delete(processCountryEntity);

			log.debug("ProcessCountryBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
