package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.TypeConceptImputation;
import com.mapfre.gaia.amap3.repositories.TypeConceptImputationRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

@Slf4j
@Service
@Transactional
public class TypeConceptImputationBLImpl implements ITypeConceptImputationBL {

	private TypeConceptImputationRepository typeConceptImpRepository;
	private MapperFacade mapperTypeConceptImputation;

	@Autowired
	public TypeConceptImputationBLImpl(TypeConceptImputationRepository typeConceptImpRepository, MapperFacade mapper) {
		this.typeConceptImpRepository = typeConceptImpRepository;
		this.mapperTypeConceptImputation = mapper;

	}

	@Override
	public List<TypeConceptImputationBO> getAll() {
		log.debug("TypeConceptImputationBLImpl:getAll [START]");

		List<TypeConceptImputationBO> typeConceptImps = new ArrayList<TypeConceptImputationBO>();
		List<TypeConceptImputationBO> typeConceptImpsAux = new ArrayList<TypeConceptImputationBO>();
		List<TypeConceptImputationBO> typeConceptImpsHijos = new ArrayList<TypeConceptImputationBO>();

		List<TypeConceptImputation> typeConceptImpEntities = typeConceptImpRepository.findAll();
		for (TypeConceptImputation typeConceptImpEntity : typeConceptImpEntities) {
			typeConceptImpsAux.add(mapperTypeConceptImputation.map(typeConceptImpEntity, TypeConceptImputationBO.class));
		}
		
		typeConceptImpsAux.forEach(typeConceptImp -> {
			if(typeConceptImp.getTypeConceptImputation() == null 
					|| typeConceptImp.getTypeConceptImputation().getIdTypeConceptImputationPk() == 0) {
				typeConceptImps.add(typeConceptImp);
			}else {
				typeConceptImpsHijos.add(typeConceptImp);				
			}
		});
		
		typeConceptImpsHijos.forEach(hijo -> {
			long idPadre = hijo.getTypeConceptImputation().getIdTypeConceptImputationPk();
			typeConceptImps.forEach(padre -> {
				if(padre.getIdTypeConceptImputationPk() == idPadre) {
					padre.getTypeConceptImputations().add(hijo);
				}
			});
		});
		
		log.debug("TypeConceptImputationBLImpl:getAll [END]");
		return typeConceptImps;
	}

	@Override
	public TypeConceptImputationBO add(TypeConceptImputationBO typeConceptImpBO) {
		log.debug("TypeConceptImputationBLImpl:add [START]");
		TypeConceptImputation typeConceptImpEntity = mapperTypeConceptImputation.map(typeConceptImpBO,
				TypeConceptImputation.class);

		Util.getDateUser(typeConceptImpEntity, "INSERT");

		log.debug("TypeConceptImputationBLImpl:add [END]");
		typeConceptImpRepository.save(typeConceptImpEntity);
		return mapperTypeConceptImputation.map(typeConceptImpRepository.save(typeConceptImpEntity),
				TypeConceptImputationBO.class);
	}

	@Override
	public TypeConceptImputationBO update(Long typeConceptImpId, TypeConceptImputationBO typeConceptImpBO) {
		log.debug("TypeConceptImputationBLImpl:update [START]");
		TypeConceptImputation typeConceptImpEntity = typeConceptImpRepository.getOne(typeConceptImpId);

		if (typeConceptImpEntity != null) {
			typeConceptImpEntity.setIsImputablePai(typeConceptImpBO.getIsImputablePai());
			typeConceptImpEntity.setTxtTypeConceptImputation(typeConceptImpBO.getTxtTypeConceptImputation());
			typeConceptImpEntity.setCodTypeConceptImputation(typeConceptImpBO.getCodTypeConceptImputation());
			typeConceptImpEntity.setTypeConceptImputation(mapperTypeConceptImputation.map(typeConceptImpBO.getTypeConceptImputation(), TypeConceptImputation.class));

			Util.getDateUser(typeConceptImpEntity, "UPDATE");

			log.debug("TypeConceptImputationBLImpl:update [END]");
			return mapperTypeConceptImputation.map(typeConceptImpRepository.save(typeConceptImpEntity),
					TypeConceptImputationBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long typeConceptImpId) {
		log.debug("TypeConceptImputationBLImpl:delete [START]");
		TypeConceptImputation typeConceptImpEntity = typeConceptImpRepository.getOne(typeConceptImpId);
		if (typeConceptImpEntity != null) {

			typeConceptImpRepository.delete(typeConceptImpEntity);

			log.debug("TypeConceptImputationBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
