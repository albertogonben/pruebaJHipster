package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.AreaTerritorial;
import com.mapfre.gaia.amap3.repositories.AreaTerritorialRepository;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Service
@Transactional
public class AreaTerritorialBLImpl implements IAreaTerritorialBL {

	private AreaTerritorialRepository areaTerritorialRepository;
	private MapperFacade mapperAreaTerritorial;

	@Autowired
	public AreaTerritorialBLImpl(AreaTerritorialRepository areaTerritorialRepository) {
		this.areaTerritorialRepository = areaTerritorialRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		mapperFactory.classMap(AreaTerritorial.class, AreaTerritorialBO.class).byDefault().register();
		this.mapperAreaTerritorial = mapperFactory.getMapperFacade();

	}

	@Override
	public List<AreaTerritorialBO> getAll() {
		List<AreaTerritorialBO> listAreaTerritorial = new ArrayList<AreaTerritorialBO>();

		List<AreaTerritorial> areaTerritorialEntities = areaTerritorialRepository.findAll();
		for (AreaTerritorial areaTerritorialEntity : areaTerritorialEntities) {
			listAreaTerritorial.add(mapperAreaTerritorial.map(areaTerritorialEntity, AreaTerritorialBO.class));
		}
		return listAreaTerritorial;
	}

	@Override
	public AreaTerritorialBO add(AreaTerritorialBO areaTerritorialBO) {
		AreaTerritorial areaTerritorialEntity = mapperAreaTerritorial.map(areaTerritorialBO, AreaTerritorial.class);
		return mapperAreaTerritorial.map(areaTerritorialRepository.save(areaTerritorialEntity),
				AreaTerritorialBO.class);
	}

	@Override
	public AreaTerritorialBO update(Long areaTerritorialId, AreaTerritorialBO areaTerritorialBO) {
		AreaTerritorial areaTerritorialEntity = areaTerritorialRepository.getOne(areaTerritorialId);
		if (areaTerritorialEntity != null) {

			// TODO Alberto Setear datos de entrada Hito III

			return mapperAreaTerritorial.map(areaTerritorialRepository.save(areaTerritorialEntity),
					AreaTerritorialBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long areaTerritorialId) {
		AreaTerritorial areaTerritorialEntity = areaTerritorialRepository.findOne(areaTerritorialId);
		if (areaTerritorialEntity != null) {
			areaTerritorialRepository.delete(areaTerritorialId);
			return true;
		}
		return false;
	}

}
