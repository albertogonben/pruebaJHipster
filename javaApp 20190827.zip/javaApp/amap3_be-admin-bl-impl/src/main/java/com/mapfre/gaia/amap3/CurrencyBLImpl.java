package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Currency;
import com.mapfre.gaia.amap3.repositories.CurrencyRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

@Slf4j
@Service
@Transactional
public class CurrencyBLImpl implements ICurrencyBL {

	private CurrencyRepository currencyRepository;
	private MapperFacade mapperCurrency;

	@Autowired
	public CurrencyBLImpl(CurrencyRepository currencyRepository, MapperFacade mapper) {
		this.currencyRepository = currencyRepository;
		this.mapperCurrency = mapper;
	}

	@Override
	public List<CurrencyBO> getlAll() {
		log.debug("CurrencyBLImpl:getlAll [START]");
		List<CurrencyBO> currencyOut = new ArrayList<CurrencyBO>();

		List<Currency> currencyList = currencyRepository.findAll();

		for (Currency currency : currencyList) {
			currencyOut.add(mapperCurrency.map(currency, CurrencyBO.class));
		}
		
		log.debug("CurrencyBLImpl:getlAll [END]");
		return currencyOut;
	}

	@Override
	public CurrencyBO save(CurrencyBO input) {
		log.debug("CurrencyBLImpl:save [START]");
		Currency entity = mapperCurrency.map(input, Currency.class);
		
		Util.getDateUser(entity, "INSERT");

		Currency output = currencyRepository.save(entity);

		log.debug("CurrencyBLImpl:save [END]");
		return mapperCurrency.map(output, CurrencyBO.class);
		
	}

	@Override
	public CurrencyBO update(Long currencyId, CurrencyBO input) {
		log.debug("CurrencyBLImpl:update [START]");
		Currency entityToUpdate = this.currencyRepository.getOne(currencyId);

		if (entityToUpdate != null) {

			entityToUpdate.setCdCurrency(input.getCdCurrency());
			entityToUpdate.setTxtCurrency(input.getTxtCurrency());
			entityToUpdate.setMrkActive(input.getMrkActive());
			Util.getDateUser(entityToUpdate, "UPDATE");
			Currency output = currencyRepository.save(entityToUpdate);
			
			log.debug("CurrencyBLImpl:update [END]");
			return mapperCurrency.map(output, CurrencyBO.class);

		} else {
			return null;
		}

	}

	@Override
	public boolean delete(Long currencyId) {
		log.debug("CurrencyBLImpl:delete [START]");
		Currency currencyEntity = currencyRepository.getOne(currencyId);
		if (currencyEntity != null) {
			currencyEntity.setMrkActive(new BigDecimal(0));
			Util.getDateUser(currencyEntity, "UPDATE");

			mapperCurrency.map(currencyRepository.save(currencyEntity), CurrencyBO.class);

			log.debug("CurrencyBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
