package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Question;
import com.mapfre.gaia.amap3.entities.Questionnaire;
import com.mapfre.gaia.amap3.entities.QuestionnaireQuestion;
import com.mapfre.gaia.amap3.repositories.QuestionRepository;
import com.mapfre.gaia.amap3.repositories.QuestionnaireQuestionRepository;
import com.mapfre.gaia.amap3.repositories.QuestionnaireRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

@Slf4j
@Service
@Transactional
public class QuestionnaireQuestionBLImpl implements IQuestionnaireQuestionBL {

	private QuestionnaireQuestionRepository questionnaireQuestionRepository;
	private QuestionnaireRepository questionnaireRepository;
	private QuestionRepository questionRepository;
	private MapperFacade mapperQuestionnaireQuestion;

	@Autowired
	public QuestionnaireQuestionBLImpl(QuestionnaireQuestionRepository questionnaireQuestionRepository,
			QuestionnaireRepository questionnaireRepository, QuestionRepository questionRepository,
			MapperFacade mapper) {
		this.questionnaireQuestionRepository = questionnaireQuestionRepository;
		this.questionnaireRepository = questionnaireRepository;
		this.questionRepository = questionRepository;
		this.mapperQuestionnaireQuestion = mapper;

	}

	@Override
	public List<QuestionnaireQuestionBO> getAll() {
		log.debug("QuestionnaireQuestionBLImpl:getAll [START]");

		List<QuestionnaireQuestionBO> questionnaireQuestions = new ArrayList<QuestionnaireQuestionBO>();

		List<QuestionnaireQuestion> questionnaireQuestionEntities = questionnaireQuestionRepository.findAll();
		for (QuestionnaireQuestion questionnaireQuestionEntity : questionnaireQuestionEntities) {
			questionnaireQuestions
					.add(mapperQuestionnaireQuestion.map(questionnaireQuestionEntity, QuestionnaireQuestionBO.class));
		}
		log.debug("QuestionnaireQuestionBLImpl:getAll [END]");
		return questionnaireQuestions;
	}

	@Override
	public QuestionnaireQuestionBO add(QuestionnaireQuestionBO questionnaireQuestionBO) {
		log.debug("QuestionnaireQuestionBLImpl:add [START]");
		QuestionnaireQuestion questionnaireQuestionEntity = mapperQuestionnaireQuestion.map(questionnaireQuestionBO,
				QuestionnaireQuestion.class);

		questionnaireQuestionEntity.setNmrVersion(new BigDecimal(1));

		Util.getDateUser(questionnaireQuestionEntity, "INSERT");

		log.debug("QuestionnaireQuestionBLImpl:add [END]");
		return mapperQuestionnaireQuestion.map(questionnaireQuestionRepository.save(questionnaireQuestionEntity),
				QuestionnaireQuestionBO.class);
	}

	@Override
	public QuestionnaireQuestionBO update(Long questionnaireQuestionId,
			QuestionnaireQuestionBO questionnaireQuestionBO) {
		log.debug("QuestionnaireQuestionBLImpl:update [START]");
		QuestionnaireQuestion questionnaireQuestionEntity = questionnaireQuestionRepository
				.findOne(questionnaireQuestionId);

		QuestionnaireQuestion questionnaireQuestionAux = mapperQuestionnaireQuestion.map(questionnaireQuestionBO,
				QuestionnaireQuestion.class);

		if (questionnaireQuestionEntity != null) {

			questionnaireQuestionEntity.setDateVersion(questionnaireQuestionAux.getDateVersion());
			questionnaireQuestionEntity.setNmrOrder(questionnaireQuestionAux.getNmrOrder());
			questionnaireQuestionEntity
					.setNmrVersion(questionnaireQuestionEntity.getNmrVersion().add(new BigDecimal(1)));
			Question question = questionRepository
					.findOne(questionnaireQuestionAux.getQuestion().getIdQuestionTypePk());
			Questionnaire questionnaire = questionnaireRepository
					.findOne(questionnaireQuestionAux.getQuestionnaire().getIdQuestionnairePk());
			questionnaireQuestionEntity.setQuestion(question);
			questionnaireQuestionEntity.setQuestionnaire(questionnaire);

			Util.getDateUser(questionnaireQuestionEntity, "UPDATE");

			log.debug("QuestionnaireQuestionBLImpl:update [END]");
			return mapperQuestionnaireQuestion.map(questionnaireQuestionRepository.save(questionnaireQuestionEntity),
					QuestionnaireQuestionBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long questionnaireQuestionId) {
		log.debug("QuestionnaireQuestionBLImpl:delete [START]");
		QuestionnaireQuestion questionnaireQuestionEntity = questionnaireQuestionRepository
				.getOne(questionnaireQuestionId);
		if (questionnaireQuestionEntity != null) {

			questionnaireQuestionRepository.delete(questionnaireQuestionEntity);

			log.debug("QuestionnaireQuestionBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
