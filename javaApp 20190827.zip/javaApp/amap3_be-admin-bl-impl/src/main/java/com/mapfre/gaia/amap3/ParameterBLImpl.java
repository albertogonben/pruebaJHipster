package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Parameter;
import com.mapfre.gaia.amap3.repositories.ParameterRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class ParameterBLImpl implements IParameterBL {

	private ParameterRepository parameterRepository;
	private MapperFacade mapperParameter;

	@Autowired
	public ParameterBLImpl(ParameterRepository parameterRepository) {
		this.parameterRepository = parameterRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		mapperFactory.classMap(Parameter.class, ParameterBO.class).byDefault().register();
		this.mapperParameter = mapperFactory.getMapperFacade();

	}

	@Override
	public List<ParameterBO> getAll() {
		log.debug("ParameterBLImpl:getAll [START]");
		
		List<ParameterBO> parameters = new ArrayList<ParameterBO>();

		List<Parameter> parameterEntities = parameterRepository.findAll();
		for (Parameter parameterEntity : parameterEntities) {
			parameters.add(mapperParameter.map(parameterEntity, ParameterBO.class));
		}
		log.debug("ParameterBLImpl:getAll [END]");
		return parameters;
	}

	@Override
	public ParameterBO add(ParameterBO parameterBO) {
		log.debug("ParameterBLImpl:add [START]");
		Parameter parameterEntity = mapperParameter.map(parameterBO, Parameter.class);
		
		Util.getDateUser(parameterEntity, "INSERT");

		log.debug("ParameterBLImpl:add [END]");
		return mapperParameter.map(parameterRepository.save(parameterEntity), ParameterBO.class);
	}

	@Override
	public ParameterBO update(Long parameterId, ParameterBO parameterBO) {
		log.debug("ParameterBLImpl:update [START]");
		Parameter parameterEntity = parameterRepository.getOne(parameterId);
				
		if (parameterEntity != null) {

			parameterEntity.setCdgoParameter(parameterBO.getCdgoParameter());
			parameterEntity.setMrkActive(parameterBO.getMrkActive());
			parameterEntity.setTxtComment(parameterBO.getTxtComment());
			parameterEntity.setTxtValor(parameterBO.getTxtValor());
			
			Util.getDateUser(parameterEntity, "UPDATE");
			
			log.debug("ParameterBLImpl:update [END]");
			return mapperParameter.map(parameterRepository.save(parameterEntity), ParameterBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long parameterId) {
		log.debug("ParameterBLImpl:delete [START]");
		Parameter parameterEntity = parameterRepository.getOne(parameterId);
		if (parameterEntity != null) {
			
			parameterRepository.delete(parameterEntity);
			
			log.debug("ParameterBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
