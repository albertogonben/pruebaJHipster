package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.ProcessCountry;
import com.mapfre.gaia.amap3.entities.ProcessUnitBusiness;
import com.mapfre.gaia.amap3.repositories.ProcessCountryRepository;
import com.mapfre.gaia.amap3.repositories.ProcessUnitBusinessRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

@Slf4j
@Service
@Transactional
public class ProcessUnitBusinessBLImpl implements IProcessUnitBusinessBL {

	private ProcessUnitBusinessRepository processUnitBusinessRepository;
	private ProcessCountryRepository processCountryRepository;
	private MapperFacade mapperProcessUnitBusiness;
	private MapperFacade mapperProcessCountry;

	@Autowired
	public ProcessUnitBusinessBLImpl(ProcessUnitBusinessRepository processUnitBusinessRepository,
			ProcessCountryRepository processCountryRepository, MapperFacade mapper, MapperFacade mapperProcessCountry) {
		this.processUnitBusinessRepository = processUnitBusinessRepository;
		this.processCountryRepository = processCountryRepository;
		this.mapperProcessUnitBusiness = mapper;
		this.mapperProcessCountry = mapperProcessCountry;

	}

	@Override
	public List<ProcessUnitBusinessBO> getAll() {
		log.debug("ProcessUnitBusinessBLImpl:getAll [START]");

		List<ProcessUnitBusinessBO> processUnitBusinesss = new ArrayList<ProcessUnitBusinessBO>();
		List<ProcessUnitBusinessBO> processUnitBusinesssAux = new ArrayList<ProcessUnitBusinessBO>();
		List<ProcessUnitBusinessBO> processUnitBusinesssHijos = new ArrayList<ProcessUnitBusinessBO>();

		List<ProcessUnitBusiness> processUnitBusinessEntities = processUnitBusinessRepository.findAll();
		for (ProcessUnitBusiness processUnitBusinessEntity : processUnitBusinessEntities) {

			ProcessUnitBusinessBO processUnitBusinessBO = mapperProcessUnitBusiness.map(processUnitBusinessEntity,
					ProcessUnitBusinessBO.class);

			List<ProcessCountry> processCountry = processCountryRepository
					.findByProcessUnitBusiness(processUnitBusinessEntity);

			processCountry.forEach(process -> {
				ProcessCountryBO processCountryBO = mapperProcessCountry.map(process, ProcessCountryBO.class);

				if (null == processUnitBusinessBO.getProcessCountries()) {
					processUnitBusinessBO.setProcessCountries(new ArrayList<ProcessCountryBO>());
				}
				processUnitBusinessBO.getProcessCountries().add(processCountryBO);

			});

			processUnitBusinesssAux.add(processUnitBusinessBO);
		}

		processUnitBusinesssAux.forEach(processUnitBusiness -> {
			if (processUnitBusiness.getProcessUnitBusiness() == null
					|| processUnitBusiness.getProcessUnitBusiness().getIdProcessPk() == 0) {
				processUnitBusinesss.add(processUnitBusiness);
			} else {
				processUnitBusinesssHijos.add(processUnitBusiness);
			}
		});

		processUnitBusinesssHijos.forEach(hijo -> {
			long idPadre = hijo.getProcessUnitBusiness().getIdProcessPk();
			processUnitBusinesss.forEach(padre -> {
				if (padre.getIdProcessPk() == idPadre) {
					if (null == padre.getProcessUnitBusinesses()) {
						padre.setProcessUnitBusinesses(new ArrayList<ProcessUnitBusinessBO>());
					}
					padre.getProcessUnitBusinesses().add(hijo);
				}
			});
		});

		log.debug("ProcessUnitBusinessBLImpl:getAll [END]");
		return processUnitBusinesss;
	}

	@Override
	public ProcessUnitBusinessBO add(ProcessUnitBusinessBO processUnitBusinessBO) {
		log.debug("ProcessUnitBusinessBLImpl:add [START]");
		ProcessUnitBusiness processUnitBusinessEntity = mapperProcessUnitBusiness.map(processUnitBusinessBO,
				ProcessUnitBusiness.class);

		processUnitBusinessEntity.setNmrVersion(new BigDecimal(1));
		processUnitBusinessEntity.setDateVersion(new Date());

		Util.getDateUser(processUnitBusinessEntity, "INSERT");

		log.debug("ProcessUnitBusinessBLImpl:add [END]");
		ProcessUnitBusiness result = processUnitBusinessRepository.save(processUnitBusinessEntity);
		return mapperProcessUnitBusiness.map(result, ProcessUnitBusinessBO.class);
	}

	@Override
	public ProcessUnitBusinessBO update(Long processUnitBusinessId, ProcessUnitBusinessBO processUnitBusinessBO) {
		log.debug("ProcessUnitBusinessBLImpl:update [START]");
		ProcessUnitBusiness processUnitBusinessEntity = processUnitBusinessRepository.getOne(processUnitBusinessId);
		if (processUnitBusinessEntity != null) {

			// TODO Versionar y cerrar el anterior registro
			String cdProcess = processUnitBusinessEntity.getCdProcess();
			BigDecimal nmrVersion = processUnitBusinessEntity.getNmrVersion();

			Util.getDateUser(processUnitBusinessEntity, "UPDATE");

			processUnitBusinessRepository.save(processUnitBusinessEntity);

			ProcessUnitBusiness processUnitBusinessAux = mapperProcessUnitBusiness.map(processUnitBusinessBO,
					ProcessUnitBusiness.class);

			processUnitBusinessAux.setCdProcess(cdProcess);
			processUnitBusinessAux.setNmrVersion(nmrVersion.add(new BigDecimal(1)));
			processUnitBusinessAux.setDateVersion(new Date());

			Util.getDateUser(processUnitBusinessAux, "UPDATE");

			log.debug("ProcessUnitBusinessBLImpl:update [START]");
			return mapperProcessUnitBusiness.map(processUnitBusinessRepository.save(processUnitBusinessAux),
					ProcessUnitBusinessBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long processUnitBusinessId) {
		log.debug("ProcessUnitBusinessBLImpl:delete [START]");
		ProcessUnitBusiness processUnitBusinessEntity = processUnitBusinessRepository.getOne(processUnitBusinessId);
		if (processUnitBusinessEntity != null) {

			processUnitBusinessRepository.delete(processUnitBusinessEntity);

			log.debug("ProcessUnitBusinessBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
