package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Tag;
import com.mapfre.gaia.amap3.mapper.StringDateMapper;
import com.mapfre.gaia.amap3.repositories.TagRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.ConverterFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class TagBLImpl implements ITagBL {

	private TagRepository tagRepository;
	private MapperFacade mapperTag;

	@Autowired
	public TagBLImpl(TagRepository tagRepository) {
		this.tagRepository = tagRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		
		ConverterFactory converterFactory = mapperFactory.getConverterFactory();
		converterFactory.registerConverter("StringDateMapper", new StringDateMapper());

		mapperFactory.classMap(Tag.class, TagBO.class).fieldMap("dateLastUse", "dateLastUse")
				.converter("StringDateMapper").add().byDefault().register();
		
		this.mapperTag = mapperFactory.getMapperFacade();

	}

	@Override
	public List<TagBO> getAll() {
		log.debug("TagBLImpl:getAll [START]");
		
		List<TagBO> tags = new ArrayList<TagBO>();

		List<Tag> tagEntities = tagRepository.findAll();
		for (Tag tagEntity : tagEntities) {
			tags.add(mapperTag.map(tagEntity, TagBO.class));
		}
		log.debug("TagBLImpl:getAll [END]");
		return tags;
	}

	@Override
	public TagBO add(TagBO tagBO) {
		log.debug("TagBLImpl:add [START]");
		Tag tagEntity = mapperTag.map(tagBO, Tag.class);

		Util.getDateUser(tagEntity, "INSERT");

		log.debug("TagBLImpl:add [END]");
		return mapperTag.map(tagRepository.save(tagEntity), TagBO.class);
	}

	@Override
	public TagBO update(Long tagId, TagBO tagBO) {
		log.debug("TagBLImpl:update [START]");
		Tag tagEntity = tagRepository.getOne(tagId);
		
		Tag tagAux = mapperTag.map(tagBO, Tag.class);
		
		if (tagEntity != null) {
			
			// TODO Validar campos Front
			
			tagEntity.setCdTag(tagAux.getCdTag());
			tagEntity.setDateLastUse(tagAux.getDateLastUse());
			tagEntity.setIsGlobalTag(tagAux.getIsGlobalTag());
			tagEntity.setMrkActive(tagAux.getMrkActive());
			tagEntity.setNmrUses(tagAux.getNmrUses());
			tagEntity.setTxtDescription(tagAux.getTxtDescription());
			tagEntity.setTxtName(tagAux.getTxtName());
			
			Util.getDateUser(tagEntity, "UPDATE");
			
			log.debug("TagBLImpl:update [START]");
			return mapperTag.map(tagRepository.save(tagEntity), TagBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long tagId) {
		log.debug("TagBLImpl:delete [START]");
		Tag tagEntity = tagRepository.getOne(tagId);
		if (tagEntity != null) {
			
			tagEntity.setMrkActive(new BigDecimal(0));
			Util.getDateUser(tagEntity, "UPDATE");
			
			mapperTag.map(tagRepository.save(tagEntity), TagBO.class);
			
			log.debug("TagBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
