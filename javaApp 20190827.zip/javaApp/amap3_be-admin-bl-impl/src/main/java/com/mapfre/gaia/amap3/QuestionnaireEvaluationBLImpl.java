package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.QuestionnaireEvaluation;
import com.mapfre.gaia.amap3.repositories.QuestionnaireEvaluationRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class QuestionnaireEvaluationBLImpl implements IQuestionnaireEvaluationBL {

	private QuestionnaireEvaluationRepository questionnaireEvaluationRepository;
	private MapperFacade mapperQuestionnaireEvaluation;

	@Autowired
	public QuestionnaireEvaluationBLImpl(QuestionnaireEvaluationRepository questionnaireEvaluationRepository) {
		this.questionnaireEvaluationRepository = questionnaireEvaluationRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		mapperFactory.classMap(QuestionnaireEvaluation.class, QuestionnaireEvaluationBO.class).byDefault().register();
		this.mapperQuestionnaireEvaluation = mapperFactory.getMapperFacade();

	}

	@Override
	public List<QuestionnaireEvaluationBO> getAll() {
		log.debug("QuestionnaireEvaluationBLImpl:getAll [START]");
		
		List<QuestionnaireEvaluationBO> questionnaireEvaluations = new ArrayList<QuestionnaireEvaluationBO>();

		List<QuestionnaireEvaluation> questionnaireEvaluationEntities = questionnaireEvaluationRepository.findAll();
		for (QuestionnaireEvaluation questionnaireEvaluationEntity : questionnaireEvaluationEntities) {
			questionnaireEvaluations.add(mapperQuestionnaireEvaluation.map(questionnaireEvaluationEntity, QuestionnaireEvaluationBO.class));
		}
		log.debug("QuestionnaireEvaluationBLImpl:getAll [END]");
		return questionnaireEvaluations;
	}

	//TODO No necesario
	@Override
	public QuestionnaireEvaluationBO add(QuestionnaireEvaluationBO questionnaireEvaluationBO) {
		log.debug("QuestionnaireEvaluationBLImpl:add [START]");
		QuestionnaireEvaluation questionnaireEvaluationEntity = mapperQuestionnaireEvaluation.map(questionnaireEvaluationBO, QuestionnaireEvaluation.class);

		Util.getDateUser(questionnaireEvaluationEntity, "INSERT");

		log.debug("QuestionnaireEvaluationBLImpl:add [END]");
		return mapperQuestionnaireEvaluation.map(questionnaireEvaluationRepository.save(questionnaireEvaluationEntity), QuestionnaireEvaluationBO.class);
	}

	@Override
	public QuestionnaireEvaluationBO update(Long questionnaireEvaluationId, QuestionnaireEvaluationBO questionnaireEvaluationBO) {
		log.debug("QuestionnaireEvaluationBLImpl:update [START]");
		QuestionnaireEvaluation questionnaireEvaluationEntity = questionnaireEvaluationRepository.getOne(questionnaireEvaluationId);
				
		if (questionnaireEvaluationEntity != null) {

			Util.getDateUser(questionnaireEvaluationEntity, "UPDATE");
			
			log.debug("QuestionnaireEvaluationBLImpl:update [END]");
			return mapperQuestionnaireEvaluation.map(questionnaireEvaluationRepository.save(questionnaireEvaluationEntity), QuestionnaireEvaluationBO.class);
		}

		return null;
	}

	//TODO No necesario
	@Override
	public boolean delete(Long questionnaireEvaluationId) {
		log.debug("QuestionnaireEvaluationBLImpl:delete [START]");
		QuestionnaireEvaluation questionnaireEvaluationEntity = questionnaireEvaluationRepository.getOne(questionnaireEvaluationId);
		if (questionnaireEvaluationEntity != null) {
			
			questionnaireEvaluationRepository.delete(questionnaireEvaluationEntity);
			
			log.debug("QuestionnaireEvaluationBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
