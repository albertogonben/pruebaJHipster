package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.GuideJob;
import com.mapfre.gaia.amap3.repositories.GuideJobRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

@Slf4j
@Service
@Transactional
public class GuideJobBLImpl implements IGuideJobBL {

	private GuideJobRepository guideJobRepository;
	private MapperFacade mapperGuideJob;

	@Autowired
	public GuideJobBLImpl(GuideJobRepository guideJobRepository, MapperFacade mapper) {
		this.guideJobRepository = guideJobRepository;
		this.mapperGuideJob = mapper;

	}

	@Override
	public List<GuideJobBO> getAll() {
		log.debug("GuideJobBLImpl:getAll [START]");

		List<GuideJobBO> guideJobs = new ArrayList<GuideJobBO>();
		List<GuideJobBO> guideJobsAux = new ArrayList<GuideJobBO>();
		List<GuideJobBO> guideJobsHijos = new ArrayList<GuideJobBO>();

		List<GuideJob> guideJobEntities = guideJobRepository.findAll();
		for (GuideJob guideJobEntity : guideJobEntities) {
			guideJobsAux.add(mapperGuideJob.map(guideJobEntity, GuideJobBO.class));
		}

		guideJobsAux.forEach(guideJob -> {
			if (guideJob.getGuideJob() == null || guideJob.getGuideJob().getIdNodePk() == 0) {
				guideJobs.add(guideJob);
			} else {
				guideJobsHijos.add(guideJob);
			}
		});

		guideJobsHijos.forEach(hijo -> {
			long idPadre = hijo.getGuideJob().getIdNodePk();
			guideJobs.forEach(padre -> {
				if (padre.getIdNodePk() == idPadre) {
					if (null == padre.getGuideJobs()) {
						padre.setGuideJobs(new ArrayList<GuideJobBO>());
					}
					padre.getGuideJobs().add(hijo);
				}
			});
		});

		log.debug("GuideJobBLImpl:getAll [END]");
		return guideJobs;
	}

	@Override
	public GuideJobBO add(GuideJobBO guideJobBO) {
		log.debug("GuideJobBLImpl:add [START]");
		GuideJob guideJobEntity = mapperGuideJob.map(guideJobBO, GuideJob.class);

		guideJobEntity.setDateUse(null);
		guideJobEntity.setDateVersion(new Date());
		guideJobEntity.setNmVersion(new BigDecimal(1));
		guideJobEntity.setNmrUses(new BigDecimal(0));

		if (null != guideJobEntity.getGuideJob()) {
			GuideJob padre = guideJobRepository.findOne(guideJobEntity.getGuideJob().getIdNodePk());
			guideJobEntity.setGuideJob(padre);
		}

		Util.getDateUser(guideJobEntity, "INSERT");

		log.debug("GuideJobBLImpl:add [END]");
		return mapperGuideJob.map(guideJobRepository.save(guideJobEntity), GuideJobBO.class);
	}

	@Override
	public GuideJobBO update(Long guideJobId, GuideJobBO guideJobBO) {
		log.debug("GuideJobBLImpl:update [START]");
		GuideJob guideJobEntity = guideJobRepository.getOne(guideJobId);

		GuideJob guideJobEntityAux = mapperGuideJob.map(guideJobBO, GuideJob.class);

		if (guideJobEntity != null) {

			String cdNode = guideJobEntity.getCdNode();
			BigDecimal nmVersion = guideJobEntity.getNmVersion();

			Util.getDateUser(guideJobEntity, "UPDATE");

			guideJobRepository.save(guideJobEntity);

			guideJobEntityAux.setCdNode(cdNode);
			guideJobEntityAux.setNmVersion(nmVersion.add(new BigDecimal(1)));

			Util.getDateUser(guideJobEntityAux, "INSERT");

			log.debug("GuideJobBLImpl:update [START]");
			return mapperGuideJob.map(guideJobRepository.save(guideJobEntityAux), GuideJobBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long guideJobId) {
		log.debug("GuideJobBLImpl:delete [START]");
		GuideJob guideJobEntity = guideJobRepository.getOne(guideJobId);
		if (guideJobEntity != null) {

			guideJobRepository.delete(guideJobEntity);

			log.debug("GuideJobBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
