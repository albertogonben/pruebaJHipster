package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Questionnaire;
import com.mapfre.gaia.amap3.repositories.QuestionnaireRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

@Slf4j
@Service
@Transactional
public class QuestionnaireBLImpl implements IQuestionnaireBL {

	private QuestionnaireRepository questionnaireRepository;
	private MapperFacade mapperQuestionnaire;

	@Autowired
	public QuestionnaireBLImpl(QuestionnaireRepository questionnaireRepository, MapperFacade mapper) {
		this.questionnaireRepository = questionnaireRepository;
		this.mapperQuestionnaire = mapper;

	}

	@Override
	public List<QuestionnaireBO> getAll() {
		log.debug("QuestionnaireBLImpl:getAll [START]");

		List<QuestionnaireBO> questionnaires = new ArrayList<QuestionnaireBO>();

		List<Questionnaire> questionnaireEntities = questionnaireRepository.findAll();
		for (Questionnaire questionnaireEntity : questionnaireEntities) {
			questionnaires.add(mapperQuestionnaire.map(questionnaireEntity, QuestionnaireBO.class));
		}
		log.debug("QuestionnaireBLImpl:getAll [END]");
		return questionnaires;
	}

	// TODO No necesario
	@Override
	public QuestionnaireBO add(QuestionnaireBO questionnaireBO) {
		log.debug("QuestionnaireBLImpl:add [START]");
		Questionnaire questionnaireEntity = mapperQuestionnaire.map(questionnaireBO, Questionnaire.class);

		questionnaireEntity.setNmrVersion(new BigDecimal(1));
		
		Util.getDateUser(questionnaireEntity, "INSERT");

		log.debug("QuestionnaireBLImpl:add [END]");
		return mapperQuestionnaire.map(questionnaireRepository.save(questionnaireEntity), QuestionnaireBO.class);
	}

	@Override
	public QuestionnaireBO update(Long questionnaireId, QuestionnaireBO questionnaireBO) {
		log.debug("QuestionnaireBLImpl:update [START]");
		Questionnaire questionnaireEntity = questionnaireRepository.getOne(questionnaireId);

		Questionnaire questionnaireAux = mapperQuestionnaire.map(questionnaireBO, Questionnaire.class);
		
		if (questionnaireEntity != null) {

			questionnaireEntity.setCodQuestionnaire(questionnaireAux.getCodQuestionnaire());
			questionnaireEntity.setDateVersion(questionnaireAux.getDateVersion());
			questionnaireEntity.setMrkActive(questionnaireAux.getMrkActive());
			questionnaireEntity.setNmrVersion(questionnaireEntity.getNmrVersion().add(new BigDecimal(1)));
			questionnaireEntity.setTxtDescription(questionnaireAux.getTxtDescription());
			questionnaireEntity.setTxtTitle(questionnaireAux.getTxtTitle());
			
			Util.getDateUser(questionnaireEntity, "UPDATE");

			log.debug("QuestionnaireBLImpl:update [END]");
			return mapperQuestionnaire.map(questionnaireRepository.save(questionnaireEntity), QuestionnaireBO.class);
		}

		return null;
	}

	// TODO No necesario
	@Override
	public boolean delete(Long questionnaireId) {
		log.debug("QuestionnaireBLImpl:delete [START]");
		Questionnaire questionnaireEntity = questionnaireRepository.getOne(questionnaireId);
		if (questionnaireEntity != null) {

			questionnaireEntity.setMrkActive(new BigDecimal(0));
			Util.getDateUser(questionnaireEntity, "UPDATE");
			
			questionnaireRepository.save(questionnaireEntity);

			log.debug("QuestionnaireBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
