package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.ImputationTime;
import com.mapfre.gaia.amap3.repositories.ImputationTimeRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class ImputationTimeBLImpl implements IImputationTimeBL {

	private ImputationTimeRepository imputationTimeRepository;
	private MapperFacade mapperImputationTime;

	@Autowired
	public ImputationTimeBLImpl(ImputationTimeRepository imputationTimeRepository) {
		this.imputationTimeRepository = imputationTimeRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		mapperFactory.classMap(ImputationTime.class, ImputationTimeBO.class).byDefault().register();
		this.mapperImputationTime = mapperFactory.getMapperFacade();

	}

	@Override
	public List<ImputationTimeBO> getAll() {
		log.debug("ImputationTimeBLImpl:getAll [START]");
		
		List<ImputationTimeBO> imputationTimes = new ArrayList<ImputationTimeBO>();

		List<ImputationTime> imputationTimeEntities = imputationTimeRepository.findAll();
		for (ImputationTime imputationTimeEntity : imputationTimeEntities) {
			imputationTimes.add(mapperImputationTime.map(imputationTimeEntity, ImputationTimeBO.class));
		}
		log.debug("ImputationTimeBLImpl:getAll [END]");
		return imputationTimes;
	}

	//TODO No necesario
	@Override
	public ImputationTimeBO add(ImputationTimeBO imputationTimeBO) {
		log.debug("ImputationTimeBLImpl:add [START]");
		ImputationTime imputationTimeEntity = mapperImputationTime.map(imputationTimeBO, ImputationTime.class);

		Util.getDateUser(imputationTimeEntity, "INSERT");

		log.debug("ImputationTimeBLImpl:add [END]");
		return mapperImputationTime.map(imputationTimeRepository.save(imputationTimeEntity), ImputationTimeBO.class);
	}

	@Override
	public ImputationTimeBO update(Long imputationTimeId, ImputationTimeBO imputationTimeBO) {
		log.debug("ImputationTimeBLImpl:update [START]");
		ImputationTime imputationTimeEntity = imputationTimeRepository.getOne(imputationTimeId);
				
		if (imputationTimeEntity != null) {

			Util.getDateUser(imputationTimeEntity, "UPDATE");
			
			log.debug("ImputationTimeBLImpl:update [END]");
			return mapperImputationTime.map(imputationTimeRepository.save(imputationTimeEntity), ImputationTimeBO.class);
		}

		return null;
	}

	//TODO No necesario
	@Override
	public boolean delete(Long imputationTimeId) {
		log.debug("ImputationTimeBLImpl:delete [START]");
		ImputationTime imputationTimeEntity = imputationTimeRepository.getOne(imputationTimeId);
		if (imputationTimeEntity != null) {
			
			imputationTimeRepository.delete(imputationTimeEntity);
			
			log.debug("ImputationTimeBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
