package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Question;
import com.mapfre.gaia.amap3.repositories.QuestionRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class QuestionBLImpl implements IQuestionBL {

	private QuestionRepository questionRepository;
	private MapperFacade mapperQuestion;

	@Autowired
	public QuestionBLImpl(QuestionRepository questionRepository) {
		this.questionRepository = questionRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		mapperFactory.classMap(Question.class, QuestionBO.class).byDefault().register();
		this.mapperQuestion = mapperFactory.getMapperFacade();

	}

	@Override
	public List<QuestionBO> getAll() {
		log.debug("QuestionBLImpl:getAll [START]");
		
		List<QuestionBO> questions = new ArrayList<QuestionBO>();

		List<Question> questionEntities = questionRepository.findAll();
		for (Question questionEntity : questionEntities) {
			questions.add(mapperQuestion.map(questionEntity, QuestionBO.class));
		}
		log.debug("QuestionBLImpl:getAll [END]");
		return questions;
	}

	@Override
	public QuestionBO add(QuestionBO questionBO) {
		log.debug("QuestionBLImpl:add [START]");
		Question questionEntity = mapperQuestion.map(questionBO, Question.class);

		Util.getDateUser(questionEntity, "INSERT");

		log.debug("QuestionBLImpl:add [END]");
		return mapperQuestion.map(questionRepository.save(questionEntity), QuestionBO.class);
	}

	@Override
	public QuestionBO update(Long questionId, QuestionBO questionBO) {
		log.debug("QuestionBLImpl:update [START]");
		Question questionEntity = questionRepository.getOne(questionId);
				
		if (questionEntity != null) {

			questionEntity.setCodQuestionType(questionBO.getCodQuestionType());
			questionEntity.setIsOptionQuestion(questionBO.getIsOptionQuestion());
			questionEntity.setIsTextQuestion(questionBO.getIsTextQuestion());
			questionEntity.setTxtQuestion(questionBO.getTxtQuestion());
			
			Util.getDateUser(questionEntity, "UPDATE");
			
			log.debug("QuestionBLImpl:update [END]");
			return mapperQuestion.map(questionRepository.save(questionEntity), QuestionBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long questionId) {
		log.debug("QuestionBLImpl:delete [START]");
		Question questionEntity = questionRepository.getOne(questionId);
		if (questionEntity != null) {
						
			questionRepository.delete(questionEntity);
			
			log.debug("QuestionBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
