package com.mapfre.gaia.amap3.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapfre.gaia.amap3.entities.OrganizationalStructureCountry;

public interface OrganizationalStructureCountryRepository extends JpaRepository<OrganizationalStructureCountry, Long> {

}
