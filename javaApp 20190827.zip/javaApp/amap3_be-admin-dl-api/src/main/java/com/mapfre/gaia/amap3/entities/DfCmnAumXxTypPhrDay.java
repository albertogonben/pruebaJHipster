package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the DF_CMN_AUM_XX_TYP_PHR_DAY database table.
 * 
 */
@Entity
@Table(name="DF_CMN_AUM_XX_TYP_PHR_DAY")
@NamedQuery(name="DfCmnAumXxTypPhrDay.findAll", query="SELECT d FROM DfCmnAumXxTypPhrDay d")
public class DfCmnAumXxTypPhrDay implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="IDT_SQN")
	private BigDecimal idtSqn;

	@Temporal(TemporalType.DATE)
	@Column(name="INS_DAT")
	private Date insDat;

	@Column(name="INS_USR_VAL")
	private String insUsrVal;

	@Temporal(TemporalType.DATE)
	@Column(name="LST_PBC_DAT")
	private Date lstPbcDat;

	@Temporal(TemporalType.DATE)
	@Column(name="MDF_DAT")
	private Date mdfDat;

	@Column(name="MDF_USR_VAL")
	private String mdfUsrVal;

	@Column(name="PHR_AUT_VAL")
	private String phrAutVal;

	@Column(name="PHR_VAL")
	private String phrVal;

	public DfCmnAumXxTypPhrDay() {
	}

	public BigDecimal getIdtSqn() {
		return this.idtSqn;
	}

	public void setIdtSqn(BigDecimal idtSqn) {
		this.idtSqn = idtSqn;
	}

	public Date getInsDat() {
		return this.insDat;
	}

	public void setInsDat(Date insDat) {
		this.insDat = insDat;
	}

	public String getInsUsrVal() {
		return this.insUsrVal;
	}

	public void setInsUsrVal(String insUsrVal) {
		this.insUsrVal = insUsrVal;
	}

	public Date getLstPbcDat() {
		return this.lstPbcDat;
	}

	public void setLstPbcDat(Date lstPbcDat) {
		this.lstPbcDat = lstPbcDat;
	}

	public Date getMdfDat() {
		return this.mdfDat;
	}

	public void setMdfDat(Date mdfDat) {
		this.mdfDat = mdfDat;
	}

	public String getMdfUsrVal() {
		return this.mdfUsrVal;
	}

	public void setMdfUsrVal(String mdfUsrVal) {
		this.mdfUsrVal = mdfUsrVal;
	}

	public String getPhrAutVal() {
		return this.phrAutVal;
	}

	public void setPhrAutVal(String phrAutVal) {
		this.phrAutVal = phrAutVal;
	}

	public String getPhrVal() {
		return this.phrVal;
	}

	public void setPhrVal(String phrVal) {
		this.phrVal = phrVal;
	}

}