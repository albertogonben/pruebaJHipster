package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the TYPE_CHANGE database table.
 * 
 */
@Entity
@Table(name="TYPE_CHANGE")
@NamedQuery(name="TypeChange.findAll", query="SELECT t FROM TypeChange t")
public class TypeChange implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_CHANGE_IDTYPECHANGEPK_GENERATOR", sequenceName="TYP_CHA_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_CHANGE_IDTYPECHANGEPK_GENERATOR")
	@Column(name="ID_TYPE_CHANGE_PK")
	private long idTypeChangePk;

	@Column(name="COD_TYPE_CHANGE")
	private String codTypeChange;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_CHANGE")
	private Date dateChange;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_TYPE_CURRENCY_FK")
	private Currency currency;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="NRM_CHANGE")
	private BigDecimal nrmChange;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public TypeChange() {
	}

	public long getIdTypeChangePk() {
		return this.idTypeChangePk;
	}

	public void setIdTypeChangePk(long idTypeChangePk) {
		this.idTypeChangePk = idTypeChangePk;
	}

	public String getCodTypeChange() {
		return this.codTypeChange;
	}

	public void setCodTypeChange(String codTypeChange) {
		this.codTypeChange = codTypeChange;
	}

	public Date getDateChange() {
		return this.dateChange;
	}

	public void setDateChange(Date dateChange) {
		this.dateChange = dateChange;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Currency getCurrency() {
		return this.currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public BigDecimal getNrmChange() {
		return this.nrmChange;
	}

	public void setNrmChange(BigDecimal nrmChange) {
		this.nrmChange = nrmChange;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}