package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the "PARAMETER" database table.
 * 
 */
@Entity
@Table(name="PARAMETER")
@NamedQuery(name="Parameter.findAll", query="SELECT p FROM Parameter p")
public class Parameter implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PARAMETER_IDPARAMETERPK_GENERATOR", sequenceName="PAR_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PARAMETER_IDPARAMETERPK_GENERATOR")
	@Column(name="ID_PARAMETER_PK")
	private long idParameterPk;

	@Column(name="CDGO_PARAMETER")
	private String cdgoParameter;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_COMMENT")
	private String txtComment;

	@Column(name="TXT_VALOR")
	private String txtValor;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public Parameter() {
	}

	public long getIdParameterPk() {
		return this.idParameterPk;
	}

	public void setIdParameterPk(long idParameterPk) {
		this.idParameterPk = idParameterPk;
	}

	public String getCdgoParameter() {
		return this.cdgoParameter;
	}

	public void setCdgoParameter(String cdgoParameter) {
		this.cdgoParameter = cdgoParameter;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtComment() {
		return this.txtComment;
	}

	public void setTxtComment(String txtComment) {
		this.txtComment = txtComment;
	}

	public String getTxtValor() {
		return this.txtValor;
	}

	public void setTxtValor(String txtValor) {
		this.txtValor = txtValor;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}