package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the PROCESS_UNIT_BUSINESS database table.
 * 
 */
@Entity
@Table(name = "PROCESS_UNIT_BUSINESS")
@NamedQuery(name = "ProcessUnitBusiness.findAll", query = "SELECT p FROM ProcessUnitBusiness p")
public class ProcessUnitBusiness implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "PROCESS_UNIT_BUSINESS_GENERATOR", sequenceName = "PRO_UNI_BUS_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PROCESS_UNIT_BUSINESS_GENERATOR")
	@Column(name = "ID_PROCESS_PK")
	private long idProcessPk;

	@Column(name = "CD_PROCESS")
	private String cdProcess;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name = "DATE_VERSION")
	private Date dateVersion;

	@Column(name = "NMR_VERSION")
	private BigDecimal nmrVersion;

	@Column(name = "TXT_NAME")
	private String txtName;

	@Column(name = "USER_INSERT")
	private String userInsert;

	@Column(name = "USER_UPDATE")
	private String userUpdate;

	// bi-directional many-to-one association to TypeProcess
	@ManyToOne
	@JoinColumn(name = "ID_TYPE_PROCESS_FK")
	private TypeProcess typeProcess;

	// bi-directional many-to-one association to ProcessCountry
//	@OneToMany(mappedBy="processUnitBusiness")
//	private List<ProcessCountry> processCountries;

	// bi-directional many-to-one association to ProcessUnitBusiness
	@ManyToOne(optional=true)
	@JoinColumn(name = "ID_PROCESS_FATHER_FK", nullable=true)
	private ProcessUnitBusiness processUnitBusiness;

	// bi-directional many-to-one association to ProcessUnitBusiness
//	@OneToMany(mappedBy="processUnitBusiness")
//	private List<ProcessUnitBusiness> processUnitBusinesses;

	// bi-directional many-to-one association to UnitBusiness
	@ManyToOne
	@JoinColumn(name = "ID_UNIT_BUSINESS_FK")
	private UnitBusiness unitBusiness;

	public ProcessUnitBusiness() {
	}

	public long getIdProcessPk() {
		return this.idProcessPk;
	}

	public void setIdProcessPk(long idProcessPk) {
		this.idProcessPk = idProcessPk;
	}

	public String getCdProcess() {
		return this.cdProcess;
	}

	public void setCdProcess(String cdProcess) {
		this.cdProcess = cdProcess;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}

	public TypeProcess getTypeProcess() {
		return this.typeProcess;
	}

	public void setTypeProcess(TypeProcess typeProcess) {
		this.typeProcess = typeProcess;
	}

	public BigDecimal getNmrVersion() {
		return this.nmrVersion;
	}

	public void setNmrVersion(BigDecimal nmrVersion) {
		this.nmrVersion = nmrVersion;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

//	public List<ProcessCountry> getProcessCountries() {
//		return this.processCountries;
//	}
//
//	public void setProcessCountries(List<ProcessCountry> processCountries) {
//		this.processCountries = processCountries;
//	}
//
//	public ProcessCountry addProcessCountry(ProcessCountry processCountry) {
//		getProcessCountries().add(processCountry);
//		processCountry.setProcessUnitBusiness(this);
//
//		return processCountry;
//	}
//
//	public ProcessCountry removeProcessCountry(ProcessCountry processCountry) {
//		getProcessCountries().remove(processCountry);
//		processCountry.setProcessUnitBusiness(null);
//
//		return processCountry;
//	}

	public ProcessUnitBusiness getProcessUnitBusiness() {
		return this.processUnitBusiness;
	}

	public void setProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness) {
		this.processUnitBusiness = processUnitBusiness;
	}

//	public List<ProcessUnitBusiness> getProcessUnitBusinesses() {
//		return this.processUnitBusinesses;
//	}
//
//	public void setProcessUnitBusinesses(List<ProcessUnitBusiness> processUnitBusinesses) {
//		this.processUnitBusinesses = processUnitBusinesses;
//	}
//
//	public ProcessUnitBusiness addProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness) {
//		getProcessUnitBusinesses().add(processUnitBusiness);
//		processUnitBusiness.setProcessUnitBusiness(this);
//
//		return processUnitBusiness;
//	}
//
//	public ProcessUnitBusiness removeProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness) {
//		getProcessUnitBusinesses().remove(processUnitBusiness);
//		processUnitBusiness.setProcessUnitBusiness(null);
//
//		return processUnitBusiness;
//	}

	public UnitBusiness getUnitBusiness() {
		return this.unitBusiness;
	}

	public void setUnitBusiness(UnitBusiness unitBusiness) {
		this.unitBusiness = unitBusiness;
	}

}