package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the USER_LANGUAGE database table.
 * 
 */
@Entity
@Table(name="USER_LANGUAGE")
@NamedQuery(name="UserLanguage.findAll", query="SELECT u FROM UserLanguage u")
public class UserLanguage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_USER_LANGUAGE_PK")
	private long idUserLanguagePk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_COMMENT")
	private String txtComment;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Language
	@ManyToOne
	@JoinColumn(name="ID_LANGUAGE_FK")
	private Language language;

	//bi-directional many-to-one association to TypeLevelLanguage
	@ManyToOne
	@JoinColumn(name="ID_LEVEL_LANGUAGE_FK")
	private TypeLevelLanguage typeLevelLanguage;

	//bi-directional many-to-one association to UserAmap
	@ManyToOne
	@JoinColumn(name="ID_USER_FK")
	private UserAmap userAmap;

	public UserLanguage() {
	}

	public long getIdUserLanguagePk() {
		return this.idUserLanguagePk;
	}

	public void setIdUserLanguagePk(long idUserLanguagePk) {
		this.idUserLanguagePk = idUserLanguagePk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtComment() {
		return this.txtComment;
	}

	public void setTxtComment(String txtComment) {
		this.txtComment = txtComment;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Language getLanguage() {
		return this.language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}

	public TypeLevelLanguage getTypeLevelLanguage() {
		return this.typeLevelLanguage;
	}

	public void setTypeLevelLanguage(TypeLevelLanguage typeLevelLanguage) {
		this.typeLevelLanguage = typeLevelLanguage;
	}

	public UserAmap getUserAmap() {
		return this.userAmap;
	}

	public void setUserAmap(UserAmap userAmap) {
		this.userAmap = userAmap;
	}

}