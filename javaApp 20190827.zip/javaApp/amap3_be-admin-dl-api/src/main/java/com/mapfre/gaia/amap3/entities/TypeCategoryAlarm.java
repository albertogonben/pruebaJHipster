package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_CATEGORY_ALARM database table.
 * 
 */
@Entity
@Table(name="TYPE_CATEGORY_ALARM")
@NamedQuery(name="TypeCategoryAlarm.findAll", query="SELECT t FROM TypeCategoryAlarm t")
public class TypeCategoryAlarm implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_TYPE_CATEGORY_ALARM_PK")
	private long idTypeCategoryAlarmPk;

	@Column(name="CD_TYPE_CATEGORY_ALARM")
	private String cdTypeCategoryAlarm;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_TYPE_CATEGORY_ALARM")
	private String txtTypeCategoryAlarm;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to TypeAlarm
	@OneToMany(mappedBy="typeCategoryAlarm")
	private List<TypeAlarm> typeAlarms;

	public TypeCategoryAlarm() {
	}

	public long getIdTypeCategoryAlarmPk() {
		return this.idTypeCategoryAlarmPk;
	}

	public void setIdTypeCategoryAlarmPk(long idTypeCategoryAlarmPk) {
		this.idTypeCategoryAlarmPk = idTypeCategoryAlarmPk;
	}

	public String getCdTypeCategoryAlarm() {
		return this.cdTypeCategoryAlarm;
	}

	public void setCdTypeCategoryAlarm(String cdTypeCategoryAlarm) {
		this.cdTypeCategoryAlarm = cdTypeCategoryAlarm;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtTypeCategoryAlarm() {
		return this.txtTypeCategoryAlarm;
	}

	public void setTxtTypeCategoryAlarm(String txtTypeCategoryAlarm) {
		this.txtTypeCategoryAlarm = txtTypeCategoryAlarm;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<TypeAlarm> getTypeAlarms() {
		return this.typeAlarms;
	}

	public void setTypeAlarms(List<TypeAlarm> typeAlarms) {
		this.typeAlarms = typeAlarms;
	}

	public TypeAlarm addTypeAlarm(TypeAlarm typeAlarm) {
		getTypeAlarms().add(typeAlarm);
		typeAlarm.setTypeCategoryAlarm(this);

		return typeAlarm;
	}

	public TypeAlarm removeTypeAlarm(TypeAlarm typeAlarm) {
		getTypeAlarms().remove(typeAlarm);
		typeAlarm.setTypeCategoryAlarm(null);

		return typeAlarm;
	}

}