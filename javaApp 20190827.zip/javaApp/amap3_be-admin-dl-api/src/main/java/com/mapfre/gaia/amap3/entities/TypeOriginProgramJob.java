package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_ORIGIN_PROGRAM_JOB database table.
 * 
 */
@Entity
@Table(name="TYPE_ORIGIN_PROGRAM_JOB")
@NamedQuery(name="TypeOriginProgramJob.findAll", query="SELECT t FROM TypeOriginProgramJob t")
public class TypeOriginProgramJob implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_TYPE_ORIGIN_PK")
	private long idTypeOriginPk;

	@Column(name="CD_TYPE_ORIGIN")
	private String cdTypeOrigin;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_TYPE_ORIGIN")
	private String txtTypeOrigin;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to ProgramJob
	@OneToMany(mappedBy="typeOriginProgramJob")
	private List<ProgramJob> programJobs;

	public TypeOriginProgramJob() {
	}

	public long getIdTypeOriginPk() {
		return this.idTypeOriginPk;
	}

	public void setIdTypeOriginPk(long idTypeOriginPk) {
		this.idTypeOriginPk = idTypeOriginPk;
	}

	public String getCdTypeOrigin() {
		return this.cdTypeOrigin;
	}

	public void setCdTypeOrigin(String cdTypeOrigin) {
		this.cdTypeOrigin = cdTypeOrigin;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtTypeOrigin() {
		return this.txtTypeOrigin;
	}

	public void setTxtTypeOrigin(String txtTypeOrigin) {
		this.txtTypeOrigin = txtTypeOrigin;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<ProgramJob> getProgramJobs() {
		return this.programJobs;
	}

	public void setProgramJobs(List<ProgramJob> programJobs) {
		this.programJobs = programJobs;
	}

	public ProgramJob addProgramJob(ProgramJob programJob) {
		getProgramJobs().add(programJob);
		programJob.setTypeOriginProgramJob(this);

		return programJob;
	}

	public ProgramJob removeProgramJob(ProgramJob programJob) {
		getProgramJobs().remove(programJob);
		programJob.setTypeOriginProgramJob(null);

		return programJob;
	}

}