package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the COUNTRY database table.
 * 
 */
@Entity
@NamedQuery(name="Country.findAll", query="SELECT c FROM Country c")
public class Country implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="COUNTRY_IDCOUNTRYPK_GENERATOR", sequenceName="COU_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="COUNTRY_IDCOUNTRYPK_GENERATOR")
	@Column(name="ID_COUNTRY_PK")
	private long idCountryPk;

	@Column(name="CD_COUNTRY")
	private String cdCountry;

	@Column(name="CD_ISO")
	private String cdIso;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Currency
	@ManyToOne
	@JoinColumn(name="ID_CURRENCY_FK")
	private Currency currency;

	//bi-directional many-to-one association to Region
	@ManyToOne
	@JoinColumn(name="ID_REGION_FK")
	private Region region;

//	//bi-directional many-to-one association to Entamap
//	@OneToMany(mappedBy="country")
//	private List<Entamap> entamaps;
//
//	//bi-directional many-to-one association to MatrixRisk
//	@OneToMany(mappedBy="country")
//	private List<MatrixRisk> matrixRisks;
//
//	//bi-directional many-to-one association to OrganizationalStructure
//	@OneToMany(mappedBy="country")
//	private List<OrganizationalStructure> organizationalStructures;
//
//	//bi-directional many-to-one association to ProcessCountry
//	@OneToMany(mappedBy="country")
//	private List<ProcessCountry> processCountries;

	public Country() {
	}

	public long getIdCountryPk() {
		return this.idCountryPk;
	}

	public void setIdCountryPk(long idCountryPk) {
		this.idCountryPk = idCountryPk;
	}

	public String getCdCountry() {
		return this.cdCountry;
	}

	public void setCdCountry(String cdCountry) {
		this.cdCountry = cdCountry;
	}

	public String getCdIso() {
		return this.cdIso;
	}

	public void setCdIso(String cdIso) {
		this.cdIso = cdIso;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Currency getCurrency() {
		return this.currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public Region getRegion() {
		return this.region;
	}

	public void setRegion(Region region) {
		this.region = region;
	}

//	public List<Entamap> getEntamaps() {
//		return this.entamaps;
//	}
//
//	public void setEntamaps(List<Entamap> entamaps) {
//		this.entamaps = entamaps;
//	}
//
//	public Entamap addEntamap(Entamap entamap) {
//		getEntamaps().add(entamap);
//		entamap.setCountry(this);
//
//		return entamap;
//	}
//
//	public Entamap removeEntamap(Entamap entamap) {
//		getEntamaps().remove(entamap);
//		entamap.setCountry(null);
//
//		return entamap;
//	}
//
//	public List<MatrixRisk> getMatrixRisks() {
//		return this.matrixRisks;
//	}
//
//	public void setMatrixRisks(List<MatrixRisk> matrixRisks) {
//		this.matrixRisks = matrixRisks;
//	}
//
//	public MatrixRisk addMatrixRisk(MatrixRisk matrixRisk) {
//		getMatrixRisks().add(matrixRisk);
//		matrixRisk.setCountry(this);
//
//		return matrixRisk;
//	}
//
//	public MatrixRisk removeMatrixRisk(MatrixRisk matrixRisk) {
//		getMatrixRisks().remove(matrixRisk);
//		matrixRisk.setCountry(null);
//
//		return matrixRisk;
//	}
//
//	public List<OrganizationalStructure> getOrganizationalStructures() {
//		return this.organizationalStructures;
//	}
//
//	public void setOrganizationalStructures(List<OrganizationalStructure> organizationalStructures) {
//		this.organizationalStructures = organizationalStructures;
//	}
//
//	public OrganizationalStructure addOrganizationalStructure(OrganizationalStructure organizationalStructure) {
//		getOrganizationalStructures().add(organizationalStructure);
//		organizationalStructure.setCountry(this);
//
//		return organizationalStructure;
//	}
//
//	public OrganizationalStructure removeOrganizationalStructure(OrganizationalStructure organizationalStructure) {
//		getOrganizationalStructures().remove(organizationalStructure);
//		organizationalStructure.setCountry(null);
//
//		return organizationalStructure;
//	}
//
//	public List<ProcessCountry> getProcessCountries() {
//		return this.processCountries;
//	}
//
//	public void setProcessCountries(List<ProcessCountry> processCountries) {
//		this.processCountries = processCountries;
//	}
//
//	public ProcessCountry addProcessCountry(ProcessCountry processCountry) {
//		getProcessCountries().add(processCountry);
//		processCountry.setCountry(this);
//
//		return processCountry;
//	}
//
//	public ProcessCountry removeProcessCountry(ProcessCountry processCountry) {
//		getProcessCountries().remove(processCountry);
//		processCountry.setCountry(null);
//
//		return processCountry;
//	}

}