package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the TYPE_PROCESS database table.
 * 
 */
@Entity
@Table(name="TYPE_PROCESS")
@NamedQuery(name="TypeProcess.findAll", query="SELECT t FROM TypeProcess t")
public class TypeProcess implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_PROCESS_GENERATOR", sequenceName="TYP_PRO_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_PROCESS_GENERATOR")
	@Column(name="ID_TYPE_PROCESS_PK")
	private long idTypeProcessPk;

	@Column(name="CD_TYPE_PROCESS")
	private String cdTypeProcess;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_DESCRIPTION")
	private String txtDescription;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public TypeProcess() {
	}

	public long getIdTypeProcessPk() {
		return this.idTypeProcessPk;
	}

	public void setIdTypeProcessPk(long idTypeProcessPk) {
		this.idTypeProcessPk = idTypeProcessPk;
	}

	public String getCdTypeProcess() {
		return this.cdTypeProcess;
	}

	public void setCdTypeProcess(String cdTypeProcess) {
		this.cdTypeProcess = cdTypeProcess;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtDescription() {
		return this.txtDescription;
	}

	public void setTxtDescription(String txtDescription) {
		this.txtDescription = txtDescription;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}