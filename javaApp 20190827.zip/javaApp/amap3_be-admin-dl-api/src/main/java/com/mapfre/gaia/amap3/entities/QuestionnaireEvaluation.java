package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the QUESTIONNAIRE_EVALUATION database table.
 * 
 */
@Entity
@Table(name="QUESTIONNAIRE_EVALUATION")
@NamedQuery(name="QuestionnaireEvaluation.findAll", query="SELECT q FROM QuestionnaireEvaluation q")
public class QuestionnaireEvaluation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="QUESTIONNAIRE_EVALUATION_IDEVALUACIONPK_GENERATOR", sequenceName="QUESTIONNAIRE_EVALUATION_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="QUESTIONNAIRE_EVALUATION_IDEVALUACIONPK_GENERATOR")
	@Column(name="ID_EVALUACION_PK")
	private long idEvaluacionPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_CUMPLIMENTATION")
	private Date dateCumplimentation;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_EMISION")
	private Date dateEmision;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_READING")
	private Date dateReading;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="ID_JOB_FK")
	private BigDecimal idJobFk;

	@Column(name="ID_USER_COMPLIANT")
	private BigDecimal idUserCompliant;

	@Column(name="ID_USER_EVALUATION")
	private BigDecimal idUserEvaluation;

	@Column(name="NRM_EVALUATION")
	private BigDecimal nrmEvaluation;

	@Column(name="TXT_EVALUATION")
	private String txtEvaluation;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to QuestionnaireQuestion
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_TYPE_QUESTIONNAIRE_QUESTION_FK")
	private QuestionnaireQuestion questionnaireQuestion;

	public QuestionnaireEvaluation() {
	}

	public long getIdEvaluacionPk() {
		return this.idEvaluacionPk;
	}

	public void setIdEvaluacionPk(long idEvaluacionPk) {
		this.idEvaluacionPk = idEvaluacionPk;
	}

	public Date getDateCumplimentation() {
		return this.dateCumplimentation;
	}

	public void setDateCumplimentation(Date dateCumplimentation) {
		this.dateCumplimentation = dateCumplimentation;
	}

	public Date getDateEmision() {
		return this.dateEmision;
	}

	public void setDateEmision(Date dateEmision) {
		this.dateEmision = dateEmision;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateReading() {
		return this.dateReading;
	}

	public void setDateReading(Date dateReading) {
		this.dateReading = dateReading;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getIdJobFk() {
		return this.idJobFk;
	}

	public void setIdJobFk(BigDecimal idJobFk) {
		this.idJobFk = idJobFk;
	}

	public BigDecimal getIdUserCompliant() {
		return this.idUserCompliant;
	}

	public void setIdUserCompliant(BigDecimal idUserCompliant) {
		this.idUserCompliant = idUserCompliant;
	}

	public BigDecimal getIdUserEvaluation() {
		return this.idUserEvaluation;
	}

	public void setIdUserEvaluation(BigDecimal idUserEvaluation) {
		this.idUserEvaluation = idUserEvaluation;
	}

	public BigDecimal getNrmEvaluation() {
		return this.nrmEvaluation;
	}

	public void setNrmEvaluation(BigDecimal nrmEvaluation) {
		this.nrmEvaluation = nrmEvaluation;
	}

	public String getTxtEvaluation() {
		return this.txtEvaluation;
	}

	public void setTxtEvaluation(String txtEvaluation) {
		this.txtEvaluation = txtEvaluation;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public QuestionnaireQuestion getQuestionnaireQuestion() {
		return this.questionnaireQuestion;
	}

	public void setQuestionnaireQuestion(QuestionnaireQuestion questionnaireQuestion) {
		this.questionnaireQuestion = questionnaireQuestion;
	}

}