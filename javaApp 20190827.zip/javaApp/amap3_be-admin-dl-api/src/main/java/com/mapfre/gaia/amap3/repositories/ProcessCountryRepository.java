package com.mapfre.gaia.amap3.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapfre.gaia.amap3.entities.ProcessCountry;
import com.mapfre.gaia.amap3.entities.ProcessUnitBusiness;

public interface ProcessCountryRepository extends JpaRepository<ProcessCountry, Long> {

	List<ProcessCountry> findByProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness);

}
