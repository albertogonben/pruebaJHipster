package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PREDICTION_PERSONNEL database table.
 * 
 */
@Entity
@Table(name="PREDICTION_PERSONNEL")
@NamedQuery(name="PredictionPersonnel.findAll", query="SELECT p FROM PredictionPersonnel p")
public class PredictionPersonnel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_PREDICTION_PERSONNEL_PK")
	private long idPredictionPersonnelPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="NMR_EXERCIESE")
	private BigDecimal nmrExerciese;

	@Column(name="TXT_COMMENTS")
	private String txtComments;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Pai
	@OneToMany(mappedBy="predictionPersonnel")
	private List<Pai> pais;

	//bi-directional many-to-one association to OrganizationalStructure
	@ManyToOne
	@JoinColumn(name="ID_ORGANIZATIONAL_STRUCTURE_FK")
	private OrganizationalStructure organizationalStructure;

	public PredictionPersonnel() {
	}

	public long getIdPredictionPersonnelPk() {
		return this.idPredictionPersonnelPk;
	}

	public void setIdPredictionPersonnelPk(long idPredictionPersonnelPk) {
		this.idPredictionPersonnelPk = idPredictionPersonnelPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getNmrExerciese() {
		return this.nmrExerciese;
	}

	public void setNmrExerciese(BigDecimal nmrExerciese) {
		this.nmrExerciese = nmrExerciese;
	}

	public String getTxtComments() {
		return this.txtComments;
	}

	public void setTxtComments(String txtComments) {
		this.txtComments = txtComments;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<Pai> getPais() {
		return this.pais;
	}

	public void setPais(List<Pai> pais) {
		this.pais = pais;
	}

	public Pai addPai(Pai pai) {
		getPais().add(pai);
		pai.setPredictionPersonnel(this);

		return pai;
	}

	public Pai removePai(Pai pai) {
		getPais().remove(pai);
		pai.setPredictionPersonnel(null);

		return pai;
	}

	public OrganizationalStructure getOrganizationalStructure() {
		return this.organizationalStructure;
	}

	public void setOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		this.organizationalStructure = organizationalStructure;
	}

}