package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the GUIDE_JOB database table.
 * 
 */
@Entity
@Table(name="GUIDE_JOB")
@NamedQuery(name="GuideJob.findAll", query="SELECT g FROM GuideJob g")
public class GuideJob implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "GUIDE_JOB_GENERATOR", sequenceName = "GUI_JOB_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "GUIDE_JOB_GENERATOR")
	@Column(name="ID_NODE_PK")
	private long idNodePk;

	@Column(name="CD_NODE")
	private String cdNode;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_USE")
	private Date dateUse;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_VERSION")
	private Date dateVersion;

	@Column(name="NM_VERSION")
	private BigDecimal nmVersion;

	@Column(name="NMR_USES")
	private BigDecimal nmrUses;

	@Column(name="TXT_NAME_GUIDE")
	private String txtNameGuide;

	@Column(name="TXT_NODE")
	private String txtNode;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to GuideJob
	@ManyToOne
	@JoinColumn(name="ID_NODE_FATHER_FK")
	private GuideJob guideJob;

	//bi-directional many-to-one association to GuideJob
//	@OneToMany(mappedBy="guideJob")
//	private List<GuideJob> guideJobs;

	//bi-directional many-to-one association to TypeNode
	@ManyToOne
	@JoinColumn(name="ID_TYPE_NODE_FK")
	private TypeNode typeNode;

	//bi-directional many-to-one association to Task
//	@OneToMany(mappedBy="guideJob")
//	private List<Task> tasks;

	public GuideJob() {
	}

	public long getIdNodePk() {
		return this.idNodePk;
	}

	public void setIdNodePk(long idNodePk) {
		this.idNodePk = idNodePk;
	}

	public String getCdNode() {
		return this.cdNode;
	}

	public void setCdNode(String cdNode) {
		this.cdNode = cdNode;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getDateUse() {
		return this.dateUse;
	}

	public void setDateUse(Date dateUse) {
		this.dateUse = dateUse;
	}

	public Date getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}

	public BigDecimal getNmVersion() {
		return this.nmVersion;
	}

	public void setNmVersion(BigDecimal nmVersion) {
		this.nmVersion = nmVersion;
	}

	public BigDecimal getNmrUses() {
		return this.nmrUses;
	}

	public void setNmrUses(BigDecimal nmrUses) {
		this.nmrUses = nmrUses;
	}

	public String getTxtNameGuide() {
		return this.txtNameGuide;
	}

	public void setTxtNameGuide(String txtNameGuide) {
		this.txtNameGuide = txtNameGuide;
	}

	public String getTxtNode() {
		return this.txtNode;
	}

	public void setTxtNode(String txtNode) {
		this.txtNode = txtNode;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public GuideJob getGuideJob() {
		return this.guideJob;
	}

	public void setGuideJob(GuideJob guideJob) {
		this.guideJob = guideJob;
	}

//	public List<GuideJob> getGuideJobs() {
//		return this.guideJobs;
//	}
//
//	public void setGuideJobs(List<GuideJob> guideJobs) {
//		this.guideJobs = guideJobs;
//	}
//
//	public GuideJob addGuideJob(GuideJob guideJob) {
//		getGuideJobs().add(guideJob);
//		guideJob.setGuideJob(this);
//
//		return guideJob;
//	}
//
//	public GuideJob removeGuideJob(GuideJob guideJob) {
//		getGuideJobs().remove(guideJob);
//		guideJob.setGuideJob(null);
//
//		return guideJob;
//	}

	public TypeNode getTypeNode() {
		return this.typeNode;
	}

	public void setTypeNode(TypeNode typeNode) {
		this.typeNode = typeNode;
	}

//	public List<Task> getTasks() {
//		return this.tasks;
//	}
//
//	public void setTasks(List<Task> tasks) {
//		this.tasks = tasks;
//	}
//
//	public Task addTask(Task task) {
//		getTasks().add(task);
//		task.setGuideJob(this);
//
//		return task;
//	}
//
//	public Task removeTask(Task task) {
//		getTasks().remove(task);
//		task.setGuideJob(null);
//
//		return task;
//	}

}