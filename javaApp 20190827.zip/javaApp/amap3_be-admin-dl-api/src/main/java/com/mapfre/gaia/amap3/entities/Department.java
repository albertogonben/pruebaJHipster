package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the DEPARTMENT database table.
 * 
 */
@Entity
@NamedQuery(name="Department.findAll", query="SELECT d FROM Department d")
public class Department implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_DEPARTMENT_PK")
	private long idDepartmentPk;

	@Column(name="CD_DEPARTMENT")
	private String cdDepartment;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_DEPARTMENT")
	private String txtDepartment;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to UserAmap
//	@OneToMany(mappedBy="department")
//	private List<UserAmap> userAmaps;

	public Department() {
	}

	public long getIdDepartmentPk() {
		return this.idDepartmentPk;
	}

	public void setIdDepartmentPk(long idDepartmentPk) {
		this.idDepartmentPk = idDepartmentPk;
	}

	public String getCdDepartment() {
		return this.cdDepartment;
	}

	public void setCdDepartment(String cdDepartment) {
		this.cdDepartment = cdDepartment;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtDepartment() {
		return this.txtDepartment;
	}

	public void setTxtDepartment(String txtDepartment) {
		this.txtDepartment = txtDepartment;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

//	public List<UserAmap> getUserAmaps() {
//		return this.userAmaps;
//	}
//
//	public void setUserAmaps(List<UserAmap> userAmaps) {
//		this.userAmaps = userAmaps;
//	}
//
//	public UserAmap addUserAmap(UserAmap userAmap) {
//		getUserAmaps().add(userAmap);
//		userAmap.setDepartment(this);
//
//		return userAmap;
//	}
//
//	public UserAmap removeUserAmap(UserAmap userAmap) {
//		getUserAmaps().remove(userAmap);
//		userAmap.setDepartment(null);
//
//		return userAmap;
//	}

}