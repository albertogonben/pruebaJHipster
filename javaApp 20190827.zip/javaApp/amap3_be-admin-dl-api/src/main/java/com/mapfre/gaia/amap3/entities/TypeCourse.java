package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TYPE_COURSE database table.
 * 
 */
@Entity
@Table(name="TYPE_COURSE")
@NamedQuery(name="TypeCourse.findAll", query="SELECT t FROM TypeCourse t")
public class TypeCourse implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_TYPE_COURSE_PK")
	private long idTypeCoursePk;

	@Column(name="CD_TYPE_COURSE")
	private String cdTypeCourse;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_TYPE_COURSE")
	private String txtTypeCourse;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public TypeCourse() {
	}

	public long getIdTypeCoursePk() {
		return this.idTypeCoursePk;
	}

	public void setIdTypeCoursePk(long idTypeCoursePk) {
		this.idTypeCoursePk = idTypeCoursePk;
	}

	public String getCdTypeCourse() {
		return this.cdTypeCourse;
	}

	public void setCdTypeCourse(String cdTypeCourse) {
		this.cdTypeCourse = cdTypeCourse;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtTypeCourse() {
		return this.txtTypeCourse;
	}

	public void setTxtTypeCourse(String txtTypeCourse) {
		this.txtTypeCourse = txtTypeCourse;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}