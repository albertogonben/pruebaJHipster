package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_CATEGORY_PROFESSIONAL database table.
 * 
 */
@Entity
@Table(name="TYPE_CATEGORY_PROFESSIONAL")
@NamedQuery(name="TypeCategoryProfessional.findAll", query="SELECT t FROM TypeCategoryProfessional t")
public class TypeCategoryProfessional implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_TYPE_CATEGORY_PK")
	private long idTypeCategoryPk;

	@Column(name="CD_TYPE_CATEGORY")
	private String cdTypeCategory;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="IS_BOSS")
	private BigDecimal isBoss;

	@Column(name="NMR_LEVEL")
	private String nmrLevel;

	@Column(name="NMR_ORDER")
	private String nmrOrder;

	@Column(name="TXT_TYPE_CATEGORY")
	private String txtTypeCategory;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to UserCategory
	@OneToMany(mappedBy="typeCategoryProfessional")
	private List<UserCategory> userCategories;

	public TypeCategoryProfessional() {
	}

	public long getIdTypeCategoryPk() {
		return this.idTypeCategoryPk;
	}

	public void setIdTypeCategoryPk(long idTypeCategoryPk) {
		this.idTypeCategoryPk = idTypeCategoryPk;
	}

	public String getCdTypeCategory() {
		return this.cdTypeCategory;
	}

	public void setCdTypeCategory(String cdTypeCategory) {
		this.cdTypeCategory = cdTypeCategory;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getIsBoss() {
		return this.isBoss;
	}

	public void setIsBoss(BigDecimal isBoss) {
		this.isBoss = isBoss;
	}

	public String getNmrLevel() {
		return this.nmrLevel;
	}

	public void setNmrLevel(String nmrLevel) {
		this.nmrLevel = nmrLevel;
	}

	public String getNmrOrder() {
		return this.nmrOrder;
	}

	public void setNmrOrder(String nmrOrder) {
		this.nmrOrder = nmrOrder;
	}

	public String getTxtTypeCategory() {
		return this.txtTypeCategory;
	}

	public void setTxtTypeCategory(String txtTypeCategory) {
		this.txtTypeCategory = txtTypeCategory;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<UserCategory> getUserCategories() {
		return this.userCategories;
	}

	public void setUserCategories(List<UserCategory> userCategories) {
		this.userCategories = userCategories;
	}

	public UserCategory addUserCategory(UserCategory userCategory) {
		getUserCategories().add(userCategory);
		userCategory.setTypeCategoryProfessional(this);

		return userCategory;
	}

	public UserCategory removeUserCategory(UserCategory userCategory) {
		getUserCategories().remove(userCategory);
		userCategory.setTypeCategoryProfessional(null);

		return userCategory;
	}

}