package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the USER_ALARM database table.
 * 
 */
@Entity
@Table(name="USER_ALARM")
@NamedQuery(name="UserAlarm.findAll", query="SELECT u FROM UserAlarm u")
public class UserAlarm implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_ALARM_PK")
	private long idAlarmPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_ADMISSION")
	private Date dateAdmission;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_FINISHED")
	private Date dateFinished;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_MATURITY")
	private Date dateMaturity;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_READING")
	private Date dateReading;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_FREE")
	private String txtFree;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to TypeAlarm
	@ManyToOne
	@JoinColumn(name="ID_TYPE_ALARM_FK")
	private TypeAlarm typeAlarm;

	//bi-directional many-to-one association to TypeCriquiteAlarm
	@ManyToOne
	@JoinColumn(name="ID_TYPE_CRITIQUE_ALARM_FK")
	private TypeCriquiteAlarm typeCriquiteAlarm;

	//bi-directional many-to-one association to UserAmap
	@ManyToOne
	@JoinColumn(name="ID_USER_FK")
	private UserAmap userAmap;

	public UserAlarm() {
	}

	public long getIdAlarmPk() {
		return this.idAlarmPk;
	}

	public void setIdAlarmPk(long idAlarmPk) {
		this.idAlarmPk = idAlarmPk;
	}

	public Date getDateAdmission() {
		return this.dateAdmission;
	}

	public void setDateAdmission(Date dateAdmission) {
		this.dateAdmission = dateAdmission;
	}

	public Date getDateFinished() {
		return this.dateFinished;
	}

	public void setDateFinished(Date dateFinished) {
		this.dateFinished = dateFinished;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateMaturity() {
		return this.dateMaturity;
	}

	public void setDateMaturity(Date dateMaturity) {
		this.dateMaturity = dateMaturity;
	}

	public Date getDateReading() {
		return this.dateReading;
	}

	public void setDateReading(Date dateReading) {
		this.dateReading = dateReading;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtFree() {
		return this.txtFree;
	}

	public void setTxtFree(String txtFree) {
		this.txtFree = txtFree;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public TypeAlarm getTypeAlarm() {
		return this.typeAlarm;
	}

	public void setTypeAlarm(TypeAlarm typeAlarm) {
		this.typeAlarm = typeAlarm;
	}

	public TypeCriquiteAlarm getTypeCriquiteAlarm() {
		return this.typeCriquiteAlarm;
	}

	public void setTypeCriquiteAlarm(TypeCriquiteAlarm typeCriquiteAlarm) {
		this.typeCriquiteAlarm = typeCriquiteAlarm;
	}

	public UserAmap getUserAmap() {
		return this.userAmap;
	}

	public void setUserAmap(UserAmap userAmap) {
		this.userAmap = userAmap;
	}

}