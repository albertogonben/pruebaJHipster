package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the QUESTIONNAIRE_QUESTION database table.
 * 
 */
@Entity
@Table(name="QUESTIONNAIRE_QUESTION")
@NamedQuery(name="QuestionnaireQuestion.findAll", query="SELECT q FROM QuestionnaireQuestion q")
public class QuestionnaireQuestion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="QUESTIONNAIRE_QUESTION_IDQUESTIONNAIREQUESTIONPK_GENERATOR", sequenceName="QUE_QUE_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="QUESTIONNAIRE_QUESTION_IDQUESTIONNAIREQUESTIONPK_GENERATOR")
	@Column(name="ID_QUESTIONNAIRE_QUESTION_PK")
	private long idQuestionnaireQuestionPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_VERSION")
	private Date dateVersion;

	@Column(name="NMR_ORDER")
	private BigDecimal nmrOrder;

	@Column(name="NMR_VERSION")
	private BigDecimal nmrVersion;

	@Temporal(TemporalType.DATE)
	@Column(name="USER_INSERT")
	private Date userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Question
	@ManyToOne
	@JoinColumn(name="ID_QUESTION_FK")
	private Question question;

	//bi-directional many-to-one association to Questionnaire
	@ManyToOne
	@JoinColumn(name="ID_QUESTIONNAIRE_FK")
	private Questionnaire questionnaire;

	public QuestionnaireQuestion() {
	}

	public long getIdQuestionnaireQuestionPk() {
		return this.idQuestionnaireQuestionPk;
	}

	public void setIdQuestionnaireQuestionPk(long idQuestionnaireQuestionPk) {
		this.idQuestionnaireQuestionPk = idQuestionnaireQuestionPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}

	public BigDecimal getNmrOrder() {
		return this.nmrOrder;
	}

	public void setNmrOrder(BigDecimal nmrOrder) {
		this.nmrOrder = nmrOrder;
	}

	public BigDecimal getNmrVersion() {
		return this.nmrVersion;
	}

	public void setNmrVersion(BigDecimal nmrVersion) {
		this.nmrVersion = nmrVersion;
	}

	public Date getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(Date userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Question getQuestion() {
		return this.question;
	}

	public void setQuestion(Question question) {
		this.question = question;
	}

	public Questionnaire getQuestionnaire() {
		return this.questionnaire;
	}

	public void setQuestionnaire(Questionnaire questionnaire) {
		this.questionnaire = questionnaire;
	}

}