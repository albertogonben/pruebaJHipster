package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_NODE database table.
 * 
 */
@Entity
@Table(name="TYPE_NODE")
@NamedQuery(name="TypeNode.findAll", query="SELECT t FROM TypeNode t")
public class TypeNode implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_TYPE_NODE_PK")
	private long idTypeNodePk;

	@Column(name="CD_TYPE_NODE")
	private String cdTypeNode;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_NODE")
	private String txtNode;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to GuideJob
//	@OneToMany(mappedBy="typeNode")
//	private List<GuideJob> guideJobs;
//
//	//bi-directional many-to-one association to ProgramJob
//	@OneToMany(mappedBy="typeNode")
//	private List<ProgramJob> programJobs;

	public TypeNode() {
	}

	public long getIdTypeNodePk() {
		return this.idTypeNodePk;
	}

	public void setIdTypeNodePk(long idTypeNodePk) {
		this.idTypeNodePk = idTypeNodePk;
	}

	public String getCdTypeNode() {
		return this.cdTypeNode;
	}

	public void setCdTypeNode(String cdTypeNode) {
		this.cdTypeNode = cdTypeNode;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtNode() {
		return this.txtNode;
	}

	public void setTxtNode(String txtNode) {
		this.txtNode = txtNode;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

//	public List<GuideJob> getGuideJobs() {
//		return this.guideJobs;
//	}
//
//	public void setGuideJobs(List<GuideJob> guideJobs) {
//		this.guideJobs = guideJobs;
//	}
//
//	public GuideJob addGuideJob(GuideJob guideJob) {
//		getGuideJobs().add(guideJob);
//		guideJob.setTypeNode(this);
//
//		return guideJob;
//	}
//
//	public GuideJob removeGuideJob(GuideJob guideJob) {
//		getGuideJobs().remove(guideJob);
//		guideJob.setTypeNode(null);
//
//		return guideJob;
//	}
//
//	public List<ProgramJob> getProgramJobs() {
//		return this.programJobs;
//	}
//
//	public void setProgramJobs(List<ProgramJob> programJobs) {
//		this.programJobs = programJobs;
//	}
//
//	public ProgramJob addProgramJob(ProgramJob programJob) {
//		getProgramJobs().add(programJob);
//		programJob.setTypeNode(this);
//
//		return programJob;
//	}
//
//	public ProgramJob removeProgramJob(ProgramJob programJob) {
//		getProgramJobs().remove(programJob);
//		programJob.setTypeNode(null);
//
//		return programJob;
//	}

}