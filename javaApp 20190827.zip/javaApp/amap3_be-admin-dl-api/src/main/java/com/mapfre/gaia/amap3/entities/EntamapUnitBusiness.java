package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the ENTAMAP_UNIT_BUSINESS database table.
 * 
 */
@Entity
@Table(name="ENTAMAP_UNIT_BUSINESS")
@NamedQuery(name="EntamapUnitBusiness.findAll", query="SELECT e FROM EntamapUnitBusiness e")
public class EntamapUnitBusiness implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ENTAMAP_UNIT_BUSINESS_IDRELATIONPK_GENERATOR", sequenceName="ENTAMAP_UNIT_BUSINESS_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ENTAMAP_UNIT_BUSINESS_IDRELATIONPK_GENERATOR")
	@Column(name="ID_RELATION_PK")
	private long idRelationPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="ID_ENTAMAP_FK")
	private java.math.BigDecimal idEntamapFk;

	@Column(name="ID_UNIT_BUSINESS_FK")
	private java.math.BigDecimal idUnitBusinessFk;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public EntamapUnitBusiness() {
	}

	public long getIdRelationPk() {
		return this.idRelationPk;
	}

	public void setIdRelationPk(long idRelationPk) {
		this.idRelationPk = idRelationPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public java.math.BigDecimal getIdEntamapFk() {
		return this.idEntamapFk;
	}

	public void setIdEntamapFk(java.math.BigDecimal idEntamapFk) {
		this.idEntamapFk = idEntamapFk;
	}

	public java.math.BigDecimal getIdUnitBusinessFk() {
		return this.idUnitBusinessFk;
	}

	public void setIdUnitBusinessFk(java.math.BigDecimal idUnitBusinessFk) {
		this.idUnitBusinessFk = idUnitBusinessFk;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}