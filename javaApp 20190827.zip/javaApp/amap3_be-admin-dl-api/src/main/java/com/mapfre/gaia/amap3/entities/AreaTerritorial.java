package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the AREA_TERRITORIAL database table.
 * 
 */
@Entity
@Table(name="AREA_TERRITORIAL")
@NamedQuery(name="AreaTerritorial.findAll", query="SELECT a FROM AreaTerritorial a")
public class AreaTerritorial implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_AREA_TERRITORIA_PK")
	private long idAreaTerritoriaPk;

	@Column(name="CD_AREA_TERRITORIAL")
	private String cdAreaTerritorial;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_AREA_TERRITORIAL")
	private String txtAreaTerritorial;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

//	//bi-directional many-to-one association to Region
//	@OneToMany(mappedBy="areaTerritorial")
//	private List<Region> regions;

	public AreaTerritorial() {
	}

	public long getIdAreaTerritoriaPk() {
		return this.idAreaTerritoriaPk;
	}

	public void setIdAreaTerritoriaPk(long idAreaTerritoriaPk) {
		this.idAreaTerritoriaPk = idAreaTerritoriaPk;
	}

	public String getCdAreaTerritorial() {
		return this.cdAreaTerritorial;
	}

	public void setCdAreaTerritorial(String cdAreaTerritorial) {
		this.cdAreaTerritorial = cdAreaTerritorial;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtAreaTerritorial() {
		return this.txtAreaTerritorial;
	}

	public void setTxtAreaTerritorial(String txtAreaTerritorial) {
		this.txtAreaTerritorial = txtAreaTerritorial;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

//	public List<Region> getRegions() {
//		return this.regions;
//	}
//
//	public void setRegions(List<Region> regions) {
//		this.regions = regions;
//	}
//
//	public Region addRegion(Region region) {
//		getRegions().add(region);
//		region.setAreaTerritorial(this);
//
//		return region;
//	}
//
//	public Region removeRegion(Region region) {
//		getRegions().remove(region);
//		region.setAreaTerritorial(null);
//
//		return region;
//	}

}