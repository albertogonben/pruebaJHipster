package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the REGION database table.
 * 
 */
@Entity
@NamedQuery(name="Region.findAll", query="SELECT r FROM Region r")
public class Region implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="REGION_IDREGIONPK_GENERATOR", sequenceName="REG_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="REGION_IDREGIONPK_GENERATOR")
	@Column(name="ID_REGION_PK")
	private long idRegionPk;

	@Column(name="CD_REGION")
	private String cdRegion;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_REGION")
	private String txtRegion;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Country
//	@OneToMany(mappedBy="region")
//	private List<Country> countries;

	//bi-directional many-to-one association to AreaTerritorial
	@ManyToOne
	@JoinColumn(name="ID_AREA_TERRITORIAL_FK")
	private AreaTerritorial areaTerritorial;

	public Region() {
	}

	public long getIdRegionPk() {
		return this.idRegionPk;
	}

	public void setIdRegionPk(long idRegionPk) {
		this.idRegionPk = idRegionPk;
	}

	public String getCdRegion() {
		return this.cdRegion;
	}

	public void setCdRegion(String cdRegion) {
		this.cdRegion = cdRegion;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtRegion() {
		return this.txtRegion;
	}

	public void setTxtRegion(String txtRegion) {
		this.txtRegion = txtRegion;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

//	public List<Country> getCountries() {
//		return this.countries;
//	}
//
//	public void setCountries(List<Country> countries) {
//		this.countries = countries;
//	}

//	public Country addCountry(Country country) {
//		getCountries().add(country);
//		country.setRegion(this);
//
//		return country;
//	}
//
//	public Country removeCountry(Country country) {
//		getCountries().remove(country);
//		country.setRegion(null);
//
//		return country;
//	}

	public AreaTerritorial getAreaTerritorial() {
		return this.areaTerritorial;
	}

	public void setAreaTerritorial(AreaTerritorial areaTerritorial) {
		this.areaTerritorial = areaTerritorial;
	}

}