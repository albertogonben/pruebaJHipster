package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the IMPUTATION_TIME database table.
 * 
 */
@Entity
@Table(name="IMPUTATION_TIME")
@NamedQuery(name="ImputationTime.findAll", query="SELECT i FROM ImputationTime i")
public class ImputationTime implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="IMPUTATION_TIME_IDIMPUTACTONPK_GENERATOR", sequenceName="IMPUTATION_TIME_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="IMPUTATION_TIME_IDIMPUTACTONPK_GENERATOR")
	@Column(name="ID_IMPUTACTON_PK")
	private long idImputactonPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_IMPUTATION")
	private Date dateImputation;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="ID_JOB_FK")
	private BigDecimal idJobFk;

	@Column(name="ID_USER_FK")
	private BigDecimal idUserFk;

	@Column(name="NMR_HOURS")
	private BigDecimal nmrHours;

	@Column(name="TXT_COMMENT")
	private String txtComment;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to TypeConceptImputation
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_CONCEPT_IMPUTATION_FK")
	private TypeConceptImputation typeConceptImputation;

	public ImputationTime() {
	}

	public long getIdImputactonPk() {
		return this.idImputactonPk;
	}

	public void setIdImputactonPk(long idImputactonPk) {
		this.idImputactonPk = idImputactonPk;
	}

	public Date getDateImputation() {
		return this.dateImputation;
	}

	public void setDateImputation(Date dateImputation) {
		this.dateImputation = dateImputation;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getIdJobFk() {
		return this.idJobFk;
	}

	public void setIdJobFk(BigDecimal idJobFk) {
		this.idJobFk = idJobFk;
	}

	public BigDecimal getIdUserFk() {
		return this.idUserFk;
	}

	public void setIdUserFk(BigDecimal idUserFk) {
		this.idUserFk = idUserFk;
	}

	public BigDecimal getNmrHours() {
		return this.nmrHours;
	}

	public void setNmrHours(BigDecimal nmrHours) {
		this.nmrHours = nmrHours;
	}

	public String getTxtComment() {
		return this.txtComment;
	}

	public void setTxtComment(String txtComment) {
		this.txtComment = txtComment;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public TypeConceptImputation getTypeConceptImputation() {
		return this.typeConceptImputation;
	}

	public void setTypeConceptImputation(TypeConceptImputation typeConceptImputation) {
		this.typeConceptImputation = typeConceptImputation;
	}

}