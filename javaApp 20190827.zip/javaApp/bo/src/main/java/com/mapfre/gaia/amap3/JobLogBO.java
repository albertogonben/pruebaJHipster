package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the JOB_LOG database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobLogBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idEventPk;

	private Date dateEvent;

	private Date dateInsert;

	private Date dateUpdate;

	private String txtEvent;

	private String userEvent;

	private String userInsert;

	private String userUpdate;

	private JobBO job;

	private TypeTraceBO typeTrace;

}