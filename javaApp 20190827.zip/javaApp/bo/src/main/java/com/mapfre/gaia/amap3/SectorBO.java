package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the SECTOR database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SectorBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idSectorPk;

	private String cdSector;

	private String dateVersion;

	private BigDecimal mrkActivo;

	private BigDecimal nmrVersion;

	private String txtNombre;

//	private List<ProcessCountryBO> processCountries;

}