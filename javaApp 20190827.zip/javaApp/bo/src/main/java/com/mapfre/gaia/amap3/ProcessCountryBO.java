package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the PROCESS_COUNTRY database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessCountryBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idProcessPk;

	private String cdProceso;

	private String dateVersion;

	private BigDecimal nmrSize;

	private BigDecimal nmrVersion;

	private String txtNm;

	private CountryBO country;

	private ProcessUnitBusinessBO processUnitBusiness;

	private SectorBO sector;

	private TypeProcessBO typeProcess;

}