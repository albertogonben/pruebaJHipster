package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the ENTAMAP database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EntamapBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idEntityPk;

	private String cdEntity;

	private String mrkActive;

	private String txtDescription;

	private String txtName;

	private CountryBO country;

	private CurrencyBO currency;

	private EntamapBO entamap;
	
	private TypeOrganizationalStructureBO typeOrganizationalStructure;

	private List<EntamapBO> entamaps;

	private List<UserAmapBO> userAmaps;
}