package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The business object class for the REGION database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegionBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idRegionPk;

	private String cdRegion;

	private BigDecimal mrkActive;

	private String txtRegion;

//	private List<CountryBO> countries;

	private AreaTerritorialBO areaTerritorial;

}