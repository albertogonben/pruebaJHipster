package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Questionnaire database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuestionnaireBO implements Serializable {

	private static final long serialVersionUID=1L;
	private long idQuestionnairePk;
	private java.lang.String codQuestionnaire;
	private String dateVersion;
	private java.math.BigDecimal mrkActive;
	private java.math.BigDecimal nmrVersion;
	private java.lang.String txtDescription;
	private java.lang.String txtTitle;

}