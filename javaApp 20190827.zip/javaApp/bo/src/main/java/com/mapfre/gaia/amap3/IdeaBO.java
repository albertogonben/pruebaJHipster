package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the IDEA database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class IdeaBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idIdeaPk;

	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal idMrkStateFk;

	private String txtDescription;

	private String txtName;

	private String userInsert;

	private String userUpdate;

	private OrganizationalStructureBO organizationalStructure;

	private List<IdeaDocumentBO> ideaDocuments;

	private List<JobIdeaBO> jobIdeas;

}