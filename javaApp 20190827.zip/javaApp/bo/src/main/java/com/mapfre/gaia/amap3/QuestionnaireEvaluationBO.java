package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the QuestionnaireEvaluation database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuestionnaireEvaluationBO implements Serializable {

	private static final long serialVersionUID=1L;
	private long idEvaluacionPk;
	private java.util.Date dateCumplimentation;
	private java.util.Date dateEmision;
	private java.util.Date dateInsert;
	private java.util.Date dateReading;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal idJobFk;
	private java.math.BigDecimal idUserCompliant;
	private java.math.BigDecimal idUserEvaluation;
	private java.math.BigDecimal nrmEvaluation;
	private java.lang.String txtEvaluation;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private QuestionnaireQuestionBO questionnaireQuestion;

}