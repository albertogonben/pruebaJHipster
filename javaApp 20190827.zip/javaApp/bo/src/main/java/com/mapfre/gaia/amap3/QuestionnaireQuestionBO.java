package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the QuestionnaireQuestion database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuestionnaireQuestionBO implements Serializable {

	private static final long serialVersionUID=1L;
	private long idQuestionnaireQuestionPk;
	private String dateVersion;
	private java.math.BigDecimal nmrOrder;
	private java.math.BigDecimal nmrVersion;
	private QuestionBO question;
	private QuestionnaireBO questionnaire;

}