package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The business object class for the CURRENCY database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CurrencyBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idCurrencyPk;

	private String cdCurrency;
	
	private BigDecimal mrkActive;

	private String txtCurrency;

}