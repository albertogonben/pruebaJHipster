package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Question database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuestionBO implements Serializable {

	private static final long serialVersionUID=1L;
	private long idQuestionTypePk;
	private java.lang.String codQuestionType;
	private java.math.BigDecimal isOptionQuestion;
	private java.math.BigDecimal isTextQuestion;
	private java.lang.String txtQuestion;

}