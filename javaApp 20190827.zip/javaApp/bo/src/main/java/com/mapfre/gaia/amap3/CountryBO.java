package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The business object class for the COUNTRY database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CountryBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idCountryPk;

	private String cdCountry;

	private String cdIso;
	
	private String txtName;

	private CurrencyBO currency;

	private RegionBO region;

}