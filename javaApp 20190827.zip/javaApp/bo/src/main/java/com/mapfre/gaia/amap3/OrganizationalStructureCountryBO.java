package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the OrganizationalStructureCountry database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrganizationalStructureCountryBO implements Serializable {

	private static final long serialVersionUID=1L;
	private long idRelationPk;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal idCountryFk;
	private java.math.BigDecimal idOrganizationalStructureFk;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}