package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeCriquiteAlarmController implements ITypeCriquiteAlarmController{

	private ITypeCriquiteAlarmBL typeCriquiteAlarmBL;
	
	@Autowired
	public TypeCriquiteAlarmController(ITypeCriquiteAlarmBL typeCriquiteAlarmBL) {
		this.typeCriquiteAlarmBL = typeCriquiteAlarmBL;
	}
	
	@Override
	public ResponseEntity<List<TypeCriquiteAlarmBO>> get() throws CustomException{
		log.debug("TypeCriquiteAlarmController:get [START]");
		try {
			log.debug("TypeCriquiteAlarmController:get [END]");
			return ResponseEntity.ok().body(typeCriquiteAlarmBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeCriquiteAlarmBO> add(@Valid @RequestBody TypeCriquiteAlarmBO input) throws CustomException{
    	log.debug("TypeCriquiteAlarmController:add [START]");
    	try {
    		
    	
			TypeCriquiteAlarmBO typeCriquiteAlarmBo = typeCriquiteAlarmBL.add(input);
			if (typeCriquiteAlarmBo != null) {
				log.debug("TypeCriquiteAlarmController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeCriquiteAlarmBO> update(@PathVariable Long typeCriquiteAlarmId, @RequestBody TypeCriquiteAlarmBO input) throws CustomException{
    	log.debug("TypeCriquiteAlarmController:update [START]");
    	try {
			TypeCriquiteAlarmBO typeCriquiteAlarmBo = typeCriquiteAlarmBL.update(typeCriquiteAlarmId, input);
			if (typeCriquiteAlarmBo != null) {
				log.debug("TypeCriquiteAlarmController:update [END]");
			    return ResponseEntity.ok().body(typeCriquiteAlarmBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeCriquiteAlarmBO> delete(@PathVariable Long typeCriquiteAlarmId) throws CustomException{
        log.debug("TypeCriquiteAlarmController:delete [START]");
        try {
			boolean typeCriquiteAlarmDeleted = typeCriquiteAlarmBL.delete(typeCriquiteAlarmId);
			if (typeCriquiteAlarmDeleted) {
				log.debug("TypeCriquiteAlarmController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
