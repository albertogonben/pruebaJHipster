package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CurrencyController implements ICurrencyController {

	private ICurrencyBL currencyBL;

	@Autowired
	public CurrencyController(ICurrencyBL currencyBL) {
		this.currencyBL = currencyBL;
	}

	@Override
	public ResponseEntity<List<CurrencyBO>> get() throws CustomException {
		log.debug("CurrencyController:get [START]");
		try {
			log.debug("CurrencyController:get [END]");
			return ResponseEntity.ok().body(currencyBL.getlAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

	@Override
	public ResponseEntity<CurrencyBO> add(@Valid @RequestBody CurrencyBO input) throws CustomException {
		log.debug("CurrencyController:add [START]");
		try {
			CurrencyBO output = currencyBL.save(input);

			if (output != null) {
				log.debug("CurrencyController:add [END]");
				return ResponseEntity.ok().body(output);
			} else {
				throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
			}
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

	@Override
	public ResponseEntity<CurrencyBO> update(@PathVariable("currencyId") Long currencyId,
			@Valid @RequestBody CurrencyBO input) throws CustomException {
		log.debug("CurrencyController:update [START]");
		try {
			CurrencyBO output = currencyBL.update(currencyId, input);

			if (output != null) {
				log.debug("CurrencyController:update [END]");
				return ResponseEntity.ok().body(output);
			} else {
				throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
			}
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

	@Override
	public ResponseEntity<CurrencyBO> delete(@PathVariable("currencyId") Long currencyId) throws CustomException {
		log.debug("CurrencyController:delete [START]");
		try {
			boolean claseoPeriodDeleted = currencyBL.delete(currencyId);
			if (claseoPeriodDeleted) {
				log.debug("CurrencyController:delete [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());

		}
	}

}
