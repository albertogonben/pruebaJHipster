package com.mapfre.gaia.amap3.validations.util;

import com.mapfre.gaia.amap3.CountryBO;
import com.mapfre.gaia.amap3.GuideJobBO;
import com.mapfre.gaia.amap3.ProcessCountryBO;
import com.mapfre.gaia.amap3.ProcessUnitBusinessBO;
import com.mapfre.gaia.amap3.QuestionBO;
import com.mapfre.gaia.amap3.QuestionnaireBO;
import com.mapfre.gaia.amap3.QuestionnaireQuestionBO;
import com.mapfre.gaia.amap3.SectorBO;
import com.mapfre.gaia.amap3.TypeNodeBO;
import com.mapfre.gaia.amap3.TypeProcessBO;
import com.mapfre.gaia.amap3.UnitBusinessBO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ValidationParametersIn {

	public static boolean validationParameters(Object input) {
		log.debug("ValidationParametersIn.validationParametersIn [START]");
		if (input instanceof QuestionnaireQuestionBO) {
			return validationParametersQuestionnaireQuestion((QuestionnaireQuestionBO) input);
		} else if (input instanceof ProcessUnitBusinessBO) {
			return validationParametersProcessUnitBusiness((ProcessUnitBusinessBO) input);
		} else if (input instanceof ProcessCountryBO) {
			return validationParametersProcessCountry((ProcessCountryBO) input);
		} else if (input instanceof GuideJobBO) {
			return validationParametersGuideJob((GuideJobBO) input);
		}
		log.debug("ValidationParametersIn.validationParametersIn [END]");
		return true;
	}

	private static boolean validationParametersGuideJob(GuideJobBO input) {
		log.debug("ValidationParametersIn.validationParametersGuideJob [START]");
		TypeNodeBO typeNode = input.getTypeNode();
		if (typeNode == null) {
			log.debug("ValidationParametersIn.validationParametersGuideJob [END]");
			return false;
		} else {
			log.debug("ValidationParametersIn.validationParametersGuideJob [END]");
			return true;
		}
	}

	private static boolean validationParametersQuestionnaireQuestion(QuestionnaireQuestionBO input) {
		log.debug("ValidationParametersIn.validationParametersQuestionnaireQuestion [START]");
		QuestionBO question = input.getQuestion();
		QuestionnaireBO questionnaire = input.getQuestionnaire();
		if (question == null || questionnaire == null) {
			log.debug("ValidationParametersIn.validationParametersQuestionnaireQuestion [END]");
			return false;
		} else {
			log.debug("ValidationParametersIn.validationParametersQuestionnaireQuestion [END]");
			return true;
		}
	}

	private static boolean validationParametersProcessUnitBusiness(ProcessUnitBusinessBO input) {
		log.debug("ValidationParametersIn.validationParametersProcessUnitBusiness [START]");
		TypeProcessBO typeProcess = input.getTypeProcess();
		UnitBusinessBO unitBusiness = input.getUnitBusiness();
		if (typeProcess == null || unitBusiness == null) {
			log.debug("ValidationParametersIn.validationParametersProcessUnitBusiness [END]");
			return false;
		} else {
			log.debug("ValidationParametersIn.validationParametersProcessUnitBusiness [END]");
			return true;
		}
	}

	private static boolean validationParametersProcessCountry(ProcessCountryBO input) {
		log.debug("ValidationParametersIn.validationParametersProcessCountry [START]");
		TypeProcessBO typeProcess = input.getTypeProcess();
		CountryBO country = input.getCountry();
		ProcessUnitBusinessBO processUnitBusiness = input.getProcessUnitBusiness();
		SectorBO sector = input.getSector();
		if (typeProcess == null || country == null || processUnitBusiness == null || sector == null) {
			log.debug("ValidationParametersIn.validationParametersProcessCountry [END]");
			return false;
		} else {
			log.debug("ValidationParametersIn.validationParametersProcessCountry [END]");
			return true;
		}
	}
}
