package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeLevelLanguageController implements ITypeLevelLanguageController{

	private ITypeLevelLanguageBL typeLevelLanguageBL;
	
	@Autowired
	public TypeLevelLanguageController(ITypeLevelLanguageBL typeLevelLanguageBL) {
		this.typeLevelLanguageBL = typeLevelLanguageBL;
	}
	
	@Override
	public ResponseEntity<List<TypeLevelLanguageBO>> get() throws CustomException{
		log.debug("TypeLevelLanguageController:get [START]");
		try {
			log.debug("TypeLevelLanguageController:get [END]");
			return ResponseEntity.ok().body(typeLevelLanguageBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeLevelLanguageBO> add(@Valid @RequestBody TypeLevelLanguageBO input) throws CustomException{
    	log.debug("TypeLevelLanguageController:add [START]");
    	try {
    		
    	
			TypeLevelLanguageBO typeLevelLanguageBo = typeLevelLanguageBL.add(input);
			if (typeLevelLanguageBo != null) {
				log.debug("TypeLevelLanguageController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeLevelLanguageBO> update(@PathVariable Long typeLevelLanguageId, @RequestBody TypeLevelLanguageBO input) throws CustomException{
    	log.debug("TypeLevelLanguageController:update [START]");
    	try {
			TypeLevelLanguageBO typeLevelLanguageBo = typeLevelLanguageBL.update(typeLevelLanguageId, input);
			if (typeLevelLanguageBo != null) {
				log.debug("TypeLevelLanguageController:update [END]");
			    return ResponseEntity.ok().body(typeLevelLanguageBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeLevelLanguageBO> delete(@PathVariable Long typeLevelLanguageId) throws CustomException{
        log.debug("TypeLevelLanguageController:delete [START]");
        try {
			boolean typeLevelLanguageDeleted = typeLevelLanguageBL.delete(typeLevelLanguageId);
			if (typeLevelLanguageDeleted) {
				log.debug("TypeLevelLanguageController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
