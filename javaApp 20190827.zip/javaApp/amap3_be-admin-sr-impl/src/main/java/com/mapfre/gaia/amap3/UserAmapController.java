package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class UserAmapController implements IUserAMapController{

	private IUserAmapBL userAmapBL;
	
	@Autowired
	public UserAmapController(IUserAmapBL userAmapBL) {
		this.userAmapBL = userAmapBL;
	}
	
	@Override
	public ResponseEntity<List<UserAmapBO>> get() throws CustomException{
		log.debug("UserAmapController:get [START]");
		try {
			log.debug("UserAmapController:get [END]");
			return ResponseEntity.ok().body(userAmapBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<UserAmapBO> add(@Valid @RequestBody UserAmapBO input) throws CustomException{
    	log.debug("UserAmapController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	    	
			UserAmapBO userAmapBo = userAmapBL.add(input);
			if (userAmapBo != null) {
				log.debug("UserAmapController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UserAmapBO> update(@PathVariable Long userAmapId, @RequestBody UserAmapBO input) throws CustomException{
    	log.debug("UserAmapController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	    		
			UserAmapBO userAmapBo = userAmapBL.update(userAmapId, input);
			if (userAmapBo != null) {
				log.debug("UserAmapController:update [END]");
			    return ResponseEntity.ok().body(userAmapBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UserAmapBO> delete(@PathVariable Long userAmapId) throws CustomException{
        log.debug("UserAmapController:delete [START]");
        try {
			boolean userAmapDeleted = userAmapBL.delete(userAmapId);
			if (userAmapDeleted) {
				log.debug("UserAmapController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
