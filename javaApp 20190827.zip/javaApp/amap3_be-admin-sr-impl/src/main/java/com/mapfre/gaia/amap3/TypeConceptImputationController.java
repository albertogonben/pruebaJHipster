package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeConceptImputationController implements ITypeConceptImputationController{

	private ITypeConceptImputationBL typeConceptImputationBL;
	
	@Autowired
	public TypeConceptImputationController(ITypeConceptImputationBL typeConceptImputationBL) {
		this.typeConceptImputationBL = typeConceptImputationBL;
	}
	
	@Override
	public ResponseEntity<List<TypeConceptImputationBO>> get() throws CustomException{
		log.debug("TypeConceptImputationController:get [START]");
		try {
			log.debug("TypeConceptImputationController:get [END]");
			return ResponseEntity.ok().body(typeConceptImputationBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeConceptImputationBO> add(@Valid @RequestBody TypeConceptImputationBO input) throws CustomException{
    	log.debug("TypeConceptImputationController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeConceptImputationBO typeConceptImputationBo = typeConceptImputationBL.add(input);
			if (typeConceptImputationBo != null) {
				log.debug("TypeConceptImputationController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeConceptImputationBO> update(@PathVariable Long typeConceptImputationId, @RequestBody TypeConceptImputationBO input) throws CustomException{
    	log.debug("TypeConceptImputationController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeConceptImputationBO typeConceptImputationBo = typeConceptImputationBL.update(typeConceptImputationId, input);
			if (typeConceptImputationBo != null) {
				log.debug("TypeConceptImputationController:update [END]");
			    return ResponseEntity.ok().body(typeConceptImputationBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeConceptImputationBO> delete(@PathVariable Long typeConceptImputationId) throws CustomException{
        log.debug("TypeConceptImputationController:delete [START]");
        try {
			boolean typeConceptImputationDeleted = typeConceptImputationBL.delete(typeConceptImputationId);
			if (typeConceptImputationDeleted) {
				log.debug("TypeConceptImputationController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
