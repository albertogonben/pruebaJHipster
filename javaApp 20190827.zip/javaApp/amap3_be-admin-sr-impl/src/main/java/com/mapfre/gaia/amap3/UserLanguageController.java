package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class UserLanguageController implements IUserLanguageController{

	private IUserLanguageBL userLanguageBL;
	
	@Autowired
	public UserLanguageController(IUserLanguageBL userLanguageBL) {
		this.userLanguageBL = userLanguageBL;
	}
	
	@Override
	public ResponseEntity<List<UserLanguageBO>> get() throws CustomException{
		log.debug("UserLanguageController:get [START]");
		try {
			log.debug("UserLanguageController:get [END]");
			return ResponseEntity.ok().body(userLanguageBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<UserLanguageBO> add(@Valid @RequestBody UserLanguageBO input) throws CustomException{
    	log.debug("UserLanguageController:add [START]");
    	try {
    		
    	
			UserLanguageBO userLanguageBo = userLanguageBL.add(input);
			if (userLanguageBo != null) {
				log.debug("UserLanguageController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UserLanguageBO> update(@PathVariable Long userLanguageId, @RequestBody UserLanguageBO input) throws CustomException{
    	log.debug("UserLanguageController:update [START]");
    	try {
			UserLanguageBO userLanguageBo = userLanguageBL.update(userLanguageId, input);
			if (userLanguageBo != null) {
				log.debug("UserLanguageController:update [END]");
			    return ResponseEntity.ok().body(userLanguageBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UserLanguageBO> delete(@PathVariable Long userLanguageId) throws CustomException{
        log.debug("UserLanguageController:delete [START]");
        try {
			boolean userLanguageDeleted = userLanguageBL.delete(userLanguageId);
			if (userLanguageDeleted) {
				log.debug("UserLanguageController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
