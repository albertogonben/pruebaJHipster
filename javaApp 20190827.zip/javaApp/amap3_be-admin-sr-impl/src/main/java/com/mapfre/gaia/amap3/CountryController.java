package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class CountryController implements ICountryController {

	private ICountryBL countryBL;

	@Autowired
	public CountryController(ICountryBL countryBL) {
		this.countryBL = countryBL;
	}

	@Override
	public ResponseEntity<List<CountryBO>> get() {
		try {
			return ResponseEntity.ok().body(countryBL.getAll());
		} catch (Exception e) {
			log.error("CountryController:get", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<CountryBO> add(@Valid @RequestBody CountryBO input) {
		try {
			CountryBO countryBO = countryBL.add(input);
			if (countryBO != null) {
				return ResponseEntity.ok().build();
			}
			return ResponseEntity.status(HttpStatus.CONFLICT).build();
		} catch (Exception e) {
			log.error("CountryController:add", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<CountryBO> update(@PathVariable Long countryId, @RequestBody CountryBO input) {
		try {
			CountryBO countryBO = countryBL.update(countryId, input);
			if (countryBO != null) {
				return ResponseEntity.ok().body(countryBO);
			}
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			log.error("CountryController:update", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<CountryBO> delete(@PathVariable Long countryId) {
		try {
			boolean countryDeleted = countryBL.delete(countryId);
			if (countryDeleted) {
				return ResponseEntity.noContent().build();
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			log.error("CountryController:delete", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<CountryBO> findCountry(Long countryId) {
		try {
			return ResponseEntity.ok().body(countryBL.findCountry(countryId));
		} catch (Exception e) {
			log.error("CountryController:get", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<CountryRegionBO> findTerrForRegionsCountry(Long countryId, Long regionId) {
		try {
			return ResponseEntity.ok().body(countryBL.findRegionCountry(countryId, regionId));
		} catch (Exception e) {
			log.error("CountryController:get", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

}
