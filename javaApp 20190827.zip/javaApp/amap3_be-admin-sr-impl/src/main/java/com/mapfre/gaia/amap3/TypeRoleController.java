package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeRoleController implements ITypeRoleController{

	private ITypeRoleBL typeRoleBL;
	
	@Autowired
	public TypeRoleController(ITypeRoleBL typeRoleBL) {
		this.typeRoleBL = typeRoleBL;
	}
	
	@Override
	public ResponseEntity<List<TypeRoleBO>> get() throws CustomException{
		log.debug("TypeRoleController:get [START]");
		try {
			log.debug("TypeRoleController:get [END]");
			return ResponseEntity.ok().body(typeRoleBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeRoleBO> add(@Valid @RequestBody TypeRoleBO input) throws CustomException{
    	log.debug("TypeRoleController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
				throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			} 		
    	
			TypeRoleBO typeRoleBo = typeRoleBL.add(input);
			if (typeRoleBo != null) {
				log.debug("TypeRoleController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeRoleBO> update(@PathVariable Long typeRoleId, @RequestBody TypeRoleBO input) throws CustomException{
    	log.debug("TypeRoleController:update [START]");
    	try {
			TypeRoleBO typeRoleBo = typeRoleBL.update(typeRoleId, input);
			if (typeRoleBo != null) {
				log.debug("TypeRoleController:update [END]");
			    return ResponseEntity.ok().body(typeRoleBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeRoleBO> delete(@PathVariable Long typeRoleId) throws CustomException{
        log.debug("TypeRoleController:delete [START]");
        try {
			boolean typeRoleDeleted = typeRoleBL.delete(typeRoleId);
			if (typeRoleDeleted) {
				log.debug("TypeRoleController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
