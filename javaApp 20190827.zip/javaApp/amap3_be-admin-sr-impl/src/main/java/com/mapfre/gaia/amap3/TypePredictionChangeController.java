package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypePredictionChangeController implements ITypePredictionChangeController{

	private ITypePredictionChangeBL typePredictionChangeBL;
	
	@Autowired
	public TypePredictionChangeController(ITypePredictionChangeBL typePredictionChangeBL) {
		this.typePredictionChangeBL = typePredictionChangeBL;
	}
	
	@Override
	public ResponseEntity<List<TypePredictionChangeBO>> get() throws CustomException{
		log.debug("TypePredictionChangeController:get [START]");
		try {
			log.debug("TypePredictionChangeController:get [END]");
			return ResponseEntity.ok().body(typePredictionChangeBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypePredictionChangeBO> add(@Valid @RequestBody TypePredictionChangeBO input) throws CustomException{
    	log.debug("TypePredictionChangeController:add [START]");
    	try {
    		
    	
			TypePredictionChangeBO typePredictionChangeBo = typePredictionChangeBL.add(input);
			if (typePredictionChangeBo != null) {
				log.debug("TypePredictionChangeController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypePredictionChangeBO> update(@PathVariable Long typePredictionChangeId, @RequestBody TypePredictionChangeBO input) throws CustomException{
    	log.debug("TypePredictionChangeController:update [START]");
    	try {
			TypePredictionChangeBO typePredictionChangeBo = typePredictionChangeBL.update(typePredictionChangeId, input);
			if (typePredictionChangeBo != null) {
				log.debug("TypePredictionChangeController:update [END]");
			    return ResponseEntity.ok().body(typePredictionChangeBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypePredictionChangeBO> delete(@PathVariable Long typePredictionChangeId) throws CustomException{
        log.debug("TypePredictionChangeController:delete [START]");
        try {
			boolean typePredictionChangeDeleted = typePredictionChangeBL.delete(typePredictionChangeId);
			if (typePredictionChangeDeleted) {
				log.debug("TypePredictionChangeController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
