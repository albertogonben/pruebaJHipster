package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CelebratedSentencesController implements ICelebratedSentencesController {

	private ICelebratedSentencesBL celebritiesSentenceBL;

	@Autowired
	public CelebratedSentencesController(ICelebratedSentencesBL celebritiesSentenceBL) {
		this.celebritiesSentenceBL = celebritiesSentenceBL;
	}

	@Override
	public ResponseEntity<List<CelebratedSentenceBO>> getAll() throws CustomException {
		log.debug("CelebratedSentencesController:getAll [START]");
		try {
			log.debug("CelebratedSentencesController:getAll [END]");
			return ResponseEntity.ok().body(celebritiesSentenceBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}

	}

	@Override
	public ResponseEntity<CelebratedSentenceBO> post(@Valid @RequestBody CelebratedSentenceBO input)
			throws CustomException {
		log.debug("CelebratedSentencesController:post [START]");
		try {
			if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			CelebratedSentenceBO output = celebritiesSentenceBL.save(input);

			if (output != null) {
				log.debug("CelebratedSentencesController:post [END]");
				return ResponseEntity.ok().body(output);
			} else {
				throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
			}

		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

	@Override
	public ResponseEntity<CelebratedSentenceBO> put(@PathVariable("id") Long id,
			@Valid @RequestBody CelebratedSentenceBO input) throws CustomException {
		log.debug("CelebratedSentencesController:put [START]");
		try {
			if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			CelebratedSentenceBO output = celebritiesSentenceBL.update(id, input);

			if (output != null) {
				log.debug("CelebratedSentencesController:put [END]");
				return ResponseEntity.ok().body(output);
			} else {
				throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
			}

		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}

	}

	@Override
	public ResponseEntity<?> delete(@PathVariable("id") Long id) throws CustomException {
		log.debug("CelebratedSentencesController:delete [START]");
		try {
			if (celebritiesSentenceBL.delete(id)) {
				log.debug("CelebratedSentencesController:delete [END]");
				return new ResponseEntity<>(HttpStatus.OK);
			} else {
				throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
			}
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(),
					HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}

	}

}
