package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class UserCategoryController implements IUserCategoryController{

	private IUserCategoryBL userCategoryBL;
	
	@Autowired
	public UserCategoryController(IUserCategoryBL userCategoryBL) {
		this.userCategoryBL = userCategoryBL;
	}
	
	@Override
	public ResponseEntity<List<UserCategoryBO>> get() throws CustomException{
		log.debug("UserCategoryController:get [START]");
		try {
			log.debug("UserCategoryController:get [END]");
			return ResponseEntity.ok().body(userCategoryBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<UserCategoryBO> add(@Valid @RequestBody UserCategoryBO input) throws CustomException{
    	log.debug("UserCategoryController:add [START]");
    	try {
    		
    	
			UserCategoryBO userCategoryBo = userCategoryBL.add(input);
			if (userCategoryBo != null) {
				log.debug("UserCategoryController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UserCategoryBO> update(@PathVariable Long userCategoryId, @RequestBody UserCategoryBO input) throws CustomException{
    	log.debug("UserCategoryController:update [START]");
    	try {
			UserCategoryBO userCategoryBo = userCategoryBL.update(userCategoryId, input);
			if (userCategoryBo != null) {
				log.debug("UserCategoryController:update [END]");
			    return ResponseEntity.ok().body(userCategoryBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UserCategoryBO> delete(@PathVariable Long userCategoryId) throws CustomException{
        log.debug("UserCategoryController:delete [START]");
        try {
			boolean userCategoryDeleted = userCategoryBL.delete(userCategoryId);
			if (userCategoryDeleted) {
				log.debug("UserCategoryController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
