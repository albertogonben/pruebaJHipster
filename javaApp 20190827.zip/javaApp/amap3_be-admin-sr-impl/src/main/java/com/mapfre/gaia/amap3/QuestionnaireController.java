package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class QuestionnaireController implements IQuestionnaireController{

	private IQuestionnaireBL questionnaireBL;
	
	@Autowired
	public QuestionnaireController(IQuestionnaireBL questionnaireBL) {
		this.questionnaireBL = questionnaireBL;
	}
	
	@Override
	public ResponseEntity<List<QuestionnaireBO>> get() throws CustomException{
		log.debug("QuestionnaireController:get [START]");
		try {
			log.debug("QuestionnaireController:get [END]");
			return ResponseEntity.ok().body(questionnaireBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<QuestionnaireBO> add(@Valid @RequestBody QuestionnaireBO input) throws CustomException{
    	log.debug("QuestionnaireController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			QuestionnaireBO questionnaireBo = questionnaireBL.add(input);
			if (questionnaireBo != null) {
				log.debug("QuestionnaireController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<QuestionnaireBO> update(@PathVariable Long questionnaireId, @RequestBody QuestionnaireBO input) throws CustomException{
    	log.debug("QuestionnaireController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			QuestionnaireBO questionnaireBo = questionnaireBL.update(questionnaireId, input);
			if (questionnaireBo != null) {
				log.debug("QuestionnaireController:update [END]");
			    return ResponseEntity.ok().body(questionnaireBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<QuestionnaireBO> delete(@PathVariable Long questionnaireId) throws CustomException{
        log.debug("QuestionnaireController:delete [START]");
        try {
			boolean questionnaireDeleted = questionnaireBL.delete(questionnaireId);
			if (questionnaireDeleted) {
				log.debug("QuestionnaireController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
