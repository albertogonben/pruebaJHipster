package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class DepartmentController implements IDepartmentController{

	private IDepartmentBL departmentBL;
	
	@Autowired
	public DepartmentController(IDepartmentBL departmentBL) {
		this.departmentBL = departmentBL;
	}
	
	@Override
	public ResponseEntity<List<DepartmentBO>> get() throws CustomException{
		log.debug("DepartmentController:get [START]");
		try {
			log.debug("DepartmentController:get [END]");
			return ResponseEntity.ok().body(departmentBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<DepartmentBO> add(@Valid @RequestBody DepartmentBO input) throws CustomException{
    	log.debug("DepartmentController:add [START]");
    	try {
    		
    	
			DepartmentBO departmentBo = departmentBL.add(input);
			if (departmentBo != null) {
				log.debug("DepartmentController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<DepartmentBO> update(@PathVariable Long departmentId, @RequestBody DepartmentBO input) throws CustomException{
    	log.debug("DepartmentController:update [START]");
    	try {
			DepartmentBO departmentBo = departmentBL.update(departmentId, input);
			if (departmentBo != null) {
				log.debug("DepartmentController:update [END]");
			    return ResponseEntity.ok().body(departmentBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<DepartmentBO> delete(@PathVariable Long departmentId) throws CustomException{
        log.debug("DepartmentController:delete [START]");
        try {
			boolean departmentDeleted = departmentBL.delete(departmentId);
			if (departmentDeleted) {
				log.debug("DepartmentController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
