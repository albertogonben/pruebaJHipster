package com.mapfre.gaia.amap3.validations;

import com.mapfre.gaia.amap3.CelebratedSentenceBO;
import com.mapfre.gaia.amap3.ClosePeriodBO;
import com.mapfre.gaia.amap3.GuideJobBO;
import com.mapfre.gaia.amap3.NewBO;
import com.mapfre.gaia.amap3.ProcessCountryBO;
import com.mapfre.gaia.amap3.ProcessUnitBusinessBO;
import com.mapfre.gaia.amap3.QuestionnaireBO;
import com.mapfre.gaia.amap3.QuestionnaireQuestionBO;
import com.mapfre.gaia.amap3.SectorBO;
import com.mapfre.gaia.amap3.TagBO;
import com.mapfre.gaia.amap3.TypeChangeBO;
import com.mapfre.gaia.amap3.UserAmapBO;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;
import com.mapfre.gaia.amap3.validations.util.ValidationParametersIn;

public class Validation {

	public static boolean validar(Object input) {
		boolean result = true;
		if (input instanceof ClosePeriodBO) {
			result = ValidationDate.validationStringDate(((ClosePeriodBO) input).getDateStart())
					&& ValidationDate.validationStringDate(((ClosePeriodBO) input).getDateFinish());
		} else if (input instanceof TagBO) {
			result = ValidationDate.validationStringDate(((TagBO) input).getDateLastUse());
		} else if (input instanceof SectorBO) {
			result = ValidationDate.validationStringDate(((SectorBO) input).getDateVersion());
		} else if (input instanceof CelebratedSentenceBO) {
			result = ValidationDate.validationStringDate(((CelebratedSentenceBO) input).getDatePublication());
		} else if (input instanceof NewBO) {
			result = ValidationDate.validationStringDate(((NewBO) input).getDatePublication());
		} else if (input instanceof UserAmapBO) {
			result = ValidationDate.validationStringDate(((UserAmapBO) input).getDateAdmission())
					&& ValidationDate.validationStringDate(((UserAmapBO) input).getDateOffSick());
		} else if (input instanceof ProcessUnitBusinessBO) {
			result = ValidationDate.validationStringDate(((ProcessUnitBusinessBO) input).getDateVersion())
					&& ValidationParametersIn.validationParameters(input);
		} else if (input instanceof TypeChangeBO) {
			result = ValidationDate.validationStringDate(((TypeChangeBO) input).getDateChange());
		} else if (input instanceof QuestionnaireBO) {
			result = ValidationDate.validationStringDate(((QuestionnaireBO) input).getDateVersion());
		} else if (input instanceof QuestionnaireQuestionBO) {
			result = ValidationDate.validationStringDate(((QuestionnaireQuestionBO) input).getDateVersion())
					&& ValidationParametersIn.validationParameters(input);
		} else if (input instanceof ProcessCountryBO) {
			result = ValidationDate.validationStringDate(((ProcessCountryBO) input).getDateVersion())
					&& ValidationParametersIn.validationParameters(input);
		} else if (input instanceof GuideJobBO) {
			result = ValidationDate.validationStringDate(((GuideJobBO) input).getDateVersion())
					&& ValidationDate.validationStringDate(((GuideJobBO) input).getDateUse())
					&& ValidationParametersIn.validationParameters(input);
		}
		return result;
	}

}
