package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the USER_TRAINING database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserTrainingBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTrainingPk;

	private Date dateFinish;

	private Date dateInsert;

	private Date dateStart;

	private Date dateUpdate;

	private Date nmrExerciese;

	@Column(name = "XT_CENTER")
	private String txtCenter;

	private String txtComment;

	private String txtTitle;

	private String userInsert;

	private String userUpdate;

	private UserAmapBO userAmap;

}