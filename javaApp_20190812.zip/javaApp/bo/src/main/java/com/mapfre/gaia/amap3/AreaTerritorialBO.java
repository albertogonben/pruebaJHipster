package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The business object class for the AREA_TERRITORIAL database table.
 * 
 */
@Data
@AllArgsConstructor
public class AreaTerritorialBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idAreaTerritoriaPk;

	private String cdAreaTerritorial;

	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal mrkActive;

	private String txtAreaTerritorial;

	private String userInsert;

	private String userUpdate;

	private List<RegionBO> regions;

	public AreaTerritorialBO() {
	}

}