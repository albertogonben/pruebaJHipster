package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the USER_AMAP database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserAmapBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idUserPk;

	private BigDecimal cdNuuma;

	private String dateAdmission;

	private String dateOffSick;

	private byte[] fileCvEn;

	private byte[] fileCvEs;

	private byte[] fileFirm;

	private byte[] filePhoto;

	private BigDecimal isMobilityFunctional;

	private BigDecimal isMobilityGeographic;

	private BigDecimal mrkActive;

	private BigDecimal nmrLaboralHours;

	private BigDecimal nmrMobile;

	private String txtComment;

	private String txtExperience;

	private String txtLastname1;

	private String txtLastname2;

	private String txtMail;

	private String txtName;

	private String typeTreatment;

//	private List<BudgetBO> budgets1;
//
//	private List<BudgetBO> budgets2;
//
//	private List<TaskBO> tasks1;
//
//	private List<TaskBO> tasks2;
//
//	private List<UserAlarmBO> userAlarms;

	private DepartmentBO department;

	private EntamapBO entamap;

	private LanguageBO language;

	private OrganizationalStructureBO organizationalStructure;

	private TypeRoleBO typeRole;

//	private List<UserCategoryBO> userCategories;
//
//	private List<UserLanguageBO> userLanguages;
//
//	private List<UserTrainingBO> userTrainings;

}