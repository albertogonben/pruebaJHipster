package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the TYPE_CERTIFICATION database table.
 * 
 */
@Data
public class TypeCertificationBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeCertificationPk;

	private String cdTypeCertification;

	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal mrkActive;

	private String txtTypeCertification;

	private String userInsert;

	private String userUpdate;

	public TypeCertificationBO() {
	}

}