package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the JOB database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idJobPk;

	private String cdJob;

	private Date dateExpectFinish;

	private Date dateExpectStart;

	private Date dateFinish;

	private Date dateInsert;

	private Date dateStart;

	private Date dateUpdate;

	private BigDecimal isPlannedJob;

	private String txtEffect;

	private String txtNm;

	private String txtNmStandar;

	private String userInsert;

	private String userUpdate;

	private JobBO job;

	private List<JobBO> jobs;

	private ProgramJobBO programJob;

	private TypeJobBO typeJob;

	private TypeReasonCloseBO typeReasonClose;

	private TypeStateJobBO typeStateJob;

	private List<JobDocumentBO> jobDocuments;

	private List<JobIdeaBO> jobIdeas;

	private List<JobLogBO> jobLogs;

	private List<JobOriginBO> jobOrigins;

	private List<JobTagBO> jobTags;

	private List<ProgramJobBO> programJobs;

}