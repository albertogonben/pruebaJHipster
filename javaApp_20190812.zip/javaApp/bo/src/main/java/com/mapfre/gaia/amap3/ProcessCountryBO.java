package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the PROCESS_COUNTRY database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessCountryBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idProcessPk;

	private String cdProceso;

	private Date dateVersion;

	private BigDecimal nmrVersion;

	private String txtNm;

	private List<MatrixRiskValuationBO> matrixRiskValuations;

	private SectorBO sector;

	private TypeProcessBO typeProcess;

}