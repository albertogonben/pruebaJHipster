package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the TYPE_REASON_CHANGE_CATEGORY database table.
 * 
 */
@Data
public class TypeReasonChangeCategoryBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeOtherReasonPk;

	private String cdTypeOtherReason;

	private Date dateInsert;

	private Date dateUpdate;

	private String txtDescription;

	private String userInsert;

	private String userUpdate;

	public TypeReasonChangeCategoryBO() {
	}

}