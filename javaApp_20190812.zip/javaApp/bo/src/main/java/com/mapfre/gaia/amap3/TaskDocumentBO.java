package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the TASK_DOCUMENT database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskDocumentBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idRelationPk;

	private Date dateInsert;

	private Date dateUpdate;

	private Date dateVersion;

	private byte[] fileDocument;

	private BigDecimal nmrSize;

	private BigDecimal nmrVersion;

	private String txtName;

	private String typeDocument;

	private String userInsert;

	private String userUpdate;

	private TaskBO task;

}