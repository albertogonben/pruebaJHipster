package com.mapfre.gaia.amap3;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The business object class for the CELEBRATED_SENTENCES database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CelebratedSentenceBO {

	private long idSentencePk;

	private String cdSentence;

	private String datePublication;

	private String txtAutor;

	private String txtSentence;

}