package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the TYPE_STATE_NODE database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeStateNodeBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeStatePk;

	private String cdTypeState;

	private Date dateInsert;

	private Date dateUpdate;

	private String txtState;

	private String userInsert;

	private String userUpdate;

	private List<TaskBO> tasks;

}