package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the PROCESS_UNIT_BUSINESS database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessUnitBusinessBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idProcessPk;

	private String cdProcess;

	private String dateVersion;

	private BigDecimal nmrVersion;

	private String txtName;

	private ProcessUnitBusinessBO processUnitBusiness;

	private List<ProcessUnitBusinessBO> processUnitBusinesses;

	private TypeProcessBO typeProcess;

	private UnitBusinessBO unitBusiness;

}