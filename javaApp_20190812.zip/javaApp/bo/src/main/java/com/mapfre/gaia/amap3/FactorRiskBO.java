package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the FACTOR_RISK database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class FactorRiskBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idFactorRiskPk;

	private String cdFactor;

	private Date dateInsert;

	private Date dateUpdate;

	private Date dateVersion;

	private BigDecimal mrkActive;

	private BigDecimal nmrExerciese;

	private BigDecimal nmrSize;

	private BigDecimal nmrVersion;

	private String txtName;

	private String txtValues;

	private String userInsert;

	private String userUpdate;

	private List<MatrixRiskValuationBO> matrixRiskValuations;

}