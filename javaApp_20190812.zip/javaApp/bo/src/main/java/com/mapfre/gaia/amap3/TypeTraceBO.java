package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the TYPE_TRACE database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeTraceBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeTracePk;

	private String cdTypeTrace;

	private Date dateInsert;

	private Date dateUpdate;

	private String txtTypeTrace;

	private String userInsert;

	private String userUpdate;

	private List<JobLogBO> jobLogs;

}