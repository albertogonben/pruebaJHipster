package com.mapfre.gaia.amap3.exception;

import lombok.Data;

@Data
public class StackTraceBO {
	
	String declaringClass;
    String methodName;
    String fileName;
    Integer lineNumber;
}
