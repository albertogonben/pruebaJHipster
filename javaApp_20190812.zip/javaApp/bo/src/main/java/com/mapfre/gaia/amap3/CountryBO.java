package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the COUNTRY database table.
 * 
 */
@Data
public class CountryBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idCountryPk;

	private String cdCountry;

	private String cdIso;

	private Date dateInsert;

	private Date dateUpdate;

	private String txtName;

	private String userInsert;

	private String userUpdate;

	private CurrencyBO currency;

	private RegionBO region;

	public CountryBO() {
	}

}