package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the USER_ALARM database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserAlarmBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idAlarmPk;

	private Date dateAdmission;

	private Date dateFinished;

	private Date dateInsert;

	private Date dateMaturity;

	private Date dateReading;

	private Date dateUpdate;

	private String txtFree;

	private String userInsert;

	private String userUpdate;

	private TypeAlarmBO typeAlarm;

	private TypeCriquiteAlarmBO typeCriquiteAlarm;

	private UserAmapBO userAmap;

}