package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the USER_CATEGORY database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserCategoryBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idCategoryUserPk;

	private Date dateFinish;

	private Date dateInsert;

	private Date dateStart;

	private Date dateUpdate;

	private String userInsert;

	private String userUpdate;

	private OrganizationalStructureBO organizationalStructure;

	private TypeCategoryProfessionalBO typeCategoryProfessional;

	private TypeReasonChangeCategoryBO typeReasonChangeCategory;

	private UserAmapBO userAmap;

}