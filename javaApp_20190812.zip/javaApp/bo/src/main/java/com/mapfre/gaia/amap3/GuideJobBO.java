package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the GUIDE_JOB database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GuideJobBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idNodePk;

	private String cdNode;

	private Date dateInsert;

	private Date dateUpdate;

	private Date dateUse;

	private Date dateVersion;

	private BigDecimal nmVersion;

	private BigDecimal nmrUses;

	private String txtNameGuide;

	private String txtNode;

	private String userInsert;

	private String userUpdate;

	private GuideJobBO guideJob;

	private List<GuideJobBO> guideJobs;

	private TypeNodeBO typeNode;

	private List<TaskBO> tasks;

}