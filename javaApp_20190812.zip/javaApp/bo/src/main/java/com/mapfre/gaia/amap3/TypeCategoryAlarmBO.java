package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Data;

/**
 * The business object class for the TYPE_CATEGORY_ALARM database table.
 * 
 */
@Data
public class TypeCategoryAlarmBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeCategoryAlarmPk;

	private String cdTypeCategoryAlarm;

	private Date dateInsert;

	private Date dateUpdate;

	private String txtTypeCategoryAlarm;

	private String userInsert;

	private String userUpdate;

	private List<TypeAlarmBO> typeAlarms;

	public TypeCategoryAlarmBO() {
	}

}