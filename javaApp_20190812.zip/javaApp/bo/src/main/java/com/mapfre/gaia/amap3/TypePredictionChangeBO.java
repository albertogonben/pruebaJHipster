package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the TYPE_PREDICTION_CHANGE database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypePredictionChangeBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypePredictionChangePk;

	private String cdgoTypePrediction;

	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal idTypeCurrencyFk;

	private BigDecimal mrkActive;

	private BigDecimal nmrChange;

	private BigDecimal nmrExerciese;

	private BigDecimal nmrExercieseApply;

	private String txtoTypePrediction;

	private String userInsert;

	private String userUpdate;

}