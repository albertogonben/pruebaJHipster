package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The business object class for the NEWS database table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NewBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idNewsPk;

	private String cdNews;

	private String datePublication;

	private byte[] fileDocument;

	private BigDecimal isPrincipal;

	private String txtName;

	private String txtNews;

	private String txtUrl;

	private String typeDocument;


}