package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the TYPE_ORIGIN_PROGRAM_JOB database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeOriginProgramJobBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeOriginPk;

	private String cdTypeOrigin;

	private Date dateInsert;

	private Date dateUpdate;

	private String txtTypeOrigin;

	private String userInsert;

	private String userUpdate;

	private List<ProgramJobBO> programJobs;

}