package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the MATRIX_RISK database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MatrixRiskBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idMatrixRiskPk;

	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal nmrExerciese;

	private String txtComment;

	private String txtName;

	private String txtStandardName;

	private String userInsert;

	private String userUpdate;

	private CountryBO country;

	private UnitBusinessBO unitBusiness;

	private List<MatrixRiskValuationBO> matrixRiskValuations;

}