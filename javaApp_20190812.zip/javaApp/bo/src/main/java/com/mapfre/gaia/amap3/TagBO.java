package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the TAG database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TagBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTagPk;

	private String cdTag;

	private String dateLastUse;

	private BigDecimal isGlobalTag;

	private BigDecimal mrkActive;

	private BigDecimal nmrUses;

	private String txtDescription;

	private String txtName;


}