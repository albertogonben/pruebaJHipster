package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the UNIT_BUSINESS database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UnitBusinessBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idUnitBusinessPk;

	private String cdUnitBusiness;

	private Date dateInsert;

	private Date dateUpdate;

	private String mrkActive;

	private String txtoUnitBusiness;

	private String userInsert;

	private String userUpdate;

	private List<MatrixRiskBO> matrixRisks;

	private List<ProcessUnitBusinessBO> processUnitBusinesses;

}