package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * The persistent class for the BUDGET database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BudgetBO implements Serializable {
	private static final long serialVersionUID = 1L;

	
	private long idBudgetPk;

	
	private Date dateFinish;


	private Date dateInsert;


	private Date dateStart;

	
	private Date dateUpdate;

	
	private Date dateValitacion;

	
	private BigDecimal nmrExerciese;

	
	private String txtComments;

	
	private String txtName;

	
	private String txtoNameStandard;

	
	private String userInsert;


	private String userUpdate;

	
	private CurrencyBO currency;


	private OrganizationalStructureBO organizationalStructure;


	private TypeStatusBudgetBO typeStatusBudget;

	
	private UserAmapBO userAmap1;


	private UserAmapBO userAmap2;

	
	private List<PaiBO> pais;


	
}