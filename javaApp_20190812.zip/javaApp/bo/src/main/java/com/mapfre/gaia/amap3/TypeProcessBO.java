package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The persistent class for the TYPE_PROCESS database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeProcessBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeProcessPk;

	private String cdTypeProcess;

	private String txtDescription;

}