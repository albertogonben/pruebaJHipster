package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The business object class for the TYPE_ORGANIZATIONAL_STRUCTURE database
 * table.
 * 
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TypeOrganizationalStructureBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypePk;

	private String cdType;

	private Date dateInsert;

	private Date dateUpdate;

	private String mrkAuditable;

	private String txtType;

	private String userInsert;

	private String userUpdate;

//	private List<OrganizationalStructureBO> organizationalStructures;

	

}