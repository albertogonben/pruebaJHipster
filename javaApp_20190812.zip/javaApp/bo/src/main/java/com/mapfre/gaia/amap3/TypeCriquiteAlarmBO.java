package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * The persistent class for the TYPE_CRIQUITE_ALARM database table.
 * 
 */
@Data
public class TypeCriquiteAlarmBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeCritiqueAlarmPk;

	private String cdTypeCritiqueAlarm;

	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal mrkActive;

	private String txtTypeCritiqueAlarm;

	private String userInsert;

	private String userUpdate;

	public TypeCriquiteAlarmBO() {
	}

}