package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Country;
import com.mapfre.gaia.amap3.entities.Currency;
import com.mapfre.gaia.amap3.entities.Entamap;
import com.mapfre.gaia.amap3.mapper.Mapper;
import com.mapfre.gaia.amap3.repositories.EntamapRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;

@Slf4j
@Service
@Transactional
public class EntamapBLImpl implements IEntamapBL {

	private EntamapRepository entamapRepository;
	private MapperFacade mapperEntamap;
	private MapperFacade mapperCountry;
	private MapperFacade mapperCurrency;


	@Autowired
	public EntamapBLImpl(EntamapRepository entamapRepository) {
		this.entamapRepository = entamapRepository;
		this.mapperEntamap = Mapper.generateMapperGeneric(Entamap.class, EntamapBO.class);
		this.mapperCountry = Mapper.generateMapperGeneric(Country.class, CountryBO.class);
		this.mapperCurrency = Mapper.generateMapperGeneric(Currency.class, CurrencyBO.class);

	}

	@Override
	public List<EntamapBO> getAll() {
		log.debug("EntamapBLImpl:getAll [START]");
		
		List<EntamapBO> entamaps = new ArrayList<EntamapBO>();

		List<Entamap> entamapEntities = entamapRepository.findAll();
		for (Entamap entamapEntity : entamapEntities) {
			entamaps.add(mapperEntamap.map(entamapEntity, EntamapBO.class));
		}
		log.debug("EntamapBLImpl:getAll [END]");
		return entamaps;
	}

	@Override
	public EntamapBO add(EntamapBO entamapBO) {
		log.debug("EntamapBLImpl:add [START]");
		Entamap entamapEntity = mapperEntamap.map(entamapBO, Entamap.class);

		Util.getDateUser(entamapEntity, "INSERT");

		log.debug("EntamapBLImpl:add [END]");
		return mapperEntamap.map(entamapRepository.save(entamapEntity), EntamapBO.class);
	}

	@Override
	public EntamapBO update(Long entamapId, EntamapBO entamapBO) {
		log.debug("EntamapBLImpl:update [START]");
		Entamap entamapEntity = entamapRepository.findOne(entamapId);
		if (entamapEntity != null) {
			
			entamapEntity.setCdEntity(entamapBO.getCdEntity());
			entamapEntity.setMrkActive(entamapBO.getMrkActive());
			entamapEntity.setTxtDescription(entamapBO.getTxtDescription());
			entamapEntity.setTxtName(entamapBO.getTxtName());
			entamapEntity.setCountry(mapperCountry.map(entamapBO.getCountry(), Country.class));
			entamapEntity.setCurrency(mapperCurrency.map(entamapBO.getCurrency(), Currency.class));
			entamapEntity.setEntamap(mapperEntamap.map(entamapBO.getEntamap(), Entamap.class));
		
			Util.getDateUser(entamapEntity, "UPDATE");
			
			log.debug("EntamapBLImpl:update [START]");
			return mapperEntamap.map(entamapRepository.save(entamapEntity), EntamapBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long entamapId) {
		log.debug("EntamapBLImpl:delete [START]");
		Entamap entamapEntity = entamapRepository.getOne(entamapId);
		if (entamapEntity != null) {
		
			entamapEntity.setMrkActive("0");
		
			Util.getDateUser(entamapEntity, "UPDATE");
			
			mapperEntamap.map(entamapRepository.save(entamapEntity), EntamapBO.class);
			
			log.debug("EntamapBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
