package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Currency;
import com.mapfre.gaia.amap3.repositories.CurrencyRepository;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;


@Service
@Transactional
public class CurrencyBLImpl implements ICurrencyBL {

    private CurrencyRepository currencyRepository;
    private MapperFacade mapperCurrency;
    
    @Autowired
    public CurrencyBLImpl(CurrencyRepository currencyRepository) {
	this.currencyRepository = currencyRepository;
	
	MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
	mapperFactory.classMap(Currency.class, CurrencyBO.class);
	this.mapperCurrency = mapperFactory.getMapperFacade();
    }
    
    @Override
    public List<CurrencyBO> getlAll() {
	List<CurrencyBO> currencyOut = new ArrayList<CurrencyBO>();
	
	List<Currency> currencyList = currencyRepository.findAll();
	
	for(Currency currency: currencyList) {
	    currencyOut.add(mapperCurrency.map(currency, CurrencyBO.class));
	}
	
	return currencyOut;
    }
    
    @Override
    public CurrencyBO save(CurrencyBO input) {
	Currency output = currencyRepository.save(mapperCurrency.map(input, Currency.class));
	
	if(output != null) {
	    return mapperCurrency.map(output, CurrencyBO.class);
	} else {
	    return null;
	}
    }
    
    @Override
    public CurrencyBO update(Long currencyId, CurrencyBO input) {
	Currency entityToUpdate = this.currencyRepository.getOne(currencyId);
	
	if(entityToUpdate != null) {
	    
	    entityToUpdate.setTxtCurrency(input.getTxtCurrency());
	    
	    Currency output = currencyRepository.save(entityToUpdate);
	    
	    return mapperCurrency.map(output, CurrencyBO.class);
	    
	} else {
	    return null;
	}
	
    }    
    
    
}
