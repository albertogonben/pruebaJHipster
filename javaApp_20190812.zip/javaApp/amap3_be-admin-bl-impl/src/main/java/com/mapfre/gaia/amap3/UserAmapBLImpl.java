package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.UserAmap;
import com.mapfre.gaia.amap3.mapper.StringDateMapper;
import com.mapfre.gaia.amap3.repositories.UserAmapRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.ConverterFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class UserAmapBLImpl implements IUserAmapBL {

	private UserAmapRepository userAmapRepository;
	private MapperFacade mapperUserAmap;

	@Autowired
	public UserAmapBLImpl(UserAmapRepository userAmapRepository) {
		this.userAmapRepository = userAmapRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		
		ConverterFactory converterFactory = mapperFactory.getConverterFactory();
		converterFactory.registerConverter("StringDateMapper", new StringDateMapper());

		mapperFactory.classMap(UserAmap.class, UserAmapBO.class).fieldMap("dateAdmission", "dateAdmission")
				.converter("StringDateMapper").add().fieldMap("dateOffSick", "dateOffSick")
				.converter("StringDateMapper").add().byDefault().register();
		
		this.mapperUserAmap = mapperFactory.getMapperFacade();

	}

	@Override
	public List<UserAmapBO> getAll() {
		log.debug("UserAmapBLImpl:getAll [START]");
		
		List<UserAmapBO> userAmaps = new ArrayList<UserAmapBO>();

		List<UserAmap> userAmapEntities = userAmapRepository.findAll();
		for (UserAmap userAmapEntity : userAmapEntities) {
			
			UserAmapBO result = mapperUserAmap.map(userAmapEntity, UserAmapBO.class);
			
			userAmaps.add(result);
		}
		log.debug("UserAmapBLImpl:getAll [END]");
		return userAmaps;
	}

	@Override
	public UserAmapBO add(UserAmapBO userAmapBO) {
		log.debug("UserAmapBLImpl:add [START]");
		UserAmap userAmapEntity = mapperUserAmap.map(userAmapBO, UserAmap.class);

		Util.getDateUser(userAmapEntity, "INSERT");

		log.debug("UserAmapBLImpl:add [END]");
		return mapperUserAmap.map(userAmapRepository.save(userAmapEntity), UserAmapBO.class);
	}

	@Override
	public UserAmapBO update(Long userAmapId, UserAmapBO userAmapBO) {
		log.debug("UserAmapBLImpl:update [START]");
		UserAmap userAmapEntity = userAmapRepository.findOne(userAmapId);
		if (userAmapEntity != null) {
			
			UserAmap userAux = mapperUserAmap.map(userAmapBO, UserAmap.class);
			
			userAmapEntity.setMrkActive(userAux.getMrkActive());
			userAmapEntity.setCdNuuma(userAux.getCdNuuma());
			userAmapEntity.setDateAdmission(userAux.getDateAdmission());
			userAmapEntity.setDateOffSick(userAux.getDateOffSick());
			userAmapEntity.setIsMobilityFunctional(userAux.getIsMobilityFunctional());
			userAmapEntity.setIsMobilityGeographic(userAux.getIsMobilityGeographic());
			userAmapEntity.setNmrLaboralHours(userAux.getNmrLaboralHours());
			userAmapEntity.setNmrMobile(userAux.getNmrMobile());
			userAmapEntity.setTxtComment(userAux.getTxtComment());
			userAmapEntity.setTxtExperience(userAux.getTxtExperience());
			userAmapEntity.setTxtLastname1(userAux.getTxtLastname1());
			userAmapEntity.setTxtLastname2(userAux.getTxtLastname2());
			userAmapEntity.setTxtMail(userAux.getTxtMail());
			userAmapEntity.setTxtName(userAux.getTxtName());
			userAmapEntity.setTypeTreatment(userAux.getTypeTreatment());
			userAmapEntity.setDepartment(userAux.getDepartment());
			userAmapEntity.setEntamap(userAux.getEntamap());
			userAmapEntity.setLanguage(userAux.getLanguage());
			userAmapEntity.setOrganizationalStructure(userAux.getOrganizationalStructure());
			userAmapEntity.setTypeRole(userAux.getTypeRole());
			
			Util.getDateUser(userAmapEntity, "UPDATE");
			
			log.debug("UserAmapBLImpl:update [START]");
			
			UserAmap result = userAmapRepository.save(userAmapEntity);
			
			return mapperUserAmap.map(result, UserAmapBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long userAmapId) {
		log.debug("UserAmapBLImpl:delete [START]");
		UserAmap userAmapEntity = userAmapRepository.findOne(userAmapId);
		if (userAmapEntity != null) {
		
			userAmapEntity.setMrkActive(new BigDecimal(0));
			
			Util.getDateUser(userAmapEntity, "UPDATE");
			
			mapperUserAmap.map(userAmapRepository.save(userAmapEntity), UserAmapBO.class);
			
			log.debug("UserAmapBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
