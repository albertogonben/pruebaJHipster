package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.OrganizationalStructure;
import com.mapfre.gaia.amap3.repositories.OrganizationalStructureRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class OrganizationalStructureBLImpl implements IOrganizationalStructureBL {

	private OrganizationalStructureRepository organizationalStructureRepository;
	private MapperFacade mapperOrganizationalStructure;

	@Autowired
	public OrganizationalStructureBLImpl(OrganizationalStructureRepository organizationalStructureRepository) {
		this.organizationalStructureRepository = organizationalStructureRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		mapperFactory.classMap(OrganizationalStructure.class, OrganizationalStructureBO.class).byDefault().register();
		this.mapperOrganizationalStructure = mapperFactory.getMapperFacade();

	}

	@Override
	public List<OrganizationalStructureBO> getAll() {
		log.debug("OrganizationalStructureBLImpl:getAll [START]");
		List<OrganizationalStructureBO> listorganizationalStructure = new ArrayList<OrganizationalStructureBO>();

		List<OrganizationalStructure> organizationalStructureEntities = organizationalStructureRepository.findAll();
		for (OrganizationalStructure organizationalStructureEntity : organizationalStructureEntities) {
			listorganizationalStructure.add(
					mapperOrganizationalStructure.map(organizationalStructureEntity, OrganizationalStructureBO.class));
		}
		log.debug("OrganizationalStructureBLImpl:getAll [END]");
		return listorganizationalStructure;
	}

	@Override
	public OrganizationalStructureBO add(OrganizationalStructureBO organizationalStructureBO) {
		log.debug("OrganizationalStructureBLImpl:add [START]");
		OrganizationalStructure organizationalStructureEntity = mapperOrganizationalStructure
				.map(organizationalStructureBO, OrganizationalStructure.class);
		
		Util.getDateUser(organizationalStructureEntity, "INSERT");
		
		log.debug("OrganizationalStructureBLImpl:add [END]");
		return mapperOrganizationalStructure.map(organizationalStructureRepository.save(organizationalStructureEntity),
				OrganizationalStructureBO.class);
	}

	@Override
	public OrganizationalStructureBO update(Long organizationalStructureId,
			OrganizationalStructureBO organizationalStructureBO) {
		log.debug("OrganizationalStructureBLImpl:update [START]");
		
		OrganizationalStructure organizationalStructureEntity = organizationalStructureRepository
				.findOne(organizationalStructureId);
		
		if (organizationalStructureEntity != null) {

			organizationalStructureEntity.setNmrDaysLab(organizationalStructureBO.getNmrDaysLab());
			organizationalStructureEntity.setNmrHoursLab(organizationalStructureBO.getNmrHoursLab());
			organizationalStructureEntity.setMrkActive(organizationalStructureBO.getMrkActive());
			organizationalStructureEntity.setTxtName(organizationalStructureBO.getTxtName());
			
			Util.getDateUser(organizationalStructureEntity, "UPDATE");
			
			// TODO Alberto Setear datos de entrada - Pendiente diseño Front

			log.debug("OrganizationalStructureBLImpl:update [END]");
			return mapperOrganizationalStructure.map(
					organizationalStructureRepository.save(organizationalStructureEntity),
					OrganizationalStructureBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long organizationalStructureId) {
		log.debug("OrganizationalStructureBLImpl:delete [START]");
		OrganizationalStructure organizationalStructureEntity = organizationalStructureRepository
				.findOne(organizationalStructureId);
		if (organizationalStructureEntity != null) {
			organizationalStructureEntity.setMrkActive("0");
			Util.getDateUser(organizationalStructureEntity, "UPDATE");
			
			mapperOrganizationalStructure.map(organizationalStructureRepository.save(organizationalStructureEntity), ClosePeriodBO.class);
			
			log.debug("OrganizationalStructureBLImpl:delete [END]");
			return true;
		}
		return false;
	}

}
