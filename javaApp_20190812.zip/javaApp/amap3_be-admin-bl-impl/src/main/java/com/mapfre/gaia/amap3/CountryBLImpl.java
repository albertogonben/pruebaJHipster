
package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Country;
import com.mapfre.gaia.amap3.entities.Region;
import com.mapfre.gaia.amap3.repositories.CountryRepository;
import com.mapfre.gaia.amap3.repositories.RegionRepository;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Service
@Transactional
public class CountryBLImpl implements ICountryBL {

	private CountryRepository countryRepository;
	private RegionRepository regionRepository;
	private MapperFacade mapperCountry;

	@Autowired
	public CountryBLImpl(CountryRepository countryRepository, MapperFacade mapperCountryRegion) {
		this.countryRepository = countryRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		mapperFactory.classMap(Country.class, CountryBO.class).byDefault().register();
		this.mapperCountry = mapperFactory.getMapperFacade();

	}

	@Override
	public List<CountryBO> getAll() {
		List<CountryBO> listCountry = new ArrayList<CountryBO>();

		List<Country> countryEntities = countryRepository.findAll();
		for (Country countryEntity : countryEntities) {
			listCountry.add(mapperCountry.map(countryEntity, CountryBO.class));
		}
		return listCountry;
	}

	@Override
	public CountryBO add(CountryBO CountryBO) {
		Country CountryEntity = mapperCountry.map(CountryBO, Country.class);
		return mapperCountry.map(countryRepository.save(CountryEntity), CountryBO.class);
	}

	@Override
	public CountryBO update(Long countryId, CountryBO countryBO) {
		Country countryEntity = countryRepository.getOne(countryId);
		if (countryEntity != null) {

			// TODO Alberto Setear datos de entrada Hito III

			return mapperCountry.map(countryRepository.save(countryEntity), CountryBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long countryId) {
		Country closePeriodEntity = countryRepository.findOne(countryId);
		if (closePeriodEntity != null) {
			countryRepository.delete(countryId);
			return true;
		}
		return false;
	}

	@Override
	public CountryBO findCountry(Long countryId) {
		Country countryEntity = countryRepository.findOne(countryId);
		if (countryEntity != null) {
			return mapperCountry.map(countryEntity, CountryBO.class);
		}

		return null;
	}

	@Override
	public CountryRegionBO findRegionCountry(Long countryId, Long regionId) {
		Country countryEntity = countryRepository.findOne(countryId);
		if (countryEntity != null) {

			Region regionEntity = regionRepository.findOne(regionId);
			if (regionEntity != null) {

				Region regions = countryEntity.getRegion();

				if (regions.equals(regionEntity)) {
//					return mapperCountryRegion.map(regionEntity, CountryRegionBO.class);
				}

			}

		}
		return null;
	}

}
