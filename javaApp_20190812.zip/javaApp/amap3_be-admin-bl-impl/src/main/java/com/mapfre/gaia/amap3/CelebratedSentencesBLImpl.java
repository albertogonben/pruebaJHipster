package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.CelebratedSentence;
import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.mapper.StringDateMapper;
import com.mapfre.gaia.amap3.repositories.CelebratedSentencesRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.ConverterFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class CelebratedSentencesBLImpl implements ICelebratedSentencesBL {

	private CelebratedSentencesRepository celebratedSentencesRepository;
	private MapperFacade mapperCelebratedSentence;

	@Autowired
	public CelebratedSentencesBLImpl(CelebratedSentencesRepository celebratedSentenceRepository) {

		this.celebratedSentencesRepository = celebratedSentenceRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		ConverterFactory converterFactory = mapperFactory.getConverterFactory();
		converterFactory.registerConverter("StringDateMapper", new StringDateMapper());

		mapperFactory.classMap(CelebratedSentence.class, CelebratedSentenceBO.class)
				.fieldMap("datePublication", "datePublication").converter("StringDateMapper").add().byDefault()
				.register();
		this.mapperCelebratedSentence = mapperFactory.getMapperFacade();
	}

	@Override
	public List<CelebratedSentenceBO> getAll() throws CustomException {
		log.debug("CelebratedSentencesBLImpl:getAll [START]");

		List<CelebratedSentenceBO> celebratedSentencesOut = new ArrayList<CelebratedSentenceBO>();

		List<CelebratedSentence> celebratedSentencesList = celebratedSentencesRepository.findAll();

		for (CelebratedSentence celebratedSentency : celebratedSentencesList) {
			celebratedSentencesOut.add(mapperCelebratedSentence.map(celebratedSentency, CelebratedSentenceBO.class));
		}

		log.debug("CelebratedSentencesBLImpl:getAll [START]");

		return celebratedSentencesOut;
	}

	@Override
	public CelebratedSentenceBO save(CelebratedSentenceBO input) {
		log.debug("CelebratedSentencesBLImpl:save [START]");

		CelebratedSentence entity = mapperCelebratedSentence.map(input, CelebratedSentence.class);

		Util.getDateUser(entity, "INSERT");
		
		CelebratedSentence output = celebratedSentencesRepository.save(entity);

		if (output != null) {

			log.debug("CelebratedSentencesBLImpl:save [END]");
			return mapperCelebratedSentence.map(output, CelebratedSentenceBO.class);
		} else {
			return null;
		}

	}

	@Override
	public CelebratedSentenceBO update(Long id, CelebratedSentenceBO input) {
		log.debug("CelebratedSentencesBLImpl:update [START]");
		CelebratedSentence entityToUpdate = celebratedSentencesRepository.getOne(id);

		if (entityToUpdate != null) {

			Util.getDateUser(entityToUpdate, "UPDATE");
			
			entityToUpdate.setTxtAutor(input.getTxtAutor());
			entityToUpdate.setTxtSentence(input.getTxtSentence());

			CelebratedSentence output = celebratedSentencesRepository.save(entityToUpdate);

			log.debug("CelebratedSentencesBLImpl:update [END]");
			return mapperCelebratedSentence.map(output, CelebratedSentenceBO.class);

		} else {
			return null;
		}

	}

	@Override
	public boolean delete(Long id) {
		log.debug("CelebratedSentencesBLImpl:delete [START]");
		CelebratedSentence entityToDelete = celebratedSentencesRepository.findOne(id);

		if (entityToDelete != null) {
			celebratedSentencesRepository.delete(id);
			log.debug("CelebratedSentencesBLImpl:delete [END]");
			return true;
		} else {
			return false;
		}

	}

}
