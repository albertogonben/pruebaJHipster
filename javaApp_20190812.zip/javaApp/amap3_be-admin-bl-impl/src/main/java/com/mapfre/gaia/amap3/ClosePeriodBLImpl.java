package com.mapfre.gaia.amap3;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.ClosePeriod;
import com.mapfre.gaia.amap3.entities.TypeClosePeriod;
import com.mapfre.gaia.amap3.mapper.StringDateMapper;
import com.mapfre.gaia.amap3.repositories.ClosePeriodRepository;
import com.mapfre.gaia.amap3.utils.Util;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.ConverterFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class ClosePeriodBLImpl implements IClosePeriodBL {

	private ClosePeriodRepository closePeriodRepository;
	private MapperFacade mapperClosePeriod;
	private MapperFacade mapperTypeClosePeriod;

	@Autowired
	public ClosePeriodBLImpl(ClosePeriodRepository closePeriodRepository) {
		this.closePeriodRepository = closePeriodRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		ConverterFactory converterFactory = mapperFactory.getConverterFactory();
		converterFactory.registerConverter("StringDateMapper", new StringDateMapper());

		mapperFactory.classMap(ClosePeriod.class, ClosePeriodBO.class).fieldMap("dateStart", "dateStart")
				.converter("StringDateMapper").add().fieldMap("dateFinish", "dateFinish").converter("StringDateMapper")
				.add().byDefault().register();
		this.mapperClosePeriod = mapperFactory.getMapperFacade();

		MapperFactory mapperFactoryAux = new DefaultMapperFactory.Builder().build();
		mapperFactoryAux.classMap(TypeClosePeriod.class, TypeClosePeriodBO.class).byDefault().register();
		this.mapperTypeClosePeriod = mapperFactoryAux.getMapperFacade();
	}

	@Override
	public List<ClosePeriodBO> getAll() {
		log.debug("ClosePeriodBLImpl:getAll [START]");
		
		List<ClosePeriodBO> closePeriods = new ArrayList<ClosePeriodBO>();

		List<ClosePeriod> closePeriodEntities = closePeriodRepository.findAll();
		for (ClosePeriod closePeriodEntity : closePeriodEntities) {
			closePeriods.add(mapperClosePeriod.map(closePeriodEntity, ClosePeriodBO.class));
		}
		log.debug("ClosePeriodBLImpl:getAll [END]");
		return closePeriods;
	}

	//TODO No necesario
	@Override
	public ClosePeriodBO add(ClosePeriodBO closePeriodBO) {
		log.debug("ClosePeriodBLImpl:add [START]");
		ClosePeriod closePeriodEntity = mapperClosePeriod.map(closePeriodBO, ClosePeriod.class);

		Util.getDateUser(closePeriodEntity, "INSERT");

		log.debug("ClosePeriodBLImpl:add [END]");
		return mapperClosePeriod.map(closePeriodRepository.save(closePeriodEntity), ClosePeriodBO.class);
	}

	@Override
	public ClosePeriodBO update(Long closePeriodId, ClosePeriodBO closePeriodBO) {
		log.debug("ClosePeriodBLImpl:update [START]");
		ClosePeriod closePeriodEntity = closePeriodRepository.getOne(closePeriodId);
		
		ClosePeriod closePeriodAux = mapperClosePeriod.map(closePeriodBO, ClosePeriod.class);
		
		if (closePeriodEntity != null) {
			closePeriodEntity.setTypeClosePeriod(
					mapperTypeClosePeriod.map(closePeriodBO.getTypeClosePeriod(), TypeClosePeriod.class));
			closePeriodEntity.setMrkActive(closePeriodAux.getMrkActive());
			closePeriodEntity.setDateStart(closePeriodAux.getDateStart());
			closePeriodEntity.setDateFinish(closePeriodAux.getDateFinish());

			Util.getDateUser(closePeriodEntity, "UPDATE");
			
			log.debug("ClosePeriodBLImpl:update [END]");
			return mapperClosePeriod.map(closePeriodRepository.save(closePeriodEntity), ClosePeriodBO.class);
		}

		return null;
	}

	//TODO No necesario
	@Override
	public boolean delete(Long closePeriodId) {
		log.debug("ClosePeriodBLImpl:delete [START]");
		ClosePeriod closePeriodEntity = closePeriodRepository.getOne(closePeriodId);
		if (closePeriodEntity != null) {
			closePeriodEntity.setMrkActive(new BigDecimal(0));
			Util.getDateUser(closePeriodEntity, "UPDATE");
			
			mapperClosePeriod.map(closePeriodRepository.save(closePeriodEntity), ClosePeriodBO.class);
			
			log.debug("ClosePeriodBLImpl:delete [END]");
			return true;
		}

		return false;
	}

}
