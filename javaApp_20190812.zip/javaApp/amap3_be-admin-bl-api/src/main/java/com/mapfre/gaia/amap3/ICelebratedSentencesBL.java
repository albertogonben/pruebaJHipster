package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mapfre.gaia.amap3.exception.CustomException;

@Service
public interface ICelebratedSentencesBL {

	/**
	 * Get all celebrated sentences
	 * @return
	 * @throws CustomException 
	 */
	List<CelebratedSentenceBO> getAll() throws CustomException;
	
	/**
	 * Creation of a celebrated sentence
	 * @param input
	 * @return
	 */
	CelebratedSentenceBO save(CelebratedSentenceBO input);
	
	/**
	 * Update of a celebrated sentence
	 * @param id
	 * @param input
	 * @return
	 */
	CelebratedSentenceBO update(Long id, CelebratedSentenceBO input);
	
	/**
	 * Delete of a celebrated sentence
	 * @param id
	 * @return
	 */
	boolean delete(Long id);
	
}
