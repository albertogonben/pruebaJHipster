package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeSpecialityController implements ITypeSpecialityController{

	private ITypeSpecialityBL typeSpecialityBL;
	
	@Autowired
	public TypeSpecialityController(ITypeSpecialityBL typeSpecialityBL) {
		this.typeSpecialityBL = typeSpecialityBL;
	}
	
	@Override
	public ResponseEntity<List<TypeSpecialityBO>> get() throws CustomException{
		log.debug("TypeSpecialityController:get [START]");
		try {
			log.debug("TypeSpecialityController:get [END]");
			return ResponseEntity.ok().body(typeSpecialityBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeSpecialityBO> add(@Valid @RequestBody TypeSpecialityBO input) throws CustomException{
    	log.debug("TypeSpecialityController:add [START]");
    	try {
    		
    	
			TypeSpecialityBO typeSpecialityBo = typeSpecialityBL.add(input);
			if (typeSpecialityBo != null) {
				log.debug("TypeSpecialityController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeSpecialityBO> update(@PathVariable Long typeSpecialityId, @RequestBody TypeSpecialityBO input) throws CustomException{
    	log.debug("TypeSpecialityController:update [START]");
    	try {
			TypeSpecialityBO typeSpecialityBo = typeSpecialityBL.update(typeSpecialityId, input);
			if (typeSpecialityBo != null) {
				log.debug("TypeSpecialityController:update [END]");
			    return ResponseEntity.ok().body(typeSpecialityBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeSpecialityBO> delete(@PathVariable Long typeSpecialityId) throws CustomException{
        log.debug("TypeSpecialityController:delete [START]");
        try {
			boolean typeSpecialityDeleted = typeSpecialityBL.delete(typeSpecialityId);
			if (typeSpecialityDeleted) {
				log.debug("TypeSpecialityController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
