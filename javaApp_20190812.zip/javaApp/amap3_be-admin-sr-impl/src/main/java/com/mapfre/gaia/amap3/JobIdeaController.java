package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class JobIdeaController implements IJobIdeaController{

	private IJobIdeaBL jobIdeaBL;
	
	@Autowired
	public JobIdeaController(IJobIdeaBL jobIdeaBL) {
		this.jobIdeaBL = jobIdeaBL;
	}
	
	@Override
	public ResponseEntity<List<JobIdeaBO>> get() throws CustomException{
		log.debug("JobIdeaController:get [START]");
		try {
			log.debug("JobIdeaController:get [END]");
			return ResponseEntity.ok().body(jobIdeaBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<JobIdeaBO> add(@Valid @RequestBody JobIdeaBO input) throws CustomException{
    	log.debug("JobIdeaController:add [START]");
    	try {
    		
    	
			JobIdeaBO jobIdeaBo = jobIdeaBL.add(input);
			if (jobIdeaBo != null) {
				log.debug("JobIdeaController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<JobIdeaBO> update(@PathVariable Long jobIdeaId, @RequestBody JobIdeaBO input) throws CustomException{
    	log.debug("JobIdeaController:update [START]");
    	try {
			JobIdeaBO jobIdeaBo = jobIdeaBL.update(jobIdeaId, input);
			if (jobIdeaBo != null) {
				log.debug("JobIdeaController:update [END]");
			    return ResponseEntity.ok().body(jobIdeaBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<JobIdeaBO> delete(@PathVariable Long jobIdeaId) throws CustomException{
        log.debug("JobIdeaController:delete [START]");
        try {
			boolean jobIdeaDeleted = jobIdeaBL.delete(jobIdeaId);
			if (jobIdeaDeleted) {
				log.debug("JobIdeaController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
