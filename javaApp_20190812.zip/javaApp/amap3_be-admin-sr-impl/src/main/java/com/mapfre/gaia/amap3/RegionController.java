package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class RegionController implements IRegionController{

	private IRegionBL regionBL;
	
	@Autowired
	public RegionController(IRegionBL regionBL) {
		this.regionBL = regionBL;
	}
	
	@Override
	public ResponseEntity<List<RegionBO>> get() throws CustomException{
		log.debug("RegionController:get [START]");
		try {
			log.debug("RegionController:get [END]");
			return ResponseEntity.ok().body(regionBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<RegionBO> add(@Valid @RequestBody RegionBO input) throws CustomException{
    	log.debug("RegionController:add [START]");
    	try {
    		
    	
			RegionBO regionBo = regionBL.add(input);
			if (regionBo != null) {
				log.debug("RegionController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<RegionBO> update(@PathVariable Long regionId, @RequestBody RegionBO input) throws CustomException{
    	log.debug("RegionController:update [START]");
    	try {
			RegionBO regionBo = regionBL.update(regionId, input);
			if (regionBo != null) {
				log.debug("RegionController:update [END]");
			    return ResponseEntity.ok().body(regionBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<RegionBO> delete(@PathVariable Long regionId) throws CustomException{
        log.debug("RegionController:delete [START]");
        try {
			boolean regionDeleted = regionBL.delete(regionId);
			if (regionDeleted) {
				log.debug("RegionController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
