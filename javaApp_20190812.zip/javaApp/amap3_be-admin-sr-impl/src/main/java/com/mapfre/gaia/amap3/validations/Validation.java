package com.mapfre.gaia.amap3.validations;

import com.mapfre.gaia.amap3.CelebratedSentenceBO;
import com.mapfre.gaia.amap3.ClosePeriodBO;
import com.mapfre.gaia.amap3.NewBO;
import com.mapfre.gaia.amap3.ProcessUnitBusinessBO;
import com.mapfre.gaia.amap3.SectorBO;
import com.mapfre.gaia.amap3.TagBO;
import com.mapfre.gaia.amap3.UserAmapBO;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

public class Validation {

	public static boolean validar(Object input) {
		boolean result = true;
		if (input instanceof ClosePeriodBO) {
			result = ValidationDate.validationStringDate(((ClosePeriodBO) input).getDateStart())
					&& ValidationDate.validationStringDate(((ClosePeriodBO) input).getDateFinish());
		} else if (input instanceof TagBO) {
			result = ValidationDate.validationStringDate(((TagBO) input).getDateLastUse());
		} else if (input instanceof SectorBO) {
			result = ValidationDate.validationStringDate(((SectorBO) input).getDateVersion());
		}else if (input instanceof CelebratedSentenceBO) {
			result = ValidationDate.validationStringDate(((CelebratedSentenceBO) input).getDatePublication());
		}else if(input instanceof NewBO){
			result = ValidationDate.validationStringDate(((NewBO) input).getDatePublication());
		}else if(input instanceof UserAmapBO){
			result = ValidationDate.validationStringDate(((UserAmapBO) input).getDateAdmission()) 
					&& ValidationDate.validationStringDate(((UserAmapBO) input).getDateOffSick());
		}else if(input instanceof ProcessUnitBusinessBO){
			result = ValidationDate.validationStringDate(((ProcessUnitBusinessBO) input).getDateVersion());
		}
		return result;
	}

}
