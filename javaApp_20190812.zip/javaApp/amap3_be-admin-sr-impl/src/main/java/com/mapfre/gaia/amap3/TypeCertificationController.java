package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeCertificationController implements ITypeCertificationController{

	private ITypeCertificationBL typeCertificationBL;
	
	@Autowired
	public TypeCertificationController(ITypeCertificationBL typeCertificationBL) {
		this.typeCertificationBL = typeCertificationBL;
	}
	
	@Override
	public ResponseEntity<List<TypeCertificationBO>> get() throws CustomException{
		log.debug("TypeCertificationController:get [START]");
		try {
			log.debug("TypeCertificationController:get [END]");
			return ResponseEntity.ok().body(typeCertificationBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeCertificationBO> add(@Valid @RequestBody TypeCertificationBO input) throws CustomException{
    	log.debug("TypeCertificationController:add [START]");
    	try {
    		
    	
			TypeCertificationBO typeCertificationBo = typeCertificationBL.add(input);
			if (typeCertificationBo != null) {
				log.debug("TypeCertificationController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeCertificationBO> update(@PathVariable Long typeCertificationId, @RequestBody TypeCertificationBO input) throws CustomException{
    	log.debug("TypeCertificationController:update [START]");
    	try {
			TypeCertificationBO typeCertificationBo = typeCertificationBL.update(typeCertificationId, input);
			if (typeCertificationBo != null) {
				log.debug("TypeCertificationController:update [END]");
			    return ResponseEntity.ok().body(typeCertificationBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeCertificationBO> delete(@PathVariable Long typeCertificationId) throws CustomException{
        log.debug("TypeCertificationController:delete [START]");
        try {
			boolean typeCertificationDeleted = typeCertificationBL.delete(typeCertificationId);
			if (typeCertificationDeleted) {
				log.debug("TypeCertificationController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
