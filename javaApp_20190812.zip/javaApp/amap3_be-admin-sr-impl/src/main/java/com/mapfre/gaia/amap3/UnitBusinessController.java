package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class UnitBusinessController implements IUnitBusinessController{

	private IUnitBusinessBL unitBusinessBL;
	
	@Autowired
	public UnitBusinessController(IUnitBusinessBL unitBusinessBL) {
		this.unitBusinessBL = unitBusinessBL;
	}
	
	@Override
	public ResponseEntity<List<UnitBusinessBO>> get() throws CustomException{
		log.debug("UnitBusinessController:get [START]");
		try {
			log.debug("UnitBusinessController:get [END]");
			return ResponseEntity.ok().body(unitBusinessBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<UnitBusinessBO> add(@Valid @RequestBody UnitBusinessBO input) throws CustomException{
    	log.debug("UnitBusinessController:add [START]");
    	try {
    		
    	
			UnitBusinessBO unitBusinessBo = unitBusinessBL.add(input);
			if (unitBusinessBo != null) {
				log.debug("UnitBusinessController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UnitBusinessBO> update(@PathVariable Long unitBusinessId, @RequestBody UnitBusinessBO input) throws CustomException{
    	log.debug("UnitBusinessController:update [START]");
    	try {
			UnitBusinessBO unitBusinessBo = unitBusinessBL.update(unitBusinessId, input);
			if (unitBusinessBo != null) {
				log.debug("UnitBusinessController:update [END]");
			    return ResponseEntity.ok().body(unitBusinessBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UnitBusinessBO> delete(@PathVariable Long unitBusinessId) throws CustomException{
        log.debug("UnitBusinessController:delete [START]");
        try {
			boolean unitBusinessDeleted = unitBusinessBL.delete(unitBusinessId);
			if (unitBusinessDeleted) {
				log.debug("UnitBusinessController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
