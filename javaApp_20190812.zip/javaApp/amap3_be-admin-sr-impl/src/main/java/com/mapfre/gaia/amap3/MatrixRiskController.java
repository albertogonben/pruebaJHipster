package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class MatrixRiskController implements IMatrixRiskController{

	private IMatrixRiskBL matrixRiskBL;
	
	@Autowired
	public MatrixRiskController(IMatrixRiskBL matrixRiskBL) {
		this.matrixRiskBL = matrixRiskBL;
	}
	
	@Override
	public ResponseEntity<List<MatrixRiskBO>> get() throws CustomException{
		log.debug("MatrixRiskController:get [START]");
		try {
			log.debug("MatrixRiskController:get [END]");
			return ResponseEntity.ok().body(matrixRiskBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<MatrixRiskBO> add(@Valid @RequestBody MatrixRiskBO input) throws CustomException{
    	log.debug("MatrixRiskController:add [START]");
    	try {
    		
    	
			MatrixRiskBO matrixRiskBo = matrixRiskBL.add(input);
			if (matrixRiskBo != null) {
				log.debug("MatrixRiskController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<MatrixRiskBO> update(@PathVariable Long matrixRiskId, @RequestBody MatrixRiskBO input) throws CustomException{
    	log.debug("MatrixRiskController:update [START]");
    	try {
			MatrixRiskBO matrixRiskBo = matrixRiskBL.update(matrixRiskId, input);
			if (matrixRiskBo != null) {
				log.debug("MatrixRiskController:update [END]");
			    return ResponseEntity.ok().body(matrixRiskBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<MatrixRiskBO> delete(@PathVariable Long matrixRiskId) throws CustomException{
        log.debug("MatrixRiskController:delete [START]");
        try {
			boolean matrixRiskDeleted = matrixRiskBL.delete(matrixRiskId);
			if (matrixRiskDeleted) {
				log.debug("MatrixRiskController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
