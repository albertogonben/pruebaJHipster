package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeReasonChangeCategoryController implements ITypeReasonChangeCategoryController{

	private ITypeReasonChangeCategoryBL typeReasonChangeCategoryBL;
	
	@Autowired
	public TypeReasonChangeCategoryController(ITypeReasonChangeCategoryBL typeReasonChangeCategoryBL) {
		this.typeReasonChangeCategoryBL = typeReasonChangeCategoryBL;
	}
	
	@Override
	public ResponseEntity<List<TypeReasonChangeCategoryBO>> get() throws CustomException{
		log.debug("TypeReasonChangeCategoryController:get [START]");
		try {
			log.debug("TypeReasonChangeCategoryController:get [END]");
			return ResponseEntity.ok().body(typeReasonChangeCategoryBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeReasonChangeCategoryBO> add(@Valid @RequestBody TypeReasonChangeCategoryBO input) throws CustomException{
    	log.debug("TypeReasonChangeCategoryController:add [START]");
    	try {
    		
    	
			TypeReasonChangeCategoryBO typeReasonChangeCategoryBo = typeReasonChangeCategoryBL.add(input);
			if (typeReasonChangeCategoryBo != null) {
				log.debug("TypeReasonChangeCategoryController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeReasonChangeCategoryBO> update(@PathVariable Long typeReasonChangeCategoryId, @RequestBody TypeReasonChangeCategoryBO input) throws CustomException{
    	log.debug("TypeReasonChangeCategoryController:update [START]");
    	try {
			TypeReasonChangeCategoryBO typeReasonChangeCategoryBo = typeReasonChangeCategoryBL.update(typeReasonChangeCategoryId, input);
			if (typeReasonChangeCategoryBo != null) {
				log.debug("TypeReasonChangeCategoryController:update [END]");
			    return ResponseEntity.ok().body(typeReasonChangeCategoryBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeReasonChangeCategoryBO> delete(@PathVariable Long typeReasonChangeCategoryId) throws CustomException{
        log.debug("TypeReasonChangeCategoryController:delete [START]");
        try {
			boolean typeReasonChangeCategoryDeleted = typeReasonChangeCategoryBL.delete(typeReasonChangeCategoryId);
			if (typeReasonChangeCategoryDeleted) {
				log.debug("TypeReasonChangeCategoryController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
