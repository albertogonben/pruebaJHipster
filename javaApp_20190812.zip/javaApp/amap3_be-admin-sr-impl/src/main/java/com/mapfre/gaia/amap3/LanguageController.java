package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.util.ValidationDate;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class LanguageController implements ILanguageController{

	private ILanguageBL languageBL;
	
	@Autowired
	public LanguageController(ILanguageBL languageBL) {
		this.languageBL = languageBL;
	}
	
	@Override
	public ResponseEntity<List<LanguageBO>> get() throws CustomException{
		log.debug("LanguageController:get [START]");
		try {
			log.debug("LanguageController:get [END]");
			return ResponseEntity.ok().body(languageBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<LanguageBO> add(@Valid @RequestBody LanguageBO input) throws CustomException{
    	log.debug("LanguageController:add [START]");
    	try {
    		
    	
			LanguageBO languageBo = languageBL.add(input);
			if (languageBo != null) {
				log.debug("LanguageController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<LanguageBO> update(@PathVariable Long languageId, @RequestBody LanguageBO input) throws CustomException{
    	log.debug("LanguageController:update [START]");
    	try {
			LanguageBO languageBo = languageBL.update(languageId, input);
			if (languageBo != null) {
				log.debug("LanguageController:update [END]");
			    return ResponseEntity.ok().body(languageBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<LanguageBO> delete(@PathVariable Long languageId) throws CustomException{
        log.debug("LanguageController:delete [START]");
        try {
			boolean languageDeleted = languageBL.delete(languageId);
			if (languageDeleted) {
				log.debug("LanguageController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
