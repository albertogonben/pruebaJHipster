package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class EntamapController implements IEntamapController{

	private IEntamapBL entamapBL;
	
	@Autowired
	public EntamapController(IEntamapBL entamapBL) {
		this.entamapBL = entamapBL;
	}
	
	@Override
	public ResponseEntity<List<EntamapBO>> get() throws CustomException{
		log.debug("EntamapController:get [START]");
		try {
			log.debug("EntamapController:get [END]");
			return ResponseEntity.ok().body(entamapBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<EntamapBO> add(@Valid @RequestBody EntamapBO input) throws CustomException{
    	log.debug("EntamapController:add [START]");
    	try {
    	
			EntamapBO entamapBo = entamapBL.add(input);
			if (entamapBo != null) {
				log.debug("EntamapController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<EntamapBO> update(@PathVariable Long entamapId, @RequestBody EntamapBO input) throws CustomException{
    	log.debug("EntamapController:update [START]");
    	try {
			EntamapBO entamapBo = entamapBL.update(entamapId, input);
			if (entamapBo != null) {
				log.debug("EntamapController:update [END]");
			    return ResponseEntity.ok().body(entamapBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<EntamapBO> delete(@PathVariable Long entamapId) throws CustomException{
        log.debug("EntamapController:delete [START]");
        try {
			boolean entamapDeleted = entamapBL.delete(entamapId);
			if (entamapDeleted) {
				log.debug("EntamapController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
