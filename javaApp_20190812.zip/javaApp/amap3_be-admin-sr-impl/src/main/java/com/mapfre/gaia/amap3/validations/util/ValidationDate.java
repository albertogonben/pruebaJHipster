package com.mapfre.gaia.amap3.validations.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class ValidationDate {

	public static boolean validationStringDate(String date) {
		log.debug("ValidationDate.validationStringDate [START]");
		try {
			SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
			formatoFecha.setLenient(false);
			formatoFecha.parse(date);
		} catch (ParseException e) {
			log.debug("ValidationDate.validationStringDate: "+e.getMessage());
			return false;
		}
		log.debug("ValidationDate.validationStringDate [END]");
		return true;
	}

}
