package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class OrganizationalStructureController implements IOrganizationalStructureController {

	private IOrganizationalStructureBL organizationalStructureBL;

	@Autowired
	public OrganizationalStructureController(IOrganizationalStructureBL organizationalStructureBL) {
		this.organizationalStructureBL = organizationalStructureBL;
	}

	@Override
	public ResponseEntity<List<OrganizationalStructureBO>> get() {
		try {
			return ResponseEntity.ok().body(organizationalStructureBL.getAll());
		} catch (Exception e) {
			log.error("organizationalStructureController:get", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<OrganizationalStructureBO> add(@Valid @RequestBody OrganizationalStructureBO input) {
		try {
			OrganizationalStructureBO organizationalStructureBO = organizationalStructureBL.add(input);
			if (organizationalStructureBO != null) {
				return ResponseEntity.ok().build();
			}
			return ResponseEntity.status(HttpStatus.CONFLICT).build();
		} catch (Exception e) {
			log.error("organizationalStructureController:add", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<OrganizationalStructureBO> update(@PathVariable Long organizationalStructureId,
			@RequestBody OrganizationalStructureBO input) {
		try {
			OrganizationalStructureBO organizationalStructureBO = organizationalStructureBL
					.update(organizationalStructureId, input);
			if (organizationalStructureBO != null) {
				return ResponseEntity.ok().body(organizationalStructureBO);
			}
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			log.error("organizationalStructureController:update", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<OrganizationalStructureBO> delete(@PathVariable Long organizationalStructureId) {
		try {
			boolean organizationalStructureDeleted = organizationalStructureBL.delete(organizationalStructureId);
			if (organizationalStructureDeleted) {
				return ResponseEntity.noContent().build();
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			log.error("organizationalStructureController:delete", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

}
