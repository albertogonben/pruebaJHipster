package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the CURRENCY database table.
 * 
 */
@Entity
@NamedQuery(name="Currency.findAll", query="SELECT c FROM Currency c")
public class Currency implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_CURRENCY_PK")
	private long idCurrencyPk;

	@Column(name="CD_CURRENCY")
	private String cdCurrency;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_CURRENCY")
	private String txtCurrency;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Budget
//	@OneToMany(mappedBy="currency")
//	private List<Budget> budgets;

	//bi-directional many-to-one association to Country
//	@OneToMany(mappedBy="currency")
//	private List<Country> countries;

	//bi-directional many-to-one association to Entamap
//	@OneToMany(mappedBy="currency")
//	private List<Entamap> entamaps;

	//bi-directional many-to-one association to OrganizationalStructure
//	@OneToMany(mappedBy="currency")
//	private List<OrganizationalStructure> organizationalStructures;

	public Currency() {
	}

	public long getIdCurrencyPk() {
		return this.idCurrencyPk;
	}

	public void setIdCurrencyPk(long idCurrencyPk) {
		this.idCurrencyPk = idCurrencyPk;
	}

	public String getCdCurrency() {
		return this.cdCurrency;
	}

	public void setCdCurrency(String cdCurrency) {
		this.cdCurrency = cdCurrency;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtCurrency() {
		return this.txtCurrency;
	}

	public void setTxtCurrency(String txtCurrency) {
		this.txtCurrency = txtCurrency;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

//	public List<Budget> getBudgets() {
//		return this.budgets;
//	}
//
//	public void setBudgets(List<Budget> budgets) {
//		this.budgets = budgets;
//	}
//
//	public Budget addBudget(Budget budget) {
//		getBudgets().add(budget);
//		budget.setCurrency(this);
//
//		return budget;
//	}
//
//	public Budget removeBudget(Budget budget) {
//		getBudgets().remove(budget);
//		budget.setCurrency(null);
//
//		return budget;
//	}
//
//	public List<Country> getCountries() {
//		return this.countries;
//	}
//
//	public void setCountries(List<Country> countries) {
//		this.countries = countries;
//	}
//
//	public Country addCountry(Country country) {
//		getCountries().add(country);
//		country.setCurrency(this);
//
//		return country;
//	}
//
//	public Country removeCountry(Country country) {
//		getCountries().remove(country);
//		country.setCurrency(null);
//
//		return country;
//	}
//
//	public List<Entamap> getEntamaps() {
//		return this.entamaps;
//	}
//
//	public void setEntamaps(List<Entamap> entamaps) {
//		this.entamaps = entamaps;
//	}
//
//	public Entamap addEntamap(Entamap entamap) {
//		getEntamaps().add(entamap);
//		entamap.setCurrency(this);
//
//		return entamap;
//	}
//
//	public Entamap removeEntamap(Entamap entamap) {
//		getEntamaps().remove(entamap);
//		entamap.setCurrency(null);
//
//		return entamap;
//	}
//
//	public List<OrganizationalStructure> getOrganizationalStructures() {
//		return this.organizationalStructures;
//	}
//
//	public void setOrganizationalStructures(List<OrganizationalStructure> organizationalStructures) {
//		this.organizationalStructures = organizationalStructures;
//	}
//
//	public OrganizationalStructure addOrganizationalStructure(OrganizationalStructure organizationalStructure) {
//		getOrganizationalStructures().add(organizationalStructure);
//		organizationalStructure.setCurrency(this);
//
//		return organizationalStructure;
//	}
//
//	public OrganizationalStructure removeOrganizationalStructure(OrganizationalStructure organizationalStructure) {
//		getOrganizationalStructures().remove(organizationalStructure);
//		organizationalStructure.setCurrency(null);
//
//		return organizationalStructure;
//	}

}