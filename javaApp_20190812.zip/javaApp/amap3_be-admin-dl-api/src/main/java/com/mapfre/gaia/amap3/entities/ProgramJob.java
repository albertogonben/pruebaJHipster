package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PROGRAM_JOB database table.
 * 
 */
@Entity
@Table(name="PROGRAM_JOB")
@NamedQuery(name="ProgramJob.findAll", query="SELECT p FROM ProgramJob p")
public class ProgramJob implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_NODE_PK")
	private long idNodePk;

	@Column(name="CD_NODE")
	private String cdNode;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_VERSION")
	private Date dateVersion;

	@Column(name="IS_IMPORTANT")
	private BigDecimal isImportant;

	@Column(name="NMR_VERSION")
	private BigDecimal nmrVersion;

	@Column(name="TXT_NODE")
	private String txtNode;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Job
	@OneToMany(mappedBy="programJob")
	private List<Job> jobs;

	//bi-directional many-to-one association to Job
	@ManyToOne
	@JoinColumn(name="ID_JOB_FK")
	private Job job;

	//bi-directional many-to-one association to ProgramJob
	@ManyToOne
	@JoinColumn(name="ID_NODE_FATHER_FK")
	private ProgramJob programJob;

	//bi-directional many-to-one association to ProgramJob
	@OneToMany(mappedBy="programJob")
	private List<ProgramJob> programJobs;

	//bi-directional many-to-one association to TypeNode
	@ManyToOne
	@JoinColumn(name="ID_TYPE_NODE_FK")
	private TypeNode typeNode;

	//bi-directional many-to-one association to TypeOriginProgramJob
	@ManyToOne
	@JoinColumn(name="ID_TYPE_ORIGIN_JOB_FK")
	private TypeOriginProgramJob typeOriginProgramJob;

	public ProgramJob() {
	}

	public long getIdNodePk() {
		return this.idNodePk;
	}

	public void setIdNodePk(long idNodePk) {
		this.idNodePk = idNodePk;
	}

	public String getCdNode() {
		return this.cdNode;
	}

	public void setCdNode(String cdNode) {
		this.cdNode = cdNode;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}

	public BigDecimal getIsImportant() {
		return this.isImportant;
	}

	public void setIsImportant(BigDecimal isImportant) {
		this.isImportant = isImportant;
	}

	public BigDecimal getNmrVersion() {
		return this.nmrVersion;
	}

	public void setNmrVersion(BigDecimal nmrVersion) {
		this.nmrVersion = nmrVersion;
	}

	public String getTxtNode() {
		return this.txtNode;
	}

	public void setTxtNode(String txtNode) {
		this.txtNode = txtNode;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

	public Job addJob(Job job) {
		getJobs().add(job);
		job.setProgramJob(this);

		return job;
	}

	public Job removeJob(Job job) {
		getJobs().remove(job);
		job.setProgramJob(null);

		return job;
	}

	public Job getJob() {
		return this.job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public ProgramJob getProgramJob() {
		return this.programJob;
	}

	public void setProgramJob(ProgramJob programJob) {
		this.programJob = programJob;
	}

	public List<ProgramJob> getProgramJobs() {
		return this.programJobs;
	}

	public void setProgramJobs(List<ProgramJob> programJobs) {
		this.programJobs = programJobs;
	}

	public ProgramJob addProgramJob(ProgramJob programJob) {
		getProgramJobs().add(programJob);
		programJob.setProgramJob(this);

		return programJob;
	}

	public ProgramJob removeProgramJob(ProgramJob programJob) {
		getProgramJobs().remove(programJob);
		programJob.setProgramJob(null);

		return programJob;
	}

	public TypeNode getTypeNode() {
		return this.typeNode;
	}

	public void setTypeNode(TypeNode typeNode) {
		this.typeNode = typeNode;
	}

	public TypeOriginProgramJob getTypeOriginProgramJob() {
		return this.typeOriginProgramJob;
	}

	public void setTypeOriginProgramJob(TypeOriginProgramJob typeOriginProgramJob) {
		this.typeOriginProgramJob = typeOriginProgramJob;
	}

}