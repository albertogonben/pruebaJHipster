package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the QUESTIONNAIRE database table.
 * 
 */
@Entity
@NamedQuery(name="Questionnaire.findAll", query="SELECT q FROM Questionnaire q")
public class Questionnaire implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="QUESTIONNAIRE_IDQUESTIONNAIREPK_GENERATOR", sequenceName="QUESTIONNAIRE_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="QUESTIONNAIRE_IDQUESTIONNAIREPK_GENERATOR")
	@Column(name="ID_QUESTIONNAIRE_PK")
	private long idQuestionnairePk;

	@Column(name="COD_QUESTIONNAIRE")
	private String codQuestionnaire;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="DATE_VERSION")
	private BigDecimal dateVersion;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="NMR_VERSION")
	private BigDecimal nmrVersion;

	@Column(name="TXT_DESCRIPTION")
	private String txtDescription;

	@Column(name="TXT_TITLE")
	private String txtTitle;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to QuestionnaireQuestion
	@OneToMany(mappedBy="questionnaire")
	private List<QuestionnaireQuestion> questionnaireQuestions;

	public Questionnaire() {
	}

	public long getIdQuestionnairePk() {
		return this.idQuestionnairePk;
	}

	public void setIdQuestionnairePk(long idQuestionnairePk) {
		this.idQuestionnairePk = idQuestionnairePk;
	}

	public String getCodQuestionnaire() {
		return this.codQuestionnaire;
	}

	public void setCodQuestionnaire(String codQuestionnaire) {
		this.codQuestionnaire = codQuestionnaire;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(BigDecimal dateVersion) {
		this.dateVersion = dateVersion;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public BigDecimal getNmrVersion() {
		return this.nmrVersion;
	}

	public void setNmrVersion(BigDecimal nmrVersion) {
		this.nmrVersion = nmrVersion;
	}

	public String getTxtDescription() {
		return this.txtDescription;
	}

	public void setTxtDescription(String txtDescription) {
		this.txtDescription = txtDescription;
	}

	public String getTxtTitle() {
		return this.txtTitle;
	}

	public void setTxtTitle(String txtTitle) {
		this.txtTitle = txtTitle;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<QuestionnaireQuestion> getQuestionnaireQuestions() {
		return this.questionnaireQuestions;
	}

	public void setQuestionnaireQuestions(List<QuestionnaireQuestion> questionnaireQuestions) {
		this.questionnaireQuestions = questionnaireQuestions;
	}

	public QuestionnaireQuestion addQuestionnaireQuestion(QuestionnaireQuestion questionnaireQuestion) {
		getQuestionnaireQuestions().add(questionnaireQuestion);
		questionnaireQuestion.setQuestionnaire(this);

		return questionnaireQuestion;
	}

	public QuestionnaireQuestion removeQuestionnaireQuestion(QuestionnaireQuestion questionnaireQuestion) {
		getQuestionnaireQuestions().remove(questionnaireQuestion);
		questionnaireQuestion.setQuestionnaire(null);

		return questionnaireQuestion;
	}

}