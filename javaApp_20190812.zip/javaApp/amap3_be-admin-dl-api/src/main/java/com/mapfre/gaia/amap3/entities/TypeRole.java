package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_ROLE database table.
 * 
 */
@Entity
@Table(name="TYPE_ROLE")
@NamedQuery(name="TypeRole.findAll", query="SELECT t FROM TypeRole t")
public class TypeRole implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_ROLE_GENERATOR", sequenceName="TYP_ROL_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_ROLE_GENERATOR")
	@Column(name="ID_TYPE_ROLE_PK")
	private long idTypeRolePk;

	@Column(name="CD_TYPE_ROLE")
	private String cdTypeRole;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_TYPE_ROLE")
	private String txtTypeRole;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to UserAmap
//	@OneToMany(mappedBy="typeRole", fetch = FetchType.LAZY)
//	private List<UserAmap> userAmaps;

	public TypeRole() {
	}

	public long getIdTypeRolePk() {
		return this.idTypeRolePk;
	}

	public void setIdTypeRolePk(long idTypeRolePk) {
		this.idTypeRolePk = idTypeRolePk;
	}

	public String getCdTypeRole() {
		return this.cdTypeRole;
	}

	public void setCdTypeRole(String cdTypeRole) {
		this.cdTypeRole = cdTypeRole;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtTypeRole() {
		return this.txtTypeRole;
	}

	public void setTxtTypeRole(String txtTypeRole) {
		this.txtTypeRole = txtTypeRole;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

//	public List<UserAmap> getUserAmaps() {
//		return this.userAmaps;
//	}
//
//	public void setUserAmaps(List<UserAmap> userAmaps) {
//		this.userAmaps = userAmaps;
//	}
//
//	public UserAmap addUserAmap(UserAmap userAmap) {
//		getUserAmaps().add(userAmap);
//		userAmap.setTypeRole(this);
//
//		return userAmap;
//	}
//
//	public UserAmap removeUserAmap(UserAmap userAmap) {
//		getUserAmaps().remove(userAmap);
//		userAmap.setTypeRole(null);
//
//		return userAmap;
//	}

}