package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the QUESTION database table.
 * 
 */
@Entity
@NamedQuery(name="Question.findAll", query="SELECT q FROM Question q")
public class Question implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="QUESTION_IDQUESTIONTYPEPK_GENERATOR", sequenceName="QUESTION_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="QUESTION_IDQUESTIONTYPEPK_GENERATOR")
	@Column(name="ID_QUESTION_TYPE_PK")
	private long idQuestionTypePk;

	@Column(name="COD_QUESTION_TYPE")
	private String codQuestionType;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="IS_OPTION_QUESTION")
	private BigDecimal isOptionQuestion;

	@Column(name="IS_TEXT_QUESTION")
	private BigDecimal isTextQuestion;

	@Column(name="TXT_QUESTION")
	private String txtQuestion;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to QuestionnaireQuestion
	@OneToMany(mappedBy="question")
	private List<QuestionnaireQuestion> questionnaireQuestions;

	public Question() {
	}

	public long getIdQuestionTypePk() {
		return this.idQuestionTypePk;
	}

	public void setIdQuestionTypePk(long idQuestionTypePk) {
		this.idQuestionTypePk = idQuestionTypePk;
	}

	public String getCodQuestionType() {
		return this.codQuestionType;
	}

	public void setCodQuestionType(String codQuestionType) {
		this.codQuestionType = codQuestionType;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getIsOptionQuestion() {
		return this.isOptionQuestion;
	}

	public void setIsOptionQuestion(BigDecimal isOptionQuestion) {
		this.isOptionQuestion = isOptionQuestion;
	}

	public BigDecimal getIsTextQuestion() {
		return this.isTextQuestion;
	}

	public void setIsTextQuestion(BigDecimal isTextQuestion) {
		this.isTextQuestion = isTextQuestion;
	}

	public String getTxtQuestion() {
		return this.txtQuestion;
	}

	public void setTxtQuestion(String txtQuestion) {
		this.txtQuestion = txtQuestion;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<QuestionnaireQuestion> getQuestionnaireQuestions() {
		return this.questionnaireQuestions;
	}

	public void setQuestionnaireQuestions(List<QuestionnaireQuestion> questionnaireQuestions) {
		this.questionnaireQuestions = questionnaireQuestions;
	}

	public QuestionnaireQuestion addQuestionnaireQuestion(QuestionnaireQuestion questionnaireQuestion) {
		getQuestionnaireQuestions().add(questionnaireQuestion);
		questionnaireQuestion.setQuestion(this);

		return questionnaireQuestion;
	}

	public QuestionnaireQuestion removeQuestionnaireQuestion(QuestionnaireQuestion questionnaireQuestion) {
		getQuestionnaireQuestions().remove(questionnaireQuestion);
		questionnaireQuestion.setQuestion(null);

		return questionnaireQuestion;
	}

}