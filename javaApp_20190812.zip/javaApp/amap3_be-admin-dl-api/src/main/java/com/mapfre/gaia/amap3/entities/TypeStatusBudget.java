package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_STATUS_BUDGET database table.
 * 
 */
@Entity
@Table(name="TYPE_STATUS_BUDGET")
@NamedQuery(name="TypeStatusBudget.findAll", query="SELECT t FROM TypeStatusBudget t")
public class TypeStatusBudget implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_TYPE_STATUS_BUDGET_PK")
	private long idTypeStatusBudgetPk;

	@Column(name="CD_TYPE_STATUS_BUDGET")
	private String cdTypeStatusBudget;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_TYPE_STATUS_BUDGET")
	private String txtTypeStatusBudget;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Budget
	@OneToMany(mappedBy="typeStatusBudget")
	private List<Budget> budgets;

	public TypeStatusBudget() {
	}

	public long getIdTypeStatusBudgetPk() {
		return this.idTypeStatusBudgetPk;
	}

	public void setIdTypeStatusBudgetPk(long idTypeStatusBudgetPk) {
		this.idTypeStatusBudgetPk = idTypeStatusBudgetPk;
	}

	public String getCdTypeStatusBudget() {
		return this.cdTypeStatusBudget;
	}

	public void setCdTypeStatusBudget(String cdTypeStatusBudget) {
		this.cdTypeStatusBudget = cdTypeStatusBudget;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtTypeStatusBudget() {
		return this.txtTypeStatusBudget;
	}

	public void setTxtTypeStatusBudget(String txtTypeStatusBudget) {
		this.txtTypeStatusBudget = txtTypeStatusBudget;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<Budget> getBudgets() {
		return this.budgets;
	}

	public void setBudgets(List<Budget> budgets) {
		this.budgets = budgets;
	}

	public Budget addBudget(Budget budget) {
		getBudgets().add(budget);
		budget.setTypeStatusBudget(this);

		return budget;
	}

	public Budget removeBudget(Budget budget) {
		getBudgets().remove(budget);
		budget.setTypeStatusBudget(null);

		return budget;
	}

}