package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the IDEA database table.
 * 
 */
@Entity
@NamedQuery(name="Idea.findAll", query="SELECT i FROM Idea i")
public class Idea implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_IDEA_PK")
	private long idIdeaPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="ID_MRK_STATE_FK")
	private BigDecimal idMrkStateFk;

	@Column(name="TXT_DESCRIPTION")
	private String txtDescription;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to OrganizationalStructure
	@ManyToOne
	@JoinColumn(name="ID_ORGANIZATIONAL_STRUCTURE_FK")
	private OrganizationalStructure organizationalStructure;

	//bi-directional many-to-one association to IdeaDocument
	@OneToMany(mappedBy="idea")
	private List<IdeaDocument> ideaDocuments;

	//bi-directional many-to-one association to JobIdea
	@OneToMany(mappedBy="idea")
	private List<JobIdea> jobIdeas;

	public Idea() {
	}

	public long getIdIdeaPk() {
		return this.idIdeaPk;
	}

	public void setIdIdeaPk(long idIdeaPk) {
		this.idIdeaPk = idIdeaPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getIdMrkStateFk() {
		return this.idMrkStateFk;
	}

	public void setIdMrkStateFk(BigDecimal idMrkStateFk) {
		this.idMrkStateFk = idMrkStateFk;
	}

	public String getTxtDescription() {
		return this.txtDescription;
	}

	public void setTxtDescription(String txtDescription) {
		this.txtDescription = txtDescription;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public OrganizationalStructure getOrganizationalStructure() {
		return this.organizationalStructure;
	}

	public void setOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		this.organizationalStructure = organizationalStructure;
	}

	public List<IdeaDocument> getIdeaDocuments() {
		return this.ideaDocuments;
	}

	public void setIdeaDocuments(List<IdeaDocument> ideaDocuments) {
		this.ideaDocuments = ideaDocuments;
	}

	public IdeaDocument addIdeaDocument(IdeaDocument ideaDocument) {
		getIdeaDocuments().add(ideaDocument);
		ideaDocument.setIdea(this);

		return ideaDocument;
	}

	public IdeaDocument removeIdeaDocument(IdeaDocument ideaDocument) {
		getIdeaDocuments().remove(ideaDocument);
		ideaDocument.setIdea(null);

		return ideaDocument;
	}

	public List<JobIdea> getJobIdeas() {
		return this.jobIdeas;
	}

	public void setJobIdeas(List<JobIdea> jobIdeas) {
		this.jobIdeas = jobIdeas;
	}

	public JobIdea addJobIdea(JobIdea jobIdea) {
		getJobIdeas().add(jobIdea);
		jobIdea.setIdea(this);

		return jobIdea;
	}

	public JobIdea removeJobIdea(JobIdea jobIdea) {
		getJobIdeas().remove(jobIdea);
		jobIdea.setIdea(null);

		return jobIdea;
	}

}