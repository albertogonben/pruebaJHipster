package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_CONCEPT_IMPUTATION database table.
 * 
 */
@Entity
@Table(name="TYPE_CONCEPT_IMPUTATION")
@NamedQuery(name="TypeConceptImputation.findAll", query="SELECT t FROM TypeConceptImputation t")
public class TypeConceptImputation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_CONCEPT_IMPUTATION_IDTYPECONCEPTIMPUTATIONPK_GENERATOR", sequenceName="TYPE_CONCEPT_IMPUTATION_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_CONCEPT_IMPUTATION_IDTYPECONCEPTIMPUTATIONPK_GENERATOR")
	@Column(name="ID_TYPE_CONCEPT_IMPUTATION_PK")
	private long idTypeConceptImputationPk;

	@Column(name="COD_TYPE_CONCEPT_IMPUTATION")
	private String codTypeConceptImputation;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="IS_IMPUTABLE_PAI")
	private BigDecimal isImputablePai;

	@Column(name="TXT_TYPE_CONCEPT_IMPUTATION")
	private String txtTypeConceptImputation;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to ImputationTime
	@OneToMany(mappedBy="typeConceptImputation")
	private List<ImputationTime> imputationTimes;

	//bi-directional many-to-one association to TypeConceptImputation
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="ID_TYPE_CONCEPT_IMPUTATION_FATHER_FK")
	private TypeConceptImputation typeConceptImputation;

	//bi-directional many-to-one association to TypeConceptImputation
	@OneToMany(mappedBy="typeConceptImputation")
	private List<TypeConceptImputation> typeConceptImputations;

	public TypeConceptImputation() {
	}

	public long getIdTypeConceptImputationPk() {
		return this.idTypeConceptImputationPk;
	}

	public void setIdTypeConceptImputationPk(long idTypeConceptImputationPk) {
		this.idTypeConceptImputationPk = idTypeConceptImputationPk;
	}

	public String getCodTypeConceptImputation() {
		return this.codTypeConceptImputation;
	}

	public void setCodTypeConceptImputation(String codTypeConceptImputation) {
		this.codTypeConceptImputation = codTypeConceptImputation;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getIsImputablePai() {
		return this.isImputablePai;
	}

	public void setIsImputablePai(BigDecimal isImputablePai) {
		this.isImputablePai = isImputablePai;
	}

	public String getTxtTypeConceptImputation() {
		return this.txtTypeConceptImputation;
	}

	public void setTxtTypeConceptImputation(String txtTypeConceptImputation) {
		this.txtTypeConceptImputation = txtTypeConceptImputation;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<ImputationTime> getImputationTimes() {
		return this.imputationTimes;
	}

	public void setImputationTimes(List<ImputationTime> imputationTimes) {
		this.imputationTimes = imputationTimes;
	}

	public ImputationTime addImputationTime(ImputationTime imputationTime) {
		getImputationTimes().add(imputationTime);
		imputationTime.setTypeConceptImputation(this);

		return imputationTime;
	}

	public ImputationTime removeImputationTime(ImputationTime imputationTime) {
		getImputationTimes().remove(imputationTime);
		imputationTime.setTypeConceptImputation(null);

		return imputationTime;
	}

	public TypeConceptImputation getTypeConceptImputation() {
		return this.typeConceptImputation;
	}

	public void setTypeConceptImputation(TypeConceptImputation typeConceptImputation) {
		this.typeConceptImputation = typeConceptImputation;
	}

	public List<TypeConceptImputation> getTypeConceptImputations() {
		return this.typeConceptImputations;
	}

	public void setTypeConceptImputations(List<TypeConceptImputation> typeConceptImputations) {
		this.typeConceptImputations = typeConceptImputations;
	}

	public TypeConceptImputation addTypeConceptImputation(TypeConceptImputation typeConceptImputation) {
		getTypeConceptImputations().add(typeConceptImputation);
		typeConceptImputation.setTypeConceptImputation(this);

		return typeConceptImputation;
	}

	public TypeConceptImputation removeTypeConceptImputation(TypeConceptImputation typeConceptImputation) {
		getTypeConceptImputations().remove(typeConceptImputation);
		typeConceptImputation.setTypeConceptImputation(null);

		return typeConceptImputation;
	}

}