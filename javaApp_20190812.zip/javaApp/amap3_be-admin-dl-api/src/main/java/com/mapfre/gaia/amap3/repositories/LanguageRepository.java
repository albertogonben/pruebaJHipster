package com.mapfre.gaia.amap3.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapfre.gaia.amap3.entities.Language;

public interface LanguageRepository extends JpaRepository<Language, Long> {

}
