package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PROCESS_COUNTRY database table.
 * 
 */
@Entity
@Table(name="PROCESS_COUNTRY")
@NamedQuery(name="ProcessCountry.findAll", query="SELECT p FROM ProcessCountry p")
public class ProcessCountry implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_PROCESS_PK")
	private long idProcessPk;

	@Column(name="CD_PROCESO")
	private String cdProceso;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSER")
	private Date dateInser;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_VERSION")
	private Date dateVersion;

	@Column(name="NMR_SIZE")
	private BigDecimal nmrSize;

	@Column(name="NMR_VERSION")
	private BigDecimal nmrVersion;

	@Column(name="TXT_NM")
	private String txtNm;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Country
	@ManyToOne
	@JoinColumn(name="ID_COUNTRY_FK")
	private Country country;

	//bi-directional many-to-one association to ProcessCountry
	@ManyToOne
	@JoinColumn(name="ID_PROCESS_FATHER_FK")
	private ProcessCountry processCountry;

	//bi-directional many-to-one association to ProcessCountry
	@OneToMany(mappedBy="processCountry")
	private List<ProcessCountry> processCountries;

	//bi-directional many-to-one association to ProcessUnitBusiness
	@ManyToOne
	@JoinColumn(name="ID_PROCESS_MAPFRE_FK")
	private ProcessUnitBusiness processUnitBusiness;

	//bi-directional many-to-one association to Sector
	@ManyToOne
	@JoinColumn(name="ID_SECTOR_FK")
	private Sector sector;

	//bi-directional many-to-one association to TypeProcess
	@ManyToOne
	@JoinColumn(name="ID_TYPE_PROCESS_FK")
	private TypeProcess typeProcess;

	//bi-directional many-to-one association to UnitBusiness
	@ManyToOne
	@JoinColumn(name="ID_UNIT_BUSINESS_FK")
	private UnitBusiness unitBusiness;

	public ProcessCountry() {
	}

	public long getIdProcessPk() {
		return this.idProcessPk;
	}

	public void setIdProcessPk(long idProcessPk) {
		this.idProcessPk = idProcessPk;
	}

	public String getCdProceso() {
		return this.cdProceso;
	}

	public void setCdProceso(String cdProceso) {
		this.cdProceso = cdProceso;
	}

	public Date getDateInser() {
		return this.dateInser;
	}

	public void setDateInser(Date dateInser) {
		this.dateInser = dateInser;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}

	public BigDecimal getNmrSize() {
		return this.nmrSize;
	}

	public void setNmrSize(BigDecimal nmrSize) {
		this.nmrSize = nmrSize;
	}

	public BigDecimal getNmrVersion() {
		return this.nmrVersion;
	}

	public void setNmrVersion(BigDecimal nmrVersion) {
		this.nmrVersion = nmrVersion;
	}

	public String getTxtNm() {
		return this.txtNm;
	}

	public void setTxtNm(String txtNm) {
		this.txtNm = txtNm;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Country getCountry() {
		return this.country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public ProcessCountry getProcessCountry() {
		return this.processCountry;
	}

	public void setProcessCountry(ProcessCountry processCountry) {
		this.processCountry = processCountry;
	}

	public List<ProcessCountry> getProcessCountries() {
		return this.processCountries;
	}

	public void setProcessCountries(List<ProcessCountry> processCountries) {
		this.processCountries = processCountries;
	}

	public ProcessCountry addProcessCountry(ProcessCountry processCountry) {
		getProcessCountries().add(processCountry);
		processCountry.setProcessCountry(this);

		return processCountry;
	}

	public ProcessCountry removeProcessCountry(ProcessCountry processCountry) {
		getProcessCountries().remove(processCountry);
		processCountry.setProcessCountry(null);

		return processCountry;
	}

	public ProcessUnitBusiness getProcessUnitBusiness() {
		return this.processUnitBusiness;
	}

	public void setProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness) {
		this.processUnitBusiness = processUnitBusiness;
	}

	public Sector getSector() {
		return this.sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	public TypeProcess getTypeProcess() {
		return this.typeProcess;
	}

	public void setTypeProcess(TypeProcess typeProcess) {
		this.typeProcess = typeProcess;
	}

	public UnitBusiness getUnitBusiness() {
		return this.unitBusiness;
	}

	public void setUnitBusiness(UnitBusiness unitBusiness) {
		this.unitBusiness = unitBusiness;
	}

}