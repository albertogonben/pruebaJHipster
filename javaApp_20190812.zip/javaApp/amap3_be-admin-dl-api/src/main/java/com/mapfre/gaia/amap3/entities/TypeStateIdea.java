package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the TYPE_STATE_IDEA database table.
 * 
 */
@Entity
@Table(name="TYPE_STATE_IDEA")
@NamedQuery(name="TypeStateIdea.findAll", query="SELECT t FROM TypeStateIdea t")
public class TypeStateIdea implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_TYPE_STATE_IDEA_PK")
	private long idTypeStateIdeaPk;

	@Column(name="CD_TYPE_STATE_IDEA")
	private String cdTypeStateIdea;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private String mrkActive;

	@Column(name="TXT_TYPE_STATE_IDEA")
	private String txtTypeStateIdea;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public TypeStateIdea() {
	}

	public long getIdTypeStateIdeaPk() {
		return this.idTypeStateIdeaPk;
	}

	public void setIdTypeStateIdeaPk(long idTypeStateIdeaPk) {
		this.idTypeStateIdeaPk = idTypeStateIdeaPk;
	}

	public String getCdTypeStateIdea() {
		return this.cdTypeStateIdea;
	}

	public void setCdTypeStateIdea(String cdTypeStateIdea) {
		this.cdTypeStateIdea = cdTypeStateIdea;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(String mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtTypeStateIdea() {
		return this.txtTypeStateIdea;
	}

	public void setTxtTypeStateIdea(String txtTypeStateIdea) {
		this.txtTypeStateIdea = txtTypeStateIdea;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}