package com.mapfre.gaia.amap3.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapfre.gaia.amap3.entities.MatrixRisk;

public interface MatrixRiskRepository extends JpaRepository<MatrixRisk, Long> {

}
