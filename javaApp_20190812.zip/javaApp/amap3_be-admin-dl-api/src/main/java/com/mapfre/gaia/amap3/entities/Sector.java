package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the SECTOR database table.
 * 
 */
@Entity
@NamedQuery(name="Sector.findAll", query="SELECT s FROM Sector s")
public class Sector implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SECTOR_GENERATOR", sequenceName="SEC_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SECTOR_GENERATOR")
	@Column(name="ID_SECTOR_PK")
	private long idSectorPk;

	@Column(name="CD_SECTOR")
	private String cdSector;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_VERSION")
	private Date dateVersion;

	@Column(name="MRK_ACTIVO")
	private BigDecimal mrkActivo;

	@Column(name="NMR_VERSION")
	private BigDecimal nmrVersion;

	@Column(name="TXT_NOMBRE")
	private String txtNombre;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to ProcessCountry
	@OneToMany(mappedBy="sector")
	private List<ProcessCountry> processCountries;

	public Sector() {
	}

	public long getIdSectorPk() {
		return this.idSectorPk;
	}

	public void setIdSectorPk(long idSectorPk) {
		this.idSectorPk = idSectorPk;
	}

	public String getCdSector() {
		return this.cdSector;
	}

	public void setCdSector(String cdSector) {
		this.cdSector = cdSector;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}

	public BigDecimal getMrkActivo() {
		return this.mrkActivo;
	}

	public void setMrkActivo(BigDecimal mrkActivo) {
		this.mrkActivo = mrkActivo;
	}

	public BigDecimal getNmrVersion() {
		return this.nmrVersion;
	}

	public void setNmrVersion(BigDecimal nmrVersion) {
		this.nmrVersion = nmrVersion;
	}

	public String getTxtNombre() {
		return this.txtNombre;
	}

	public void setTxtNombre(String txtNombre) {
		this.txtNombre = txtNombre;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<ProcessCountry> getProcessCountries() {
		return this.processCountries;
	}

	public void setProcessCountries(List<ProcessCountry> processCountries) {
		this.processCountries = processCountries;
	}

	public ProcessCountry addProcessCountry(ProcessCountry processCountry) {
		getProcessCountries().add(processCountry);
		processCountry.setSector(this);

		return processCountry;
	}

	public ProcessCountry removeProcessCountry(ProcessCountry processCountry) {
		getProcessCountries().remove(processCountry);
		processCountry.setSector(null);

		return processCountry;
	}

}