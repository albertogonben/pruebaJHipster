package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_REASON_CHANGE_CATEGORY database table.
 * 
 */
@Entity
@Table(name="TYPE_REASON_CHANGE_CATEGORY")
@NamedQuery(name="TypeReasonChangeCategory.findAll", query="SELECT t FROM TypeReasonChangeCategory t")
public class TypeReasonChangeCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_TYPE_OTHER_REASON_PK")
	private long idTypeOtherReasonPk;

	@Column(name="CD_TYPE_OTHER_REASON")
	private String cdTypeOtherReason;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_DESCRIPTION")
	private String txtDescription;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to UserCategory
	@OneToMany(mappedBy="typeReasonChangeCategory")
	private List<UserCategory> userCategories;

	public TypeReasonChangeCategory() {
	}

	public long getIdTypeOtherReasonPk() {
		return this.idTypeOtherReasonPk;
	}

	public void setIdTypeOtherReasonPk(long idTypeOtherReasonPk) {
		this.idTypeOtherReasonPk = idTypeOtherReasonPk;
	}

	public String getCdTypeOtherReason() {
		return this.cdTypeOtherReason;
	}

	public void setCdTypeOtherReason(String cdTypeOtherReason) {
		this.cdTypeOtherReason = cdTypeOtherReason;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtDescription() {
		return this.txtDescription;
	}

	public void setTxtDescription(String txtDescription) {
		this.txtDescription = txtDescription;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<UserCategory> getUserCategories() {
		return this.userCategories;
	}

	public void setUserCategories(List<UserCategory> userCategories) {
		this.userCategories = userCategories;
	}

	public UserCategory addUserCategory(UserCategory userCategory) {
		getUserCategories().add(userCategory);
		userCategory.setTypeReasonChangeCategory(this);

		return userCategory;
	}

	public UserCategory removeUserCategory(UserCategory userCategory) {
		getUserCategories().remove(userCategory);
		userCategory.setTypeReasonChangeCategory(null);

		return userCategory;
	}

}