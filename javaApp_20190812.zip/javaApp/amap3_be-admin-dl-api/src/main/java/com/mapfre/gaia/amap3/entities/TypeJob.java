package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_JOB database table.
 * 
 */
@Entity
@Table(name="TYPE_JOB")
@NamedQuery(name="TypeJob.findAll", query="SELECT t FROM TypeJob t")
public class TypeJob implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_TYPE_JOB_PK")
	private long idTypeJobPk;

	@Column(name="CD_TYPE_JOB")
	private String cdTypeJob;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Job
	@OneToMany(mappedBy="typeJob")
	private List<Job> jobs;

	public TypeJob() {
	}

	public long getIdTypeJobPk() {
		return this.idTypeJobPk;
	}

	public void setIdTypeJobPk(long idTypeJobPk) {
		this.idTypeJobPk = idTypeJobPk;
	}

	public String getCdTypeJob() {
		return this.cdTypeJob;
	}

	public void setCdTypeJob(String cdTypeJob) {
		this.cdTypeJob = cdTypeJob;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

	public Job addJob(Job job) {
		getJobs().add(job);
		job.setTypeJob(this);

		return job;
	}

	public Job removeJob(Job job) {
		getJobs().remove(job);
		job.setTypeJob(null);

		return job;
	}

}