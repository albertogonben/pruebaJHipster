package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the JOB_LOG database table.
 * 
 */
@Entity
@Table(name="JOB_LOG")
@NamedQuery(name="JobLog.findAll", query="SELECT j FROM JobLog j")
public class JobLog implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID_EVENT_PK")
	private long idEventPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_EVENT")
	private Date dateEvent;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_EVENT")
	private String txtEvent;

	@Column(name="USER_EVENT")
	private String userEvent;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Job
	@ManyToOne
	@JoinColumn(name="ID_JOB_FK")
	private Job job;

	//bi-directional many-to-one association to TypeTrace
	@ManyToOne
	@JoinColumn(name="ID_TYPE_EVENT_FK")
	private TypeTrace typeTrace;

	public JobLog() {
	}

	public long getIdEventPk() {
		return this.idEventPk;
	}

	public void setIdEventPk(long idEventPk) {
		this.idEventPk = idEventPk;
	}

	public Date getDateEvent() {
		return this.dateEvent;
	}

	public void setDateEvent(Date dateEvent) {
		this.dateEvent = dateEvent;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtEvent() {
		return this.txtEvent;
	}

	public void setTxtEvent(String txtEvent) {
		this.txtEvent = txtEvent;
	}

	public String getUserEvent() {
		return this.userEvent;
	}

	public void setUserEvent(String userEvent) {
		this.userEvent = userEvent;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Job getJob() {
		return this.job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public TypeTrace getTypeTrace() {
		return this.typeTrace;
	}

	public void setTypeTrace(TypeTrace typeTrace) {
		this.typeTrace = typeTrace;
	}

}