package com.mapfre.gaia.amap3.exception.handler;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.mapfre.gaia.amap3.exception.CustomErrorResponseBO;
import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.exception.ErrorBO;
import com.mapfre.gaia.amap3.exception.InfoErrorBO;
import com.mapfre.gaia.amap3.exception.StackTraceBO;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(Exception.class)
	public ResponseEntity<CustomErrorResponseBO> customExceptionHandle(Exception ex, WebRequest request)  {
		
		String status = null;
		
		if(ex instanceof CustomException) {
			status = String.valueOf(((CustomException) ex ).getStatus());
		}else {
			status = HttpStatus.INTERNAL_SERVER_ERROR.toString();
		}
		
		// We build the response object for an error
		CustomErrorResponseBO customErrorResponseBO = new CustomErrorResponseBO();
		customErrorResponseBO.setCode(status);
		customErrorResponseBO.setMessage(ex.getMessage());
		customErrorResponseBO.setType("Meter tipo error");
		customErrorResponseBO.setContext("Meter contexto");
		customErrorResponseBO.setException(ex.getMessage());
		customErrorResponseBO.setApplication("amap3");
		customErrorResponseBO.setComponent("Meter componente");
		
		// Get current date time
		LocalDateTime currentDateTime = LocalDateTime.now();
		 
		//Build formatter
		DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
		
		customErrorResponseBO.setTimestamp(currentDateTime.format(formatter));
		
		// To set the error list
		ErrorBO errorBO = new ErrorBO();
		errorBO.setCode(status);
		errorBO.setMessage(ex.getMessage());
		errorBO.setComponent("Meter componente");
		errorBO.setRootCause(ex.getMessage());
		
		// To set the error info
		InfoErrorBO infoErrorBO = new InfoErrorBO();
		
		infoErrorBO.setKey(Integer.parseInt(status));
		infoErrorBO.setValue("Valor error");
		
		List<InfoErrorBO> infoErrorList = new ArrayList<InfoErrorBO>();
		infoErrorList.add(infoErrorBO);
		
		errorBO.setInfo(infoErrorList);
		
		List<ErrorBO> errorList = new ArrayList<ErrorBO>();
		errorList.add(errorBO);
		
		customErrorResponseBO.setErrors(errorList);
		
		// To set the stack trace object
		if(ex.getStackTrace().length > 0) {
			
			StackTraceBO stackTraceBO = new StackTraceBO();
			
			stackTraceBO.setDeclaringClass(ex.getStackTrace()[0].getClassName());
			stackTraceBO.setMethodName(ex.getStackTrace()[0].getMethodName());
			stackTraceBO.setFileName(ex.getStackTrace()[0].getFileName());
			stackTraceBO.setLineNumber(ex.getStackTrace()[0].getLineNumber());
			
			customErrorResponseBO.setStackTrace(stackTraceBO);
			
		}
		
		
		
		return new ResponseEntity<CustomErrorResponseBO>(customErrorResponseBO, HttpStatus.valueOf(Integer.parseInt(status)));

	}

}
