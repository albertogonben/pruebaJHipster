package com.mapfre.gaia.amap3.mapper;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

public class Mapper {

	public static MapperFacade generateMapperGeneric(Class classEntity, Class classBO) {
		
		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		mapperFactory.classMap(classEntity, classBO).byDefault().register();
		
		return mapperFactory.getMapperFacade();
		
	}
	
}
