package com.mapfre.gaia.amap3.mapper;

import org.springframework.stereotype.Component;

import com.mapfre.gaia.amap3.CountryRegionBO;
import com.mapfre.gaia.amap3.CurrencyBO;
import com.mapfre.gaia.amap3.RegionBO;
import com.mapfre.gaia.amap3.entities.Region;

import ma.glasnost.orika.CustomMapper;
import ma.glasnost.orika.MappingContext;

@Component
public class CountryRegionMapper extends CustomMapper<Region, CountryRegionBO> {

	@Override
	public void mapAtoB(Region region, CountryRegionBO countryRegionBO, MappingContext context) {
		//TODO Alberto Revisar para el Hito III
//		countryRegionBO.setCdCountry(region.getCountry().getCdCountry());
//		countryRegionBO.setCdIso(region.getCountry().getCdIso());

		CurrencyBO currency = new CurrencyBO();

//		currency.setIdCurrencyPk(region.getCountry().getCurrency().getIdCurrencyPk());
//		currency.setCdCurrency(region.getCountry().getCurrency().getCdCurrency());
//		currency.setMrkActive(region.getCountry().getCurrency().getMrkActive());
//		currency.setTxtCurrency(region.getCountry().getCurrency().getTxtCurrency());

		countryRegionBO.setCurrency(currency);

		countryRegionBO.setDateInsert(region.getDateInsert());
		countryRegionBO.setDateUpdate(region.getDateUpdate());
//		countryRegionBO.setIdCountryPk(region.getCountry().getIdCountryPk());

		RegionBO regionBO = new RegionBO();

		region.setIdRegionPk(region.getIdRegionPk());
		region.setCdRegion(region.getCdRegion());
		region.setMrkActive(region.getMrkActive());

		countryRegionBO.setRegion(regionBO);

//		countryRegionBO.setTxtName(region.getCountry().getTxtName());
//		countryRegionBO.setUserInsert(region.getCountry().getUserInsert());
//		countryRegionBO.setUserUpdate(region.getCountry().getUserUpdate());
	}

}
