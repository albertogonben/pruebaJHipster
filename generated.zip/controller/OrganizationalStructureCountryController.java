package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class OrganizationalStructureCountryController implements IOrganizationalStructureCountryController{

	private IOrganizationalStructureCountryBL organizationalStructureCountryBL;
	
	@Autowired
	public OrganizationalStructureCountryController(IOrganizationalStructureCountryBL organizationalStructureCountryBL) {
		this.organizationalStructureCountryBL = organizationalStructureCountryBL;
	}
	
	@Override
	public ResponseEntity<List<OrganizationalStructureCountryBO>> get() throws CustomException{
		log.debug("OrganizationalStructureCountryController:get [START]");
		try {
			log.debug("OrganizationalStructureCountryController:get [END]");
			return ResponseEntity.ok().body(organizationalStructureCountryBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<OrganizationalStructureCountryBO> add(@Valid @RequestBody OrganizationalStructureCountryBO input) throws CustomException{
    	log.debug("OrganizationalStructureCountryController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			OrganizationalStructureCountryBO organizationalStructureCountryBo = organizationalStructureCountryBL.add(input);
			if (organizationalStructureCountryBo != null) {
				log.debug("OrganizationalStructureCountryController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<OrganizationalStructureCountryBO> update(@PathVariable Long organizationalStructureCountryId, @RequestBody OrganizationalStructureCountryBO input) throws CustomException{
    	log.debug("OrganizationalStructureCountryController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			OrganizationalStructureCountryBO organizationalStructureCountryBo = organizationalStructureCountryBL.update(organizationalStructureCountryId, input);
			if (organizationalStructureCountryBo != null) {
				log.debug("OrganizationalStructureCountryController:update [END]");
			    return ResponseEntity.ok().body(organizationalStructureCountryBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<OrganizationalStructureCountryBO> delete(@PathVariable Long organizationalStructureCountryId) throws CustomException{
        log.debug("OrganizationalStructureCountryController:delete [START]");
        try {
			boolean organizationalStructureCountryDeleted = organizationalStructureCountryBL.delete(organizationalStructureCountryId);
			if (organizationalStructureCountryDeleted) {
				log.debug("OrganizationalStructureCountryController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
