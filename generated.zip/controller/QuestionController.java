package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class QuestionController implements IQuestionController{

	private IQuestionBL questionBL;
	
	@Autowired
	public QuestionController(IQuestionBL questionBL) {
		this.questionBL = questionBL;
	}
	
	@Override
	public ResponseEntity<List<QuestionBO>> get() throws CustomException{
		log.debug("QuestionController:get [START]");
		try {
			log.debug("QuestionController:get [END]");
			return ResponseEntity.ok().body(questionBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<QuestionBO> add(@Valid @RequestBody QuestionBO input) throws CustomException{
    	log.debug("QuestionController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			QuestionBO questionBo = questionBL.add(input);
			if (questionBo != null) {
				log.debug("QuestionController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<QuestionBO> update(@PathVariable Long questionId, @RequestBody QuestionBO input) throws CustomException{
    	log.debug("QuestionController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			QuestionBO questionBo = questionBL.update(questionId, input);
			if (questionBo != null) {
				log.debug("QuestionController:update [END]");
			    return ResponseEntity.ok().body(questionBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<QuestionBO> delete(@PathVariable Long questionId) throws CustomException{
        log.debug("QuestionController:delete [START]");
        try {
			boolean questionDeleted = questionBL.delete(questionId);
			if (questionDeleted) {
				log.debug("QuestionController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
