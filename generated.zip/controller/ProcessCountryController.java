package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ProcessCountryController implements IProcessCountryController{

	private IProcessCountryBL processCountryBL;
	
	@Autowired
	public ProcessCountryController(IProcessCountryBL processCountryBL) {
		this.processCountryBL = processCountryBL;
	}
	
	@Override
	public ResponseEntity<List<ProcessCountryBO>> get() throws CustomException{
		log.debug("ProcessCountryController:get [START]");
		try {
			log.debug("ProcessCountryController:get [END]");
			return ResponseEntity.ok().body(processCountryBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<ProcessCountryBO> add(@Valid @RequestBody ProcessCountryBO input) throws CustomException{
    	log.debug("ProcessCountryController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			ProcessCountryBO processCountryBo = processCountryBL.add(input);
			if (processCountryBo != null) {
				log.debug("ProcessCountryController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<ProcessCountryBO> update(@PathVariable Long processCountryId, @RequestBody ProcessCountryBO input) throws CustomException{
    	log.debug("ProcessCountryController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			ProcessCountryBO processCountryBo = processCountryBL.update(processCountryId, input);
			if (processCountryBo != null) {
				log.debug("ProcessCountryController:update [END]");
			    return ResponseEntity.ok().body(processCountryBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<ProcessCountryBO> delete(@PathVariable Long processCountryId) throws CustomException{
        log.debug("ProcessCountryController:delete [START]");
        try {
			boolean processCountryDeleted = processCountryBL.delete(processCountryId);
			if (processCountryDeleted) {
				log.debug("ProcessCountryController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
