package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class GuideJobController implements IGuideJobController{

	private IGuideJobBL guideJobBL;
	
	@Autowired
	public GuideJobController(IGuideJobBL guideJobBL) {
		this.guideJobBL = guideJobBL;
	}
	
	@Override
	public ResponseEntity<List<GuideJobBO>> get() throws CustomException{
		log.debug("GuideJobController:get [START]");
		try {
			log.debug("GuideJobController:get [END]");
			return ResponseEntity.ok().body(guideJobBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<GuideJobBO> add(@Valid @RequestBody GuideJobBO input) throws CustomException{
    	log.debug("GuideJobController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			GuideJobBO guideJobBo = guideJobBL.add(input);
			if (guideJobBo != null) {
				log.debug("GuideJobController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<GuideJobBO> update(@PathVariable Long guideJobId, @RequestBody GuideJobBO input) throws CustomException{
    	log.debug("GuideJobController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			GuideJobBO guideJobBo = guideJobBL.update(guideJobId, input);
			if (guideJobBo != null) {
				log.debug("GuideJobController:update [END]");
			    return ResponseEntity.ok().body(guideJobBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<GuideJobBO> delete(@PathVariable Long guideJobId) throws CustomException{
        log.debug("GuideJobController:delete [START]");
        try {
			boolean guideJobDeleted = guideJobBL.delete(guideJobId);
			if (guideJobDeleted) {
				log.debug("GuideJobController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
