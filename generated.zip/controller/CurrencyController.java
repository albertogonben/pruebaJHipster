package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class CurrencyController implements ICurrencyController{

	private ICurrencyBL currencyBL;
	
	@Autowired
	public CurrencyController(ICurrencyBL currencyBL) {
		this.currencyBL = currencyBL;
	}
	
	@Override
	public ResponseEntity<List<CurrencyBO>> get() throws CustomException{
		log.debug("CurrencyController:get [START]");
		try {
			log.debug("CurrencyController:get [END]");
			return ResponseEntity.ok().body(currencyBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<CurrencyBO> add(@Valid @RequestBody CurrencyBO input) throws CustomException{
    	log.debug("CurrencyController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			CurrencyBO currencyBo = currencyBL.add(input);
			if (currencyBo != null) {
				log.debug("CurrencyController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<CurrencyBO> update(@PathVariable Long currencyId, @RequestBody CurrencyBO input) throws CustomException{
    	log.debug("CurrencyController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			CurrencyBO currencyBo = currencyBL.update(currencyId, input);
			if (currencyBo != null) {
				log.debug("CurrencyController:update [END]");
			    return ResponseEntity.ok().body(currencyBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<CurrencyBO> delete(@PathVariable Long currencyId) throws CustomException{
        log.debug("CurrencyController:delete [START]");
        try {
			boolean currencyDeleted = currencyBL.delete(currencyId);
			if (currencyDeleted) {
				log.debug("CurrencyController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
