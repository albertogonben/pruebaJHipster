package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class PaiController implements IPaiController{

	private IPaiBL paiBL;
	
	@Autowired
	public PaiController(IPaiBL paiBL) {
		this.paiBL = paiBL;
	}
	
	@Override
	public ResponseEntity<List<PaiBO>> get() throws CustomException{
		log.debug("PaiController:get [START]");
		try {
			log.debug("PaiController:get [END]");
			return ResponseEntity.ok().body(paiBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<PaiBO> add(@Valid @RequestBody PaiBO input) throws CustomException{
    	log.debug("PaiController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			PaiBO paiBo = paiBL.add(input);
			if (paiBo != null) {
				log.debug("PaiController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<PaiBO> update(@PathVariable Long paiId, @RequestBody PaiBO input) throws CustomException{
    	log.debug("PaiController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			PaiBO paiBo = paiBL.update(paiId, input);
			if (paiBo != null) {
				log.debug("PaiController:update [END]");
			    return ResponseEntity.ok().body(paiBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<PaiBO> delete(@PathVariable Long paiId) throws CustomException{
        log.debug("PaiController:delete [START]");
        try {
			boolean paiDeleted = paiBL.delete(paiId);
			if (paiDeleted) {
				log.debug("PaiController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
