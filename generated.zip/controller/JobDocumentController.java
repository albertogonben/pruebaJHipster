package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class JobDocumentController implements IJobDocumentController{

	private IJobDocumentBL jobDocumentBL;
	
	@Autowired
	public JobDocumentController(IJobDocumentBL jobDocumentBL) {
		this.jobDocumentBL = jobDocumentBL;
	}
	
	@Override
	public ResponseEntity<List<JobDocumentBO>> get() throws CustomException{
		log.debug("JobDocumentController:get [START]");
		try {
			log.debug("JobDocumentController:get [END]");
			return ResponseEntity.ok().body(jobDocumentBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<JobDocumentBO> add(@Valid @RequestBody JobDocumentBO input) throws CustomException{
    	log.debug("JobDocumentController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			JobDocumentBO jobDocumentBo = jobDocumentBL.add(input);
			if (jobDocumentBo != null) {
				log.debug("JobDocumentController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<JobDocumentBO> update(@PathVariable Long jobDocumentId, @RequestBody JobDocumentBO input) throws CustomException{
    	log.debug("JobDocumentController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			JobDocumentBO jobDocumentBo = jobDocumentBL.update(jobDocumentId, input);
			if (jobDocumentBo != null) {
				log.debug("JobDocumentController:update [END]");
			    return ResponseEntity.ok().body(jobDocumentBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<JobDocumentBO> delete(@PathVariable Long jobDocumentId) throws CustomException{
        log.debug("JobDocumentController:delete [START]");
        try {
			boolean jobDocumentDeleted = jobDocumentBL.delete(jobDocumentId);
			if (jobDocumentDeleted) {
				log.debug("JobDocumentController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
