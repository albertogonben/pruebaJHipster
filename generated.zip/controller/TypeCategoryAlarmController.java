package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeCategoryAlarmController implements ITypeCategoryAlarmController{

	private ITypeCategoryAlarmBL typeCategoryAlarmBL;
	
	@Autowired
	public TypeCategoryAlarmController(ITypeCategoryAlarmBL typeCategoryAlarmBL) {
		this.typeCategoryAlarmBL = typeCategoryAlarmBL;
	}
	
	@Override
	public ResponseEntity<List<TypeCategoryAlarmBO>> get() throws CustomException{
		log.debug("TypeCategoryAlarmController:get [START]");
		try {
			log.debug("TypeCategoryAlarmController:get [END]");
			return ResponseEntity.ok().body(typeCategoryAlarmBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeCategoryAlarmBO> add(@Valid @RequestBody TypeCategoryAlarmBO input) throws CustomException{
    	log.debug("TypeCategoryAlarmController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeCategoryAlarmBO typeCategoryAlarmBo = typeCategoryAlarmBL.add(input);
			if (typeCategoryAlarmBo != null) {
				log.debug("TypeCategoryAlarmController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeCategoryAlarmBO> update(@PathVariable Long typeCategoryAlarmId, @RequestBody TypeCategoryAlarmBO input) throws CustomException{
    	log.debug("TypeCategoryAlarmController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeCategoryAlarmBO typeCategoryAlarmBo = typeCategoryAlarmBL.update(typeCategoryAlarmId, input);
			if (typeCategoryAlarmBo != null) {
				log.debug("TypeCategoryAlarmController:update [END]");
			    return ResponseEntity.ok().body(typeCategoryAlarmBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeCategoryAlarmBO> delete(@PathVariable Long typeCategoryAlarmId) throws CustomException{
        log.debug("TypeCategoryAlarmController:delete [START]");
        try {
			boolean typeCategoryAlarmDeleted = typeCategoryAlarmBL.delete(typeCategoryAlarmId);
			if (typeCategoryAlarmDeleted) {
				log.debug("TypeCategoryAlarmController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
