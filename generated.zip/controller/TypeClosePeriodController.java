package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeClosePeriodController implements ITypeClosePeriodController{

	private ITypeClosePeriodBL typeClosePeriodBL;
	
	@Autowired
	public TypeClosePeriodController(ITypeClosePeriodBL typeClosePeriodBL) {
		this.typeClosePeriodBL = typeClosePeriodBL;
	}
	
	@Override
	public ResponseEntity<List<TypeClosePeriodBO>> get() throws CustomException{
		log.debug("TypeClosePeriodController:get [START]");
		try {
			log.debug("TypeClosePeriodController:get [END]");
			return ResponseEntity.ok().body(typeClosePeriodBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeClosePeriodBO> add(@Valid @RequestBody TypeClosePeriodBO input) throws CustomException{
    	log.debug("TypeClosePeriodController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeClosePeriodBO typeClosePeriodBo = typeClosePeriodBL.add(input);
			if (typeClosePeriodBo != null) {
				log.debug("TypeClosePeriodController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeClosePeriodBO> update(@PathVariable Long typeClosePeriodId, @RequestBody TypeClosePeriodBO input) throws CustomException{
    	log.debug("TypeClosePeriodController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeClosePeriodBO typeClosePeriodBo = typeClosePeriodBL.update(typeClosePeriodId, input);
			if (typeClosePeriodBo != null) {
				log.debug("TypeClosePeriodController:update [END]");
			    return ResponseEntity.ok().body(typeClosePeriodBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeClosePeriodBO> delete(@PathVariable Long typeClosePeriodId) throws CustomException{
        log.debug("TypeClosePeriodController:delete [START]");
        try {
			boolean typeClosePeriodDeleted = typeClosePeriodBL.delete(typeClosePeriodId);
			if (typeClosePeriodDeleted) {
				log.debug("TypeClosePeriodController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
