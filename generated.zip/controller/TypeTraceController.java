package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeTraceController implements ITypeTraceController{

	private ITypeTraceBL typeTraceBL;
	
	@Autowired
	public TypeTraceController(ITypeTraceBL typeTraceBL) {
		this.typeTraceBL = typeTraceBL;
	}
	
	@Override
	public ResponseEntity<List<TypeTraceBO>> get() throws CustomException{
		log.debug("TypeTraceController:get [START]");
		try {
			log.debug("TypeTraceController:get [END]");
			return ResponseEntity.ok().body(typeTraceBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeTraceBO> add(@Valid @RequestBody TypeTraceBO input) throws CustomException{
    	log.debug("TypeTraceController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeTraceBO typeTraceBo = typeTraceBL.add(input);
			if (typeTraceBo != null) {
				log.debug("TypeTraceController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeTraceBO> update(@PathVariable Long typeTraceId, @RequestBody TypeTraceBO input) throws CustomException{
    	log.debug("TypeTraceController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeTraceBO typeTraceBo = typeTraceBL.update(typeTraceId, input);
			if (typeTraceBo != null) {
				log.debug("TypeTraceController:update [END]");
			    return ResponseEntity.ok().body(typeTraceBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeTraceBO> delete(@PathVariable Long typeTraceId) throws CustomException{
        log.debug("TypeTraceController:delete [START]");
        try {
			boolean typeTraceDeleted = typeTraceBL.delete(typeTraceId);
			if (typeTraceDeleted) {
				log.debug("TypeTraceController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
