package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ModuleAppController implements IModuleAppController{

	private IModuleAppBL moduleAppBL;
	
	@Autowired
	public ModuleAppController(IModuleAppBL moduleAppBL) {
		this.moduleAppBL = moduleAppBL;
	}
	
	@Override
	public ResponseEntity<List<ModuleAppBO>> get() throws CustomException{
		log.debug("ModuleAppController:get [START]");
		try {
			log.debug("ModuleAppController:get [END]");
			return ResponseEntity.ok().body(moduleAppBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<ModuleAppBO> add(@Valid @RequestBody ModuleAppBO input) throws CustomException{
    	log.debug("ModuleAppController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			ModuleAppBO moduleAppBo = moduleAppBL.add(input);
			if (moduleAppBo != null) {
				log.debug("ModuleAppController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<ModuleAppBO> update(@PathVariable Long moduleAppId, @RequestBody ModuleAppBO input) throws CustomException{
    	log.debug("ModuleAppController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			ModuleAppBO moduleAppBo = moduleAppBL.update(moduleAppId, input);
			if (moduleAppBo != null) {
				log.debug("ModuleAppController:update [END]");
			    return ResponseEntity.ok().body(moduleAppBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<ModuleAppBO> delete(@PathVariable Long moduleAppId) throws CustomException{
        log.debug("ModuleAppController:delete [START]");
        try {
			boolean moduleAppDeleted = moduleAppBL.delete(moduleAppId);
			if (moduleAppDeleted) {
				log.debug("ModuleAppController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
