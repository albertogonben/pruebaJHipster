package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class IdeaDocumentController implements IIdeaDocumentController{

	private IIdeaDocumentBL ideaDocumentBL;
	
	@Autowired
	public IdeaDocumentController(IIdeaDocumentBL ideaDocumentBL) {
		this.ideaDocumentBL = ideaDocumentBL;
	}
	
	@Override
	public ResponseEntity<List<IdeaDocumentBO>> get() throws CustomException{
		log.debug("IdeaDocumentController:get [START]");
		try {
			log.debug("IdeaDocumentController:get [END]");
			return ResponseEntity.ok().body(ideaDocumentBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<IdeaDocumentBO> add(@Valid @RequestBody IdeaDocumentBO input) throws CustomException{
    	log.debug("IdeaDocumentController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			IdeaDocumentBO ideaDocumentBo = ideaDocumentBL.add(input);
			if (ideaDocumentBo != null) {
				log.debug("IdeaDocumentController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<IdeaDocumentBO> update(@PathVariable Long ideaDocumentId, @RequestBody IdeaDocumentBO input) throws CustomException{
    	log.debug("IdeaDocumentController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			IdeaDocumentBO ideaDocumentBo = ideaDocumentBL.update(ideaDocumentId, input);
			if (ideaDocumentBo != null) {
				log.debug("IdeaDocumentController:update [END]");
			    return ResponseEntity.ok().body(ideaDocumentBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<IdeaDocumentBO> delete(@PathVariable Long ideaDocumentId) throws CustomException{
        log.debug("IdeaDocumentController:delete [START]");
        try {
			boolean ideaDocumentDeleted = ideaDocumentBL.delete(ideaDocumentId);
			if (ideaDocumentDeleted) {
				log.debug("IdeaDocumentController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
