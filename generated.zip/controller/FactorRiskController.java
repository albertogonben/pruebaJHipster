package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class FactorRiskController implements IFactorRiskController{

	private IFactorRiskBL factorRiskBL;
	
	@Autowired
	public FactorRiskController(IFactorRiskBL factorRiskBL) {
		this.factorRiskBL = factorRiskBL;
	}
	
	@Override
	public ResponseEntity<List<FactorRiskBO>> get() throws CustomException{
		log.debug("FactorRiskController:get [START]");
		try {
			log.debug("FactorRiskController:get [END]");
			return ResponseEntity.ok().body(factorRiskBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<FactorRiskBO> add(@Valid @RequestBody FactorRiskBO input) throws CustomException{
    	log.debug("FactorRiskController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			FactorRiskBO factorRiskBo = factorRiskBL.add(input);
			if (factorRiskBo != null) {
				log.debug("FactorRiskController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<FactorRiskBO> update(@PathVariable Long factorRiskId, @RequestBody FactorRiskBO input) throws CustomException{
    	log.debug("FactorRiskController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			FactorRiskBO factorRiskBo = factorRiskBL.update(factorRiskId, input);
			if (factorRiskBo != null) {
				log.debug("FactorRiskController:update [END]");
			    return ResponseEntity.ok().body(factorRiskBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<FactorRiskBO> delete(@PathVariable Long factorRiskId) throws CustomException{
        log.debug("FactorRiskController:delete [START]");
        try {
			boolean factorRiskDeleted = factorRiskBL.delete(factorRiskId);
			if (factorRiskDeleted) {
				log.debug("FactorRiskController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
