package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class QuestionnaireQuestionController implements IQuestionnaireQuestionController{

	private IQuestionnaireQuestionBL questionnaireQuestionBL;
	
	@Autowired
	public QuestionnaireQuestionController(IQuestionnaireQuestionBL questionnaireQuestionBL) {
		this.questionnaireQuestionBL = questionnaireQuestionBL;
	}
	
	@Override
	public ResponseEntity<List<QuestionnaireQuestionBO>> get() throws CustomException{
		log.debug("QuestionnaireQuestionController:get [START]");
		try {
			log.debug("QuestionnaireQuestionController:get [END]");
			return ResponseEntity.ok().body(questionnaireQuestionBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<QuestionnaireQuestionBO> add(@Valid @RequestBody QuestionnaireQuestionBO input) throws CustomException{
    	log.debug("QuestionnaireQuestionController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			QuestionnaireQuestionBO questionnaireQuestionBo = questionnaireQuestionBL.add(input);
			if (questionnaireQuestionBo != null) {
				log.debug("QuestionnaireQuestionController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<QuestionnaireQuestionBO> update(@PathVariable Long questionnaireQuestionId, @RequestBody QuestionnaireQuestionBO input) throws CustomException{
    	log.debug("QuestionnaireQuestionController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			QuestionnaireQuestionBO questionnaireQuestionBo = questionnaireQuestionBL.update(questionnaireQuestionId, input);
			if (questionnaireQuestionBo != null) {
				log.debug("QuestionnaireQuestionController:update [END]");
			    return ResponseEntity.ok().body(questionnaireQuestionBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<QuestionnaireQuestionBO> delete(@PathVariable Long questionnaireQuestionId) throws CustomException{
        log.debug("QuestionnaireQuestionController:delete [START]");
        try {
			boolean questionnaireQuestionDeleted = questionnaireQuestionBL.delete(questionnaireQuestionId);
			if (questionnaireQuestionDeleted) {
				log.debug("QuestionnaireQuestionController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
