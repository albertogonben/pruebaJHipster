package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeCourseController implements ITypeCourseController{

	private ITypeCourseBL typeCourseBL;
	
	@Autowired
	public TypeCourseController(ITypeCourseBL typeCourseBL) {
		this.typeCourseBL = typeCourseBL;
	}
	
	@Override
	public ResponseEntity<List<TypeCourseBO>> get() throws CustomException{
		log.debug("TypeCourseController:get [START]");
		try {
			log.debug("TypeCourseController:get [END]");
			return ResponseEntity.ok().body(typeCourseBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeCourseBO> add(@Valid @RequestBody TypeCourseBO input) throws CustomException{
    	log.debug("TypeCourseController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeCourseBO typeCourseBo = typeCourseBL.add(input);
			if (typeCourseBo != null) {
				log.debug("TypeCourseController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeCourseBO> update(@PathVariable Long typeCourseId, @RequestBody TypeCourseBO input) throws CustomException{
    	log.debug("TypeCourseController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeCourseBO typeCourseBo = typeCourseBL.update(typeCourseId, input);
			if (typeCourseBo != null) {
				log.debug("TypeCourseController:update [END]");
			    return ResponseEntity.ok().body(typeCourseBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeCourseBO> delete(@PathVariable Long typeCourseId) throws CustomException{
        log.debug("TypeCourseController:delete [START]");
        try {
			boolean typeCourseDeleted = typeCourseBL.delete(typeCourseId);
			if (typeCourseDeleted) {
				log.debug("TypeCourseController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
