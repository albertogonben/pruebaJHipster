package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeStatusBudgetController implements ITypeStatusBudgetController{

	private ITypeStatusBudgetBL typeStatusBudgetBL;
	
	@Autowired
	public TypeStatusBudgetController(ITypeStatusBudgetBL typeStatusBudgetBL) {
		this.typeStatusBudgetBL = typeStatusBudgetBL;
	}
	
	@Override
	public ResponseEntity<List<TypeStatusBudgetBO>> get() throws CustomException{
		log.debug("TypeStatusBudgetController:get [START]");
		try {
			log.debug("TypeStatusBudgetController:get [END]");
			return ResponseEntity.ok().body(typeStatusBudgetBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeStatusBudgetBO> add(@Valid @RequestBody TypeStatusBudgetBO input) throws CustomException{
    	log.debug("TypeStatusBudgetController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeStatusBudgetBO typeStatusBudgetBo = typeStatusBudgetBL.add(input);
			if (typeStatusBudgetBo != null) {
				log.debug("TypeStatusBudgetController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeStatusBudgetBO> update(@PathVariable Long typeStatusBudgetId, @RequestBody TypeStatusBudgetBO input) throws CustomException{
    	log.debug("TypeStatusBudgetController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeStatusBudgetBO typeStatusBudgetBo = typeStatusBudgetBL.update(typeStatusBudgetId, input);
			if (typeStatusBudgetBo != null) {
				log.debug("TypeStatusBudgetController:update [END]");
			    return ResponseEntity.ok().body(typeStatusBudgetBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeStatusBudgetBO> delete(@PathVariable Long typeStatusBudgetId) throws CustomException{
        log.debug("TypeStatusBudgetController:delete [START]");
        try {
			boolean typeStatusBudgetDeleted = typeStatusBudgetBL.delete(typeStatusBudgetId);
			if (typeStatusBudgetDeleted) {
				log.debug("TypeStatusBudgetController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
