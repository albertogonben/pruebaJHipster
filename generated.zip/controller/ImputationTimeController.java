package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class ImputationTimeController implements IImputationTimeController{

	private IImputationTimeBL imputationTimeBL;
	
	@Autowired
	public ImputationTimeController(IImputationTimeBL imputationTimeBL) {
		this.imputationTimeBL = imputationTimeBL;
	}
	
	@Override
	public ResponseEntity<List<ImputationTimeBO>> get() throws CustomException{
		log.debug("ImputationTimeController:get [START]");
		try {
			log.debug("ImputationTimeController:get [END]");
			return ResponseEntity.ok().body(imputationTimeBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<ImputationTimeBO> add(@Valid @RequestBody ImputationTimeBO input) throws CustomException{
    	log.debug("ImputationTimeController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			ImputationTimeBO imputationTimeBo = imputationTimeBL.add(input);
			if (imputationTimeBo != null) {
				log.debug("ImputationTimeController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<ImputationTimeBO> update(@PathVariable Long imputationTimeId, @RequestBody ImputationTimeBO input) throws CustomException{
    	log.debug("ImputationTimeController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			ImputationTimeBO imputationTimeBo = imputationTimeBL.update(imputationTimeId, input);
			if (imputationTimeBo != null) {
				log.debug("ImputationTimeController:update [END]");
			    return ResponseEntity.ok().body(imputationTimeBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<ImputationTimeBO> delete(@PathVariable Long imputationTimeId) throws CustomException{
        log.debug("ImputationTimeController:delete [START]");
        try {
			boolean imputationTimeDeleted = imputationTimeBL.delete(imputationTimeId);
			if (imputationTimeDeleted) {
				log.debug("ImputationTimeController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
