package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class OrganizationalStructureController implements IOrganizationalStructureController{

	private IOrganizationalStructureBL organizationalStructureBL;
	
	@Autowired
	public OrganizationalStructureController(IOrganizationalStructureBL organizationalStructureBL) {
		this.organizationalStructureBL = organizationalStructureBL;
	}
	
	@Override
	public ResponseEntity<List<OrganizationalStructureBO>> get() throws CustomException{
		log.debug("OrganizationalStructureController:get [START]");
		try {
			log.debug("OrganizationalStructureController:get [END]");
			return ResponseEntity.ok().body(organizationalStructureBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<OrganizationalStructureBO> add(@Valid @RequestBody OrganizationalStructureBO input) throws CustomException{
    	log.debug("OrganizationalStructureController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			OrganizationalStructureBO organizationalStructureBo = organizationalStructureBL.add(input);
			if (organizationalStructureBo != null) {
				log.debug("OrganizationalStructureController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<OrganizationalStructureBO> update(@PathVariable Long organizationalStructureId, @RequestBody OrganizationalStructureBO input) throws CustomException{
    	log.debug("OrganizationalStructureController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			OrganizationalStructureBO organizationalStructureBo = organizationalStructureBL.update(organizationalStructureId, input);
			if (organizationalStructureBo != null) {
				log.debug("OrganizationalStructureController:update [END]");
			    return ResponseEntity.ok().body(organizationalStructureBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<OrganizationalStructureBO> delete(@PathVariable Long organizationalStructureId) throws CustomException{
        log.debug("OrganizationalStructureController:delete [START]");
        try {
			boolean organizationalStructureDeleted = organizationalStructureBL.delete(organizationalStructureId);
			if (organizationalStructureDeleted) {
				log.debug("OrganizationalStructureController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
