package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeOrganizationalStructureController implements ITypeOrganizationalStructureController{

	private ITypeOrganizationalStructureBL typeOrganizationalStructureBL;
	
	@Autowired
	public TypeOrganizationalStructureController(ITypeOrganizationalStructureBL typeOrganizationalStructureBL) {
		this.typeOrganizationalStructureBL = typeOrganizationalStructureBL;
	}
	
	@Override
	public ResponseEntity<List<TypeOrganizationalStructureBO>> get() throws CustomException{
		log.debug("TypeOrganizationalStructureController:get [START]");
		try {
			log.debug("TypeOrganizationalStructureController:get [END]");
			return ResponseEntity.ok().body(typeOrganizationalStructureBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeOrganizationalStructureBO> add(@Valid @RequestBody TypeOrganizationalStructureBO input) throws CustomException{
    	log.debug("TypeOrganizationalStructureController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeOrganizationalStructureBO typeOrganizationalStructureBo = typeOrganizationalStructureBL.add(input);
			if (typeOrganizationalStructureBo != null) {
				log.debug("TypeOrganizationalStructureController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeOrganizationalStructureBO> update(@PathVariable Long typeOrganizationalStructureId, @RequestBody TypeOrganizationalStructureBO input) throws CustomException{
    	log.debug("TypeOrganizationalStructureController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeOrganizationalStructureBO typeOrganizationalStructureBo = typeOrganizationalStructureBL.update(typeOrganizationalStructureId, input);
			if (typeOrganizationalStructureBo != null) {
				log.debug("TypeOrganizationalStructureController:update [END]");
			    return ResponseEntity.ok().body(typeOrganizationalStructureBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeOrganizationalStructureBO> delete(@PathVariable Long typeOrganizationalStructureId) throws CustomException{
        log.debug("TypeOrganizationalStructureController:delete [START]");
        try {
			boolean typeOrganizationalStructureDeleted = typeOrganizationalStructureBL.delete(typeOrganizationalStructureId);
			if (typeOrganizationalStructureDeleted) {
				log.debug("TypeOrganizationalStructureController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
