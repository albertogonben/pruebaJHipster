package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class EntamapUnitBusinessController implements IEntamapUnitBusinessController{

	private IEntamapUnitBusinessBL entamapUnitBusinessBL;
	
	@Autowired
	public EntamapUnitBusinessController(IEntamapUnitBusinessBL entamapUnitBusinessBL) {
		this.entamapUnitBusinessBL = entamapUnitBusinessBL;
	}
	
	@Override
	public ResponseEntity<List<EntamapUnitBusinessBO>> get() throws CustomException{
		log.debug("EntamapUnitBusinessController:get [START]");
		try {
			log.debug("EntamapUnitBusinessController:get [END]");
			return ResponseEntity.ok().body(entamapUnitBusinessBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<EntamapUnitBusinessBO> add(@Valid @RequestBody EntamapUnitBusinessBO input) throws CustomException{
    	log.debug("EntamapUnitBusinessController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			EntamapUnitBusinessBO entamapUnitBusinessBo = entamapUnitBusinessBL.add(input);
			if (entamapUnitBusinessBo != null) {
				log.debug("EntamapUnitBusinessController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<EntamapUnitBusinessBO> update(@PathVariable Long entamapUnitBusinessId, @RequestBody EntamapUnitBusinessBO input) throws CustomException{
    	log.debug("EntamapUnitBusinessController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			EntamapUnitBusinessBO entamapUnitBusinessBo = entamapUnitBusinessBL.update(entamapUnitBusinessId, input);
			if (entamapUnitBusinessBo != null) {
				log.debug("EntamapUnitBusinessController:update [END]");
			    return ResponseEntity.ok().body(entamapUnitBusinessBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<EntamapUnitBusinessBO> delete(@PathVariable Long entamapUnitBusinessId) throws CustomException{
        log.debug("EntamapUnitBusinessController:delete [START]");
        try {
			boolean entamapUnitBusinessDeleted = entamapUnitBusinessBL.delete(entamapUnitBusinessId);
			if (entamapUnitBusinessDeleted) {
				log.debug("EntamapUnitBusinessController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
