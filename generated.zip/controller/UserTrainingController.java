package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class UserTrainingController implements IUserTrainingController{

	private IUserTrainingBL userTrainingBL;
	
	@Autowired
	public UserTrainingController(IUserTrainingBL userTrainingBL) {
		this.userTrainingBL = userTrainingBL;
	}
	
	@Override
	public ResponseEntity<List<UserTrainingBO>> get() throws CustomException{
		log.debug("UserTrainingController:get [START]");
		try {
			log.debug("UserTrainingController:get [END]");
			return ResponseEntity.ok().body(userTrainingBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<UserTrainingBO> add(@Valid @RequestBody UserTrainingBO input) throws CustomException{
    	log.debug("UserTrainingController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			UserTrainingBO userTrainingBo = userTrainingBL.add(input);
			if (userTrainingBo != null) {
				log.debug("UserTrainingController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UserTrainingBO> update(@PathVariable Long userTrainingId, @RequestBody UserTrainingBO input) throws CustomException{
    	log.debug("UserTrainingController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			UserTrainingBO userTrainingBo = userTrainingBL.update(userTrainingId, input);
			if (userTrainingBo != null) {
				log.debug("UserTrainingController:update [END]");
			    return ResponseEntity.ok().body(userTrainingBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<UserTrainingBO> delete(@PathVariable Long userTrainingId) throws CustomException{
        log.debug("UserTrainingController:delete [START]");
        try {
			boolean userTrainingDeleted = userTrainingBL.delete(userTrainingId);
			if (userTrainingDeleted) {
				log.debug("UserTrainingController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
