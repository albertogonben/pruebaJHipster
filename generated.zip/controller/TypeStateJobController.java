package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeStateJobController implements ITypeStateJobController{

	private ITypeStateJobBL typeStateJobBL;
	
	@Autowired
	public TypeStateJobController(ITypeStateJobBL typeStateJobBL) {
		this.typeStateJobBL = typeStateJobBL;
	}
	
	@Override
	public ResponseEntity<List<TypeStateJobBO>> get() throws CustomException{
		log.debug("TypeStateJobController:get [START]");
		try {
			log.debug("TypeStateJobController:get [END]");
			return ResponseEntity.ok().body(typeStateJobBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeStateJobBO> add(@Valid @RequestBody TypeStateJobBO input) throws CustomException{
    	log.debug("TypeStateJobController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeStateJobBO typeStateJobBo = typeStateJobBL.add(input);
			if (typeStateJobBo != null) {
				log.debug("TypeStateJobController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeStateJobBO> update(@PathVariable Long typeStateJobId, @RequestBody TypeStateJobBO input) throws CustomException{
    	log.debug("TypeStateJobController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeStateJobBO typeStateJobBo = typeStateJobBL.update(typeStateJobId, input);
			if (typeStateJobBo != null) {
				log.debug("TypeStateJobController:update [END]");
			    return ResponseEntity.ok().body(typeStateJobBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeStateJobBO> delete(@PathVariable Long typeStateJobId) throws CustomException{
        log.debug("TypeStateJobController:delete [START]");
        try {
			boolean typeStateJobDeleted = typeStateJobBL.delete(typeStateJobId);
			if (typeStateJobDeleted) {
				log.debug("TypeStateJobController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
