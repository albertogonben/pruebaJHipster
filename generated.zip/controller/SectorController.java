package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class SectorController implements ISectorController{

	private ISectorBL sectorBL;
	
	@Autowired
	public SectorController(ISectorBL sectorBL) {
		this.sectorBL = sectorBL;
	}
	
	@Override
	public ResponseEntity<List<SectorBO>> get() throws CustomException{
		log.debug("SectorController:get [START]");
		try {
			log.debug("SectorController:get [END]");
			return ResponseEntity.ok().body(sectorBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<SectorBO> add(@Valid @RequestBody SectorBO input) throws CustomException{
    	log.debug("SectorController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			SectorBO sectorBo = sectorBL.add(input);
			if (sectorBo != null) {
				log.debug("SectorController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<SectorBO> update(@PathVariable Long sectorId, @RequestBody SectorBO input) throws CustomException{
    	log.debug("SectorController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			SectorBO sectorBo = sectorBL.update(sectorId, input);
			if (sectorBo != null) {
				log.debug("SectorController:update [END]");
			    return ResponseEntity.ok().body(sectorBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<SectorBO> delete(@PathVariable Long sectorId) throws CustomException{
        log.debug("SectorController:delete [START]");
        try {
			boolean sectorDeleted = sectorBL.delete(sectorId);
			if (sectorDeleted) {
				log.debug("SectorController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
