package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TaskDocumentController implements ITaskDocumentController{

	private ITaskDocumentBL taskDocumentBL;
	
	@Autowired
	public TaskDocumentController(ITaskDocumentBL taskDocumentBL) {
		this.taskDocumentBL = taskDocumentBL;
	}
	
	@Override
	public ResponseEntity<List<TaskDocumentBO>> get() throws CustomException{
		log.debug("TaskDocumentController:get [START]");
		try {
			log.debug("TaskDocumentController:get [END]");
			return ResponseEntity.ok().body(taskDocumentBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TaskDocumentBO> add(@Valid @RequestBody TaskDocumentBO input) throws CustomException{
    	log.debug("TaskDocumentController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TaskDocumentBO taskDocumentBo = taskDocumentBL.add(input);
			if (taskDocumentBo != null) {
				log.debug("TaskDocumentController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TaskDocumentBO> update(@PathVariable Long taskDocumentId, @RequestBody TaskDocumentBO input) throws CustomException{
    	log.debug("TaskDocumentController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TaskDocumentBO taskDocumentBo = taskDocumentBL.update(taskDocumentId, input);
			if (taskDocumentBo != null) {
				log.debug("TaskDocumentController:update [END]");
			    return ResponseEntity.ok().body(taskDocumentBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TaskDocumentBO> delete(@PathVariable Long taskDocumentId) throws CustomException{
        log.debug("TaskDocumentController:delete [START]");
        try {
			boolean taskDocumentDeleted = taskDocumentBL.delete(taskDocumentId);
			if (taskDocumentDeleted) {
				log.debug("TaskDocumentController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
