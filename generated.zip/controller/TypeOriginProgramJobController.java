package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeOriginProgramJobController implements ITypeOriginProgramJobController{

	private ITypeOriginProgramJobBL typeOriginProgramJobBL;
	
	@Autowired
	public TypeOriginProgramJobController(ITypeOriginProgramJobBL typeOriginProgramJobBL) {
		this.typeOriginProgramJobBL = typeOriginProgramJobBL;
	}
	
	@Override
	public ResponseEntity<List<TypeOriginProgramJobBO>> get() throws CustomException{
		log.debug("TypeOriginProgramJobController:get [START]");
		try {
			log.debug("TypeOriginProgramJobController:get [END]");
			return ResponseEntity.ok().body(typeOriginProgramJobBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeOriginProgramJobBO> add(@Valid @RequestBody TypeOriginProgramJobBO input) throws CustomException{
    	log.debug("TypeOriginProgramJobController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeOriginProgramJobBO typeOriginProgramJobBo = typeOriginProgramJobBL.add(input);
			if (typeOriginProgramJobBo != null) {
				log.debug("TypeOriginProgramJobController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeOriginProgramJobBO> update(@PathVariable Long typeOriginProgramJobId, @RequestBody TypeOriginProgramJobBO input) throws CustomException{
    	log.debug("TypeOriginProgramJobController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeOriginProgramJobBO typeOriginProgramJobBo = typeOriginProgramJobBL.update(typeOriginProgramJobId, input);
			if (typeOriginProgramJobBo != null) {
				log.debug("TypeOriginProgramJobController:update [END]");
			    return ResponseEntity.ok().body(typeOriginProgramJobBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeOriginProgramJobBO> delete(@PathVariable Long typeOriginProgramJobId) throws CustomException{
        log.debug("TypeOriginProgramJobController:delete [START]");
        try {
			boolean typeOriginProgramJobDeleted = typeOriginProgramJobBL.delete(typeOriginProgramJobId);
			if (typeOriginProgramJobDeleted) {
				log.debug("TypeOriginProgramJobController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
