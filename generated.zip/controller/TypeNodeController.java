package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;
import com.mapfre.gaia.amap3.validations.Validation;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class TypeNodeController implements ITypeNodeController{

	private ITypeNodeBL typeNodeBL;
	
	@Autowired
	public TypeNodeController(ITypeNodeBL typeNodeBL) {
		this.typeNodeBL = typeNodeBL;
	}
	
	@Override
	public ResponseEntity<List<TypeNodeBO>> get() throws CustomException{
		log.debug("TypeNodeController:get [START]");
		try {
			log.debug("TypeNodeController:get [END]");
			return ResponseEntity.ok().body(typeNodeBL.getAll());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
	}

    @Override
    public ResponseEntity<TypeNodeBO> add(@Valid @RequestBody TypeNodeBO input) throws CustomException{
    	log.debug("TypeNodeController:add [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
    	
			TypeNodeBO typeNodeBo = typeNodeBL.add(input);
			if (typeNodeBo != null) {
				log.debug("TypeNodeController:add [END]");
				return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.CONFLICT.value(), HttpStatus.CONFLICT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeNodeBO> update(@PathVariable Long typeNodeId, @RequestBody TypeNodeBO input) throws CustomException{
    	log.debug("TypeNodeController:update [START]");
    	try {
    		if(!Validation.validar(input)) {
    			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
    		}
			TypeNodeBO typeNodeBo = typeNodeBL.update(typeNodeId, input);
			if (typeNodeBo != null) {
				log.debug("TypeNodeController:update [END]");
			    return ResponseEntity.ok().body(typeNodeBo);
			}
			throw new CustomException(HttpStatus.NO_CONTENT.value(), HttpStatus.NO_CONTENT.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

    @Override
    public ResponseEntity<TypeNodeBO> delete(@PathVariable Long typeNodeId) throws CustomException{
        log.debug("TypeNodeController:delete [START]");
        try {
			boolean typeNodeDeleted = typeNodeBL.delete(typeNodeId);
			if (typeNodeDeleted) {
				log.debug("TypeNodeController:delete [END]");
			    return ResponseEntity.ok().build();
			}
			throw new CustomException(HttpStatus.NOT_FOUND.value(), HttpStatus.NOT_FOUND.getReasonPhrase());
		} catch (Exception e) {
			throw new CustomException(HttpStatus.INTERNAL_SERVER_ERROR.value(), HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
    }

}
