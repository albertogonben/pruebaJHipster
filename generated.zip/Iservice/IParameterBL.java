package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IParameterBL {

	/**
	 * Get all parameter
	 */
	List<ParameterBO> getAll();
	
	/**
	 * Add a parameter
	 */
	ParameterBO add(ParameterBO parameterBo);

	/**
	 * Update a parameter
	 */
	ParameterBO update(Long parameterId, ParameterBO parameterBo);

    /**
     * Delete a parameter
     */
    boolean delete(Long parameterId);

}
