package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ITypeChangeBL {

	/**
	 * Get all type change
	 */
	List<TypeChangeBO> getAll();
	
	/**
	 * Add a type change
	 */
	TypeChangeBO add(TypeChangeBO typeChangeBo);

	/**
	 * Update a type change
	 */
	TypeChangeBO update(Long typeChangeId, TypeChangeBO typeChangeBo);

    /**
     * Delete a type change
     */
    boolean delete(Long typeChangeId);

}
