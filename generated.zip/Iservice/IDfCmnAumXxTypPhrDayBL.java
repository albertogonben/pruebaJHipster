package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IDfCmnAumXxTypPhrDayBL {

	/**
	 * Get all df cmn aum xx typ phr day
	 */
	List<DfCmnAumXxTypPhrDayBO> getAll();
	
	/**
	 * Add a df cmn aum xx typ phr day
	 */
	DfCmnAumXxTypPhrDayBO add(DfCmnAumXxTypPhrDayBO dfCmnAumXxTypPhrDayBo);

	/**
	 * Update a df cmn aum xx typ phr day
	 */
	DfCmnAumXxTypPhrDayBO update(Long dfCmnAumXxTypPhrDayId, DfCmnAumXxTypPhrDayBO dfCmnAumXxTypPhrDayBo);

    /**
     * Delete a df cmn aum xx typ phr day
     */
    boolean delete(Long dfCmnAumXxTypPhrDayId);

}
