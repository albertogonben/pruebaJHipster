package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IEntamapUnitBusinessBL {

	/**
	 * Get all entamap unit business
	 */
	List<EntamapUnitBusinessBO> getAll();
	
	/**
	 * Add a entamap unit business
	 */
	EntamapUnitBusinessBO add(EntamapUnitBusinessBO entamapUnitBusinessBo);

	/**
	 * Update a entamap unit business
	 */
	EntamapUnitBusinessBO update(Long entamapUnitBusinessId, EntamapUnitBusinessBO entamapUnitBusinessBo);

    /**
     * Delete a entamap unit business
     */
    boolean delete(Long entamapUnitBusinessId);

}
