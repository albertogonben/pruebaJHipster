package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ITypeConceptImputationBL {

	/**
	 * Get all type concept imputation
	 */
	List<TypeConceptImputationBO> getAll();
	
	/**
	 * Add a type concept imputation
	 */
	TypeConceptImputationBO add(TypeConceptImputationBO typeConceptImputationBo);

	/**
	 * Update a type concept imputation
	 */
	TypeConceptImputationBO update(Long typeConceptImputationId, TypeConceptImputationBO typeConceptImputationBo);

    /**
     * Delete a type concept imputation
     */
    boolean delete(Long typeConceptImputationId);

}
