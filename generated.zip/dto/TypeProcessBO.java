package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeProcess database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeProcessBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeProcessPk;
	private java.lang.String cdTypeProcess;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String txtDescription;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}