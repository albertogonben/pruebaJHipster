package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Entamap database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EntamapBO implements Serializable {

	private static final long serialVersionUID;
	private long idEntityPk;
	private java.lang.String cdEntity;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String mrkActive;
	private java.lang.String txtDescription;
	private java.lang.String txtName;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Country country;
	private com.mapfre.gaia.amap3.entities.Currency currency;
	private com.mapfre.gaia.amap3.entities.Entamap entamap;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Entamap&gt; entamaps;
	private com.mapfre.gaia.amap3.entities.TypeOrganizationalStructure typeOrganizationalStructure;

}