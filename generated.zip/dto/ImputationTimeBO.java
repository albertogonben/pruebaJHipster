package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the ImputationTime database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ImputationTimeBO implements Serializable {

	private static final long serialVersionUID;
	private long idImputactonPk;
	private java.util.Date dateImputation;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal idJobFk;
	private java.math.BigDecimal idUserFk;
	private java.math.BigDecimal nmrHours;
	private java.lang.String txtComment;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.TypeConceptImputation typeConceptImputation;

}