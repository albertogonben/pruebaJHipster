package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeSpeciality database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeSpecialityBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeSpecialityPk;
	private java.lang.String cdTypeSpeciality;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String mrkActive;
	private java.lang.String txtTypeSpeciality;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}