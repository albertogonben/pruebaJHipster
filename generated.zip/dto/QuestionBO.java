package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Question database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuestionBO implements Serializable {

	private static final long serialVersionUID;
	private long idQuestionTypePk;
	private java.lang.String codQuestionType;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal isOptionQuestion;
	private java.math.BigDecimal isTextQuestion;
	private java.lang.String txtQuestion;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.QuestionnaireQuestion&gt; questionnaireQuestions;

}