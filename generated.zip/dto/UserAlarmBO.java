package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the UserAlarm database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserAlarmBO implements Serializable {

	private static final long serialVersionUID;
	private long idAlarmPk;
	private java.util.Date dateAdmission;
	private java.util.Date dateFinished;
	private java.util.Date dateInsert;
	private java.util.Date dateMaturity;
	private java.util.Date dateReading;
	private java.util.Date dateUpdate;
	private java.lang.String txtFree;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.TypeAlarm typeAlarm;
	private com.mapfre.gaia.amap3.entities.TypeCriquiteAlarm typeCriquiteAlarm;
	private com.mapfre.gaia.amap3.entities.UserAmap userAmap;

}