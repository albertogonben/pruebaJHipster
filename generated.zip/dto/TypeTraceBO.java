package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeTrace database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeTraceBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeTracePk;
	private java.lang.String cdTypeTrace;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String txtTypeTrace;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.JobLog&gt; jobLogs;

}