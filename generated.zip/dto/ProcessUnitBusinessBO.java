package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the ProcessUnitBusiness database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessUnitBusinessBO implements Serializable {

	private static final long serialVersionUID;
	private long idProcessPk;
	private java.lang.String cdProcess;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.util.Date dateVersion;
	private java.math.BigDecimal idTypeProcessFk;
	private java.math.BigDecimal nmrVersion;
	private java.lang.String txtName;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.ProcessCountry&gt; processCountries;
	private com.mapfre.gaia.amap3.entities.ProcessUnitBusiness processUnitBusiness;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.ProcessUnitBusiness&gt; processUnitBusinesses;
	private com.mapfre.gaia.amap3.entities.UnitBusiness unitBusiness;

}