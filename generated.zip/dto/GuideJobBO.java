package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the GuideJob database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class GuideJobBO implements Serializable {

	private static final long serialVersionUID;
	private long idNodePk;
	private java.lang.String cdNode;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.util.Date dateUse;
	private java.util.Date dateVersion;
	private java.math.BigDecimal nmVersion;
	private java.math.BigDecimal nmrUses;
	private java.lang.String txtNameGuide;
	private java.lang.String txtNode;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.GuideJob guideJob;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.GuideJob&gt; guideJobs;
	private com.mapfre.gaia.amap3.entities.TypeNode typeNode;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Task&gt; tasks;

}