package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the ProcessCountry database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProcessCountryBO implements Serializable {

	private static final long serialVersionUID;
	private long idProcessPk;
	private java.lang.String cdProceso;
	private java.util.Date dateInser;
	private java.util.Date dateUpdate;
	private java.util.Date dateVersion;
	private java.math.BigDecimal nmrSize;
	private java.math.BigDecimal nmrVersion;
	private java.lang.String txtNm;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Country country;
	private com.mapfre.gaia.amap3.entities.ProcessCountry processCountry;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.ProcessCountry&gt; processCountries;
	private com.mapfre.gaia.amap3.entities.ProcessUnitBusiness processUnitBusiness;
	private com.mapfre.gaia.amap3.entities.Sector sector;
	private com.mapfre.gaia.amap3.entities.TypeProcess typeProcess;
	private com.mapfre.gaia.amap3.entities.UnitBusiness unitBusiness;

}