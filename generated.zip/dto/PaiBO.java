package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Pai database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PaiBO implements Serializable {

	private static final long serialVersionUID;
	private long idPaiPk;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal nmrExerciese;
	private java.lang.String txtNm;
	private java.lang.String txtNmStandard;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Budget budget;
	private com.mapfre.gaia.amap3.entities.OrganizationalStructure organizationalStructure;
	private com.mapfre.gaia.amap3.entities.PredictionPersonnel predictionPersonnel;

}