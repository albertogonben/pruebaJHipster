package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeCategoryProfessional database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeCategoryProfessionalBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeCategoryPk;
	private java.lang.String cdTypeCategory;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal isBoss;
	private java.lang.String nmrLevel;
	private java.lang.String nmrOrder;
	private java.lang.String txtTypeCategory;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.UserCategory&gt; userCategories;

}