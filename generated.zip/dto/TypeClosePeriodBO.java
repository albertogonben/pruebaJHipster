package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeClosePeriod database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeClosePeriodBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeClosePeriodPk;
	private java.lang.String cdTypeClosePeriod;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String txtTypeClosePeriod;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.ClosePeriod&gt; closePeriods;

}