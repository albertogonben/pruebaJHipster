package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the DfCmnAumXxTypPhrDay database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DfCmnAumXxTypPhrDayBO implements Serializable {

	private static final long serialVersionUID;
	private java.math.BigDecimal idtSqn;
	private java.util.Date insDat;
	private java.lang.String insUsrVal;
	private java.util.Date lstPbcDat;
	private java.util.Date mdfDat;
	private java.lang.String mdfUsrVal;
	private java.lang.String phrAutVal;
	private java.lang.String phrVal;

}