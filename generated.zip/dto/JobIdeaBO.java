package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the JobIdea database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobIdeaBO implements Serializable {

	private static final long serialVersionUID;
	private long idRelactionPk;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Idea idea;
	private com.mapfre.gaia.amap3.entities.Job job;

}