package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TaskDocument database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskDocumentBO implements Serializable {

	private static final long serialVersionUID;
	private long idRelationPk;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.util.Date dateVersion;
	private byte[] fileDocument;
	private java.math.BigDecimal nmrSize;
	private java.math.BigDecimal nmrVersion;
	private java.lang.String txtName;
	private java.lang.String typeDocument;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Task task;

}