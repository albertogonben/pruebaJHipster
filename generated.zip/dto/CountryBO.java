package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Country database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CountryBO implements Serializable {

	private static final long serialVersionUID;
	private long idCountryPk;
	private java.lang.String cdCountry;
	private java.lang.String cdIso;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String txtName;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Currency currency;
	private com.mapfre.gaia.amap3.entities.Region region;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Entamap&gt; entamaps;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.MatrixRisk&gt; matrixRisks;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.OrganizationalStructure&gt; organizationalStructures;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.ProcessCountry&gt; processCountries;

}