package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeRole database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeRoleBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeRolePk;
	private java.lang.String cdTypeRole;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String txtTypeRole;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}