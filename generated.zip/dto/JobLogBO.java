package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the JobLog database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobLogBO implements Serializable {

	private static final long serialVersionUID;
	private long idEventPk;
	private java.util.Date dateEvent;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String txtEvent;
	private java.lang.String userEvent;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Job job;
	private com.mapfre.gaia.amap3.entities.TypeTrace typeTrace;

}