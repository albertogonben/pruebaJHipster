package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the ProgramJob database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProgramJobBO implements Serializable {

	private static final long serialVersionUID;
	private long idNodePk;
	private java.lang.String cdNode;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.util.Date dateVersion;
	private java.math.BigDecimal isImportant;
	private java.math.BigDecimal nmrVersion;
	private java.lang.String txtNode;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Job&gt; jobs;
	private com.mapfre.gaia.amap3.entities.Job job;
	private com.mapfre.gaia.amap3.entities.ProgramJob programJob;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.ProgramJob&gt; programJobs;
	private com.mapfre.gaia.amap3.entities.TypeNode typeNode;
	private com.mapfre.gaia.amap3.entities.TypeOriginProgramJob typeOriginProgramJob;

}