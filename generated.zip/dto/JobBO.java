package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Job database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class JobBO implements Serializable {

	private static final long serialVersionUID;
	private long idJobPk;
	private java.lang.String cdJob;
	private java.util.Date dateExpectFinish;
	private java.util.Date dateExpectStart;
	private java.util.Date dateFinish;
	private java.util.Date dateInsert;
	private java.util.Date dateStart;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal isPlannedJob;
	private java.lang.String txtEffect;
	private java.lang.String txtNm;
	private java.lang.String txtNmStandar;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Job job;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Job&gt; jobs;
	private com.mapfre.gaia.amap3.entities.ProgramJob programJob;
	private com.mapfre.gaia.amap3.entities.TypeJob typeJob;
	private com.mapfre.gaia.amap3.entities.TypeReasonClose typeReasonClose;
	private com.mapfre.gaia.amap3.entities.TypeStateJob typeStateJob;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.JobDocument&gt; jobDocuments;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.JobIdea&gt; jobIdeas;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.JobLog&gt; jobLogs;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.ProgramJob&gt; programJobs;

}