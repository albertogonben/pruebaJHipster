package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeChange database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeChangeBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeChangePk;
	private java.lang.String codTypeChange;
	private java.util.Date dateChange;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal idTypeCurrencyFk;
	private java.math.BigDecimal mrkActive;
	private java.math.BigDecimal nrmChange;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}