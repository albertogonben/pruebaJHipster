package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Task database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TaskBO implements Serializable {

	private static final long serialVersionUID;
	private long idTaskPk;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal idStateNodeFk;
	private java.lang.String txtoDescription;
	private java.lang.String txtoJob;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.GuideJob guideJob;
	private com.mapfre.gaia.amap3.entities.UserAmap userAmap1;
	private com.mapfre.gaia.amap3.entities.UserAmap userAmap2;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.TaskDocument&gt; taskDocuments;

}