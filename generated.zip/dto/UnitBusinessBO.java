package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the UnitBusiness database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UnitBusinessBO implements Serializable {

	private static final long serialVersionUID;
	private long idUnitBusinessPk;
	private java.lang.String cdUnitBusiness;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String mrkActive;
	private java.lang.String txtoUnitBusiness;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}