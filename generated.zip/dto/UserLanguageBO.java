package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the UserLanguage database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserLanguageBO implements Serializable {

	private static final long serialVersionUID;
	private long idUserLanguagePk;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String txtComment;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Language language;
	private com.mapfre.gaia.amap3.entities.TypeLevelLanguage typeLevelLanguage;
	private com.mapfre.gaia.amap3.entities.UserAmap userAmap;

}