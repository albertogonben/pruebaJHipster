package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Region database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegionBO implements Serializable {

	private static final long serialVersionUID;
	private long idRegionPk;
	private java.lang.String cdRegion;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal mrkActive;
	private java.lang.String txtRegion;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.AreaTerritorial areaTerritorial;

}