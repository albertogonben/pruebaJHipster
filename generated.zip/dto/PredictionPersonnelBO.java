package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the PredictionPersonnel database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class PredictionPersonnelBO implements Serializable {

	private static final long serialVersionUID;
	private long idPredictionPersonnelPk;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal nmrExerciese;
	private java.lang.String txtComments;
	private java.lang.String txtName;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Pai&gt; pais;
	private com.mapfre.gaia.amap3.entities.OrganizationalStructure organizationalStructure;

}