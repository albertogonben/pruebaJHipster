package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Origin database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OriginBO implements Serializable {

	private static final long serialVersionUID;
	private long idOriginPk;
	private java.lang.String cdOrigin;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String mrkActive;
	private java.lang.String txtOrigin;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}