package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeOriginProgramJob database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeOriginProgramJobBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeOriginPk;
	private java.lang.String cdTypeOrigin;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String txtTypeOrigin;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.ProgramJob&gt; programJobs;

}