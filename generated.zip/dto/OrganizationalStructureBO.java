package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the OrganizationalStructure database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrganizationalStructureBO implements Serializable {

	private static final long serialVersionUID;
	private long idOrganizationalStructurePk;
	private java.lang.String cdOrganizationalStructure;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String mrkActive;
	private java.math.BigDecimal nmrDaysLab;
	private java.math.BigDecimal nmrHoursLab;
	private java.lang.String txtAbbreviation;
	private java.lang.String txtDescription;
	private java.lang.String txtName;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Budget&gt; budgets;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Idea&gt; ideas;
	private com.mapfre.gaia.amap3.entities.Country country;
	private com.mapfre.gaia.amap3.entities.Currency currency;
	private com.mapfre.gaia.amap3.entities.OrganizationalStructure organizationalStructure;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.OrganizationalStructure&gt; organizationalStructures;
	private com.mapfre.gaia.amap3.entities.TypeOrganizationalStructure typeOrganizationalStructure;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Pai&gt; pais;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.PredictionPersonnel&gt; predictionPersonnels;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.UserCategory&gt; userCategories;

}