package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the MatrixRiskValuation database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MatrixRiskValuationBO implements Serializable {

	private static final long serialVersionUID;
	private long idValuationPk;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal idProcessFk;
	private java.math.BigDecimal nmrSize;
	private java.math.BigDecimal nmrValuation;
	private java.lang.String txtComment;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.FactorRisk factorRisk;
	private com.mapfre.gaia.amap3.entities.MatrixRisk matrixRisk;

}