package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the UserTraining database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserTrainingBO implements Serializable {

	private static final long serialVersionUID;
	private long idTrainingPk;
	private java.util.Date dateFinish;
	private java.util.Date dateInsert;
	private java.util.Date dateStart;
	private java.util.Date dateUpdate;
	private java.util.Date nmrExerciese;
	private java.lang.String txtCenter;
	private java.lang.String txtComment;
	private java.lang.String txtTitle;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.UserAmap userAmap;

}