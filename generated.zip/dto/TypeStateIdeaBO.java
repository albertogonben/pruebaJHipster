package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeStateIdea database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeStateIdeaBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeStateIdeaPk;
	private java.lang.String cdTypeStateIdea;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String mrkActive;
	private java.lang.String txtTypeStateIdea;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}