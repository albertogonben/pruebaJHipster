package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the UserAmap database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserAmapBO implements Serializable {

	private static final long serialVersionUID;
	private long idUserPk;
	private java.math.BigDecimal cdNuuma;
	private java.util.Date dateAdmission;
	private java.util.Date dateInsert;
	private java.util.Date dateOffSick;
	private java.util.Date dateUpdate;
	private byte[] fileCvEn;
	private byte[] fileCvEs;
	private byte[] fileFirm;
	private byte[] filePhoto;
	private java.math.BigDecimal isMobilityFunctional;
	private java.math.BigDecimal isMobilityGeographic;
	private java.math.BigDecimal mrkActive;
	private java.math.BigDecimal nmrLaboralHours;
	private java.math.BigDecimal nmrMobile;
	private java.lang.String txtComment;
	private java.lang.String txtExperience;
	private java.lang.String txtLastname1;
	private java.lang.String txtLastname2;
	private java.lang.String txtMail;
	private java.lang.String txtName;
	private java.lang.String typeTreatment;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Department department;
	private com.mapfre.gaia.amap3.entities.Entamap entamap;
	private com.mapfre.gaia.amap3.entities.Language language;
	private com.mapfre.gaia.amap3.entities.OrganizationalStructure organizationalStructure;
	private com.mapfre.gaia.amap3.entities.TypeRole typeRole;

}