package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the UserCategory database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserCategoryBO implements Serializable {

	private static final long serialVersionUID;
	private long idCategoryUserPk;
	private java.util.Date dateFinish;
	private java.util.Date dateInsert;
	private java.util.Date dateStart;
	private java.util.Date dateUpdate;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.OrganizationalStructure organizationalStructure;
	private com.mapfre.gaia.amap3.entities.TypeCategoryProfessional typeCategoryProfessional;
	private com.mapfre.gaia.amap3.entities.TypeReasonChangeCategory typeReasonChangeCategory;
	private com.mapfre.gaia.amap3.entities.UserAmap userAmap;

}