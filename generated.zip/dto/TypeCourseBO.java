package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeCourse database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeCourseBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypeCoursePk;
	private java.lang.String cdTypeCourse;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal mrkActive;
	private java.lang.String txtTypeCourse;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}