package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the QuestionnaireQuestion database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QuestionnaireQuestionBO implements Serializable {

	private static final long serialVersionUID;
	private long idQuestionnaireQuestionPk;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.util.Date dateVersion;
	private java.math.BigDecimal nmrOrder;
	private java.math.BigDecimal nmrVersion;
	private java.util.Date userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.QuestionnaireEvaluation&gt; questionnaireEvaluations;
	private com.mapfre.gaia.amap3.entities.Question question;
	private com.mapfre.gaia.amap3.entities.Questionnaire questionnaire;

}