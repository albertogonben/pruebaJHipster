package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the Budget database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class BudgetBO implements Serializable {

	private static final long serialVersionUID;
	private long idBudgetPk;
	private java.util.Date dateFinish;
	private java.util.Date dateInsert;
	private java.util.Date dateStart;
	private java.util.Date dateUpdate;
	private java.util.Date dateValitacion;
	private java.math.BigDecimal nmrExerciese;
	private java.lang.String txtComments;
	private java.lang.String txtName;
	private java.lang.String txtoNameStandard;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private com.mapfre.gaia.amap3.entities.Currency currency;
	private com.mapfre.gaia.amap3.entities.OrganizationalStructure organizationalStructure;
	private com.mapfre.gaia.amap3.entities.TypeStatusBudget typeStatusBudget;
	private com.mapfre.gaia.amap3.entities.UserAmap userAmap1;
	private com.mapfre.gaia.amap3.entities.UserAmap userAmap2;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Pai&gt; pais;

}