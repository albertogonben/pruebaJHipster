package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypePredictionChange database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypePredictionChangeBO implements Serializable {

	private static final long serialVersionUID;
	private long idTypePredictionChangePk;
	private java.lang.String cdgoTypePrediction;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.math.BigDecimal idTypeCurrencyFk;
	private java.math.BigDecimal mrkActive;
	private java.math.BigDecimal nmrChange;
	private java.math.BigDecimal nmrExerciese;
	private java.math.BigDecimal nmrExercieseApply;
	private java.lang.String txtoTypePrediction;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;

}