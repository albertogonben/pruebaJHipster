package com.mapfre.gaia.amap3;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

/**
 * The bussiness class for the TypeReasonClose database table.
 * 
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TypeReasonCloseBO implements Serializable {

	private static final long serialVersionUID;
	private long idReasonClosePk;
	private java.lang.String cdReason;
	private java.util.Date dateInsert;
	private java.util.Date dateUpdate;
	private java.lang.String mrkActive;
	private java.lang.String txtReason;
	private java.lang.String userInsert;
	private java.lang.String userUpdate;
	private java.util.List&lt;com.mapfre.gaia.amap3.entities.Job&gt; jobs;

}