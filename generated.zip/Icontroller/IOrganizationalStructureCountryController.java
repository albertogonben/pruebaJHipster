package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Api(value = "API organizational structure country")
public interface IOrganizationalStructureCountryController {

	@ApiOperation(value = "Get all organizational structure country", response = String.class, responseContainer = "List")
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
			@ApiResponse(code = 500, message = "Internal server error")})

	@GetMapping("/organizational-structure-country")
	ResponseEntity<List<OrganizationalStructureCountryBO>> get() throws CustomException;

	@ApiOperation(value = "Add a organizational structure country", response = OrganizationalStructureCountryBO.class)
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Successfully created organizational structure country"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") ,
			@ApiResponse(code = 409, message = "The request could not be completed") ,
			@ApiResponse(code = 500, message = "Internal server error")})
	@PostMapping("/organizational-structure-country")
	ResponseEntity<OrganizationalStructureCountryBO> add(@Valid @RequestBody OrganizationalStructureCountryBO input) throws CustomException;

	@ApiOperation(value = "Update a organizational structure country", response = OrganizationalStructureCountryBO.class)
	@ApiResponses(value = { @ApiResponse(code = 204, message = "Successfully updated organizational structure country"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found"),
			@ApiResponse(code = 500, message = "Internal server error")})

	@PutMapping("/organizational-structure-country/{organizationalStructureCountryId}")
	ResponseEntity<OrganizationalStructureCountryBO> update(@PathVariable Long organizationalStructureCountryId, @Valid @RequestBody OrganizationalStructureCountryBO input) throws CustomException;

	@ApiOperation(value = "Delete a organizational structure country")
	@ApiResponses(value = { @ApiResponse(code = 201, message = "Successfully deleted organizational structure country"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") ,
			@ApiResponse(code = 500, message = "Internal server error")})

	@DeleteMapping("/organizational-structure-country/{organizationalStructureCountryId}")
	ResponseEntity<OrganizationalStructureCountryBO> delete(@PathVariable Long organizationalStructureCountryId) throws CustomException;

}
