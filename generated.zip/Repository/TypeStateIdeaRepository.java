package com.mapfre.gaia.amap3.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mapfre.gaia.amap3.entities.TypeStateIdea;

public interface TypeStateIdeaRepository extends JpaRepository<TypeStateIdea, Long> {

}
