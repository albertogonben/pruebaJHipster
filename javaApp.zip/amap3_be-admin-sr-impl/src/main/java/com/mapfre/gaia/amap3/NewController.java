package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class NewController implements INewController {

	private INewBL newBL;

	@Autowired
	public NewController(INewBL NewBL) {
		this.newBL = NewBL;
	}

	@Override
	public ResponseEntity<List<NewBO>> get() {
		try {
			return ResponseEntity.ok().body(newBL.getAll());
		} catch (Exception e) {
			log.error("NewController:get", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<NewBO> add(@Valid @RequestBody NewBO input) {
		try {
			NewBO newBo = newBL.add(input);
			if (newBo != null) {
				return ResponseEntity.ok().build();
			}
			return ResponseEntity.status(HttpStatus.CONFLICT).build();
		} catch (Exception e) {
			log.error("NewController:add", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<NewBO> update(@PathVariable Long newId, @RequestBody NewBO input) {
		try {
			NewBO newBo = newBL.update(newId, input);
			if (newBo != null) {
				return ResponseEntity.ok().body(newBo);
			}
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			log.error("NewController:update", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<NewBO> delete(@PathVariable Long newId) {
		try {
			boolean newDeleted = newBL.delete(newId);
			if (newDeleted) {
				return ResponseEntity.noContent().build();
			}
			return ResponseEntity.notFound().build();
		} catch (Exception e) {
			log.error("NewController:delete", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}

	}

}
