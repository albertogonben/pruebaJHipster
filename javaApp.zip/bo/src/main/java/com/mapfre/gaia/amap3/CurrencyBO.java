package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;


/**
 * The business object class for the CURRENCY database table.
 * 
 */
@Data
public class CurrencyBO implements Serializable {
	private static final long serialVersionUID = 1L;


	private long idCurrencyPk;

	private String cdCurrency;
	
	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal mrkActive;

	private String txtCurrency;

	private String userInsert;

	private String userUpdate;


	private List<CountryBO> countries;

	public CurrencyBO() {
	}


}