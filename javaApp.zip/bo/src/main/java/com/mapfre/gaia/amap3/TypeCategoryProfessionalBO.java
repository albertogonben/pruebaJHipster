package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the TYPE_CATEGORY_PROFESSIONAL database table.
 * 
 */
@Data
public class TypeCategoryProfessionalBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeCategoryPk;

	private String cdTypeCategory;

	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal isBoss;

	private String nmrLevel;

	private String nmrOrder;

	private String txtTypeCategory;

	private String userInsert;

	private String userUpdate;

	public TypeCategoryProfessionalBO() {
	}

}