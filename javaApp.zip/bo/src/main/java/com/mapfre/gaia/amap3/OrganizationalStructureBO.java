package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the ORGANIZATIONAL_STRUCTURE database table.
 * 
 */
@Data
public class OrganizationalStructureBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idOrganizationalStructurePk;

	private String cdOrganizationalStructure;

	private Date dateInsert;

	private Date dateUpdate;

	private String mrkActive;

	private BigDecimal nmrDaysLab;

	private BigDecimal nmrHoursLab;

	private String txtAbbreviation;

	private String txtDescription;

	private String txtName;

	private String userInsert;

	private String userUpdate;

	private TypeOrganizationalStructureBO typeOrganizationalStructure;

	public OrganizationalStructureBO() {
	}

}