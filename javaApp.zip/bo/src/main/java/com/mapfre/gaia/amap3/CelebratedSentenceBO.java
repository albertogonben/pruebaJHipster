package com.mapfre.gaia.amap3;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The business object class for the CELEBRATED_SENTENCES database table.
 * 
 */
@Data
@AllArgsConstructor
public class CelebratedSentenceBO {

	private long idSentencePk;

	private String cdSentence;

	private Date dateInsert;

	private Date datePublication;

	private Date dateUpdate;

	private String txtAutor;

	private String txtSentence;

	private String userInsert;

	private String userUpdate;

	public CelebratedSentenceBO() {
	}

}