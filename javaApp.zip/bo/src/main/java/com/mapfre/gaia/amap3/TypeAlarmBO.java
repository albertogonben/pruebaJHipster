package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the TYPE_ALARM database table.
 * 
 */
@Data
public class TypeAlarmBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeAlarmPk;

	private String cdTypeAlarm;

	private Date dateInsert;

	private Date dateUpdate;

	private String fileLogo;

	private BigDecimal isComunicationMail;

	private BigDecimal mrkActive;

	private String txtTypeAlarm;

	private String userInsert;

	private String userUpdate;

	private TypeCategoryAlarmBO typeCategoryAlarm;

	public TypeAlarmBO() {
	}

}