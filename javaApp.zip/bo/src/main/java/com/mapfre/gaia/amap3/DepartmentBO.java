package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the DEPARTMENT database table.
 * 
 */
@Data
public class DepartmentBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idDepartmentPk;

	private String cdDepartment;

	private Date dateInsert;

	private Date dateUpdate;

	private String mrkActive;

	private String txtDepartment;

	private String userInsert;

	private String userUpdate;

	public DepartmentBO() {
	}

}