package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the TYPE_ROLE database table.
 * 
 */
@Data
public class TypeRoleBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeRolePk;

	private String cdTypeRole;

	private Date dateInsert;

	private Date dateUpdate;

	private String txtTypeRole;

	private String userInsert;

	private String userUpdate;

	public TypeRoleBO() {
	}

}