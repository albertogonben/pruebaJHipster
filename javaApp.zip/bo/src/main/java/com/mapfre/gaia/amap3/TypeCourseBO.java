package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the TYPE_COURSE database table.
 * 
 */
@Data
public class TypeCourseBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idTypeCoursePk;

	private String cdTypeCourse;

	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal mrkActive;

	private String txtTypeCourse;

	private String userInsert;

	private String userUpdate;

	public TypeCourseBO() {
	}

}