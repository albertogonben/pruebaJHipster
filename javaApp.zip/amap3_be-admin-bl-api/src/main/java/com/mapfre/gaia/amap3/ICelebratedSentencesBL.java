package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ICelebratedSentencesBL {

	/**
	 * Get all celebrated sentences
	 * @return
	 */
	List<CelebratedSentenceBO> getAll();
	
	/**
	 * Creation of a celebrated sentence
	 * @param input
	 * @return
	 */
	CelebratedSentenceBO save(CelebratedSentenceBO input);
	
	/**
	 * Update of a celebrated sentence
	 * @param id
	 * @param input
	 * @return
	 */
	CelebratedSentenceBO update(Long id, CelebratedSentenceBO input);
	
	/**
	 * Delete of a celebrated sentence
	 * @param id
	 * @return
	 */
	boolean delete(Long id);
	
}
