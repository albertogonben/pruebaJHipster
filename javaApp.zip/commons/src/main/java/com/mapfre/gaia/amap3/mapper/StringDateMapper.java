package com.mapfre.gaia.amap3.mapper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.converter.BidirectionalConverter;
import ma.glasnost.orika.metadata.Type;

@Slf4j
public class StringDateMapper extends BidirectionalConverter<String, Date> {

	@Override
	public Date convertTo(String source, Type<Date> destinationType, MappingContext mappingContext) {

		Date dateReturn = new Date();
		try {
			dateReturn = new SimpleDateFormat("dd/MM/yyyy").parse(source);
		} catch (ParseException e) {
			log.debug("Error StringDateMapper:convertTo:" + source + ":to:" + destinationType);
		}
		return dateReturn;
	}

	@Override
	public String convertFrom(Date source, Type<String> destinationType, MappingContext mappingContext) {

		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = dateFormat.format(source);
		
		return strDate;
	}

}
