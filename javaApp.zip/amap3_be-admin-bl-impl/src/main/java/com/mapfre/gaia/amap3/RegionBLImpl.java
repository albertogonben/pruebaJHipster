package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.Region;
import com.mapfre.gaia.amap3.repositories.RegionRepository;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Service
@Transactional
public class RegionBLImpl implements IRegionBL {

	private RegionRepository regionRepository;
	private MapperFacade mapperRegion;

	@Autowired
	public RegionBLImpl(RegionRepository regionRepository) {
		this.regionRepository = regionRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		mapperFactory.classMap(Region.class, RegionBO.class).byDefault().register();
		this.mapperRegion = mapperFactory.getMapperFacade();

	}

	@Override
	public List<RegionBO> getAll() {
		List<RegionBO> listRegion = new ArrayList<RegionBO>();

		List<Region> regionEntities = regionRepository.findAll();
		for (Region regionEntity : regionEntities) {
			listRegion.add(mapperRegion.map(regionEntity, RegionBO.class));
		}
		return listRegion;
	}

	@Override
	public RegionBO add(RegionBO regionBO) {
		Region regionEntity = mapperRegion.map(regionBO, Region.class);
		return mapperRegion.map(regionRepository.save(regionEntity),
				RegionBO.class);
	}

	@Override
	public RegionBO update(Long regionId, RegionBO regionBO) {
		Region regionEntity = regionRepository.getOne(regionId);
		if (regionEntity != null) {

			// TODO Alberto Setear datos de entrada Hito III

			return mapperRegion.map(regionRepository.save(regionEntity),
					RegionBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long regionId) {
		Region regionEntity = regionRepository.findOne(regionId);
		if (regionEntity != null) {
			regionRepository.delete(regionId);
			return true;
		}
		return false;
	}

}
