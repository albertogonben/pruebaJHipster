package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.OrganizationalStructure;
import com.mapfre.gaia.amap3.repositories.OrganizationalStructureRepository;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Service
@Transactional
public class OrganizationalStructureBLImpl implements IOrganizationalStructureBL {

	private OrganizationalStructureRepository organizationalStructureRepository;
	private MapperFacade mapperOrganizationalStructure;

	@Autowired
	public OrganizationalStructureBLImpl(OrganizationalStructureRepository organizationalStructureRepository) {
		this.organizationalStructureRepository = organizationalStructureRepository;

		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		mapperFactory.classMap(OrganizationalStructure.class, OrganizationalStructureBO.class).byDefault().register();
		this.mapperOrganizationalStructure = mapperFactory.getMapperFacade();

	}

	@Override
	public List<OrganizationalStructureBO> getAll() {
		List<OrganizationalStructureBO> listorganizationalStructure = new ArrayList<OrganizationalStructureBO>();

		List<OrganizationalStructure> organizationalStructureEntities = organizationalStructureRepository.findAll();
		for (OrganizationalStructure organizationalStructureEntity : organizationalStructureEntities) {
			listorganizationalStructure.add(
					mapperOrganizationalStructure.map(organizationalStructureEntity, OrganizationalStructureBO.class));
		}
		return listorganizationalStructure;
	}

	@Override
	public OrganizationalStructureBO add(OrganizationalStructureBO organizationalStructureBO) {
		OrganizationalStructure organizationalStructureEntity = mapperOrganizationalStructure
				.map(organizationalStructureBO, OrganizationalStructure.class);
		return mapperOrganizationalStructure.map(organizationalStructureRepository.save(organizationalStructureEntity),
				OrganizationalStructureBO.class);
	}

	@Override
	public OrganizationalStructureBO update(Long organizationalStructureId,
			OrganizationalStructureBO organizationalStructureBO) {
		OrganizationalStructure organizationalStructureEntity = organizationalStructureRepository
				.getOne(organizationalStructureId);
		if (organizationalStructureEntity != null) {

			organizationalStructureEntity.setNmrDaysLab(organizationalStructureBO.getNmrDaysLab());
			organizationalStructureEntity.setNmrHoursLab(organizationalStructureBO.getNmrHoursLab());
			//organizationalStructureEntity.setMrkActive(organizationalStructureBO.getMrkActive());
			organizationalStructureEntity.setTxtName(organizationalStructureBO.getTxtName());
			
			// TODO Alberto Setear datos de entrada - Pendiente diseño Front

			return mapperOrganizationalStructure.map(
					organizationalStructureRepository.save(organizationalStructureEntity),
					OrganizationalStructureBO.class);
		}

		return null;
	}

	@Override
	public boolean delete(Long organizationalStructureId) {
		OrganizationalStructure organizationalStructureEntity = organizationalStructureRepository
				.findOne(organizationalStructureId);
		if (organizationalStructureEntity != null) {
			organizationalStructureRepository.delete(organizationalStructureId);
			return true;
		}
		return false;
	}

}
