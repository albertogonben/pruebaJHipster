package com.mapfre.gaia.amap3.utils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Util {

	public static Object getDateUser(Object object, String operation) {

		log.debug("Start method getDatUser");

		Map<String, Class> listMethods = new HashMap<String, Class>();
		if ("INSERT".equals(operation)) {
			listMethods.put("setDateInsert", Date.class);
			listMethods.put("setUserInsert", String.class);
		}
		listMethods.put("setDateUpdate", Date.class);
		listMethods.put("setUserUpdate", String.class);

		Map<String, Object> listParameters = new HashMap<String, Object>();
		if ("INSERT".equals(operation)) {
			listMethods.put("setDateInsert", Date.class);
			listParameters.put("setUserInsert", "");
		}
		listParameters.put("setDateUpdate", new Date());
		listParameters.put("setUserUpdate", "");

		List<Method> listMethodExecute = new ArrayList<Method>();

		for (String method : listMethods.keySet()) {
			try {
				listMethodExecute.add(object.getClass().getDeclaredMethod(method, listMethods.get(method)));
			} catch (NoSuchMethodException | SecurityException e) {
				log.debug("Error: " + e.getMessage());
			}
		}

		for (Method methodExecute : listMethodExecute) {
			try {
				methodExecute.invoke(object, listParameters.get(methodExecute.getName()));
			} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
				log.debug("Error: " + e.getMessage());
			}
		}

		log.debug("End method getDatUser");

		return object;
	}

}
