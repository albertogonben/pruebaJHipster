package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.CelebratedSentence;
import com.mapfre.gaia.amap3.repositories.CelebratedSentencesRepository;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Service
@Transactional
public class CelebratedSentencesBLImpl implements ICelebratedSentencesBL {

	private CelebratedSentencesRepository celebratedSentencesRepository;
	private MapperFacade mapperCelebratedSentence;
	

	@Autowired
	public CelebratedSentencesBLImpl(CelebratedSentencesRepository celebratedSentenceRepository) {
		
		this.celebratedSentencesRepository = celebratedSentenceRepository;
		
		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		mapperFactory.classMap(CelebratedSentence.class, CelebratedSentenceBO.class).byDefault().register();
		this.mapperCelebratedSentence = mapperFactory.getMapperFacade();
	}

	@Override
	public List<CelebratedSentenceBO> getAll() {
		
		List<CelebratedSentenceBO> celebratedSentencesOut = new ArrayList<CelebratedSentenceBO>();
		
		List<CelebratedSentence> celebratedSentencesList = celebratedSentencesRepository.findAll();
		
		for (CelebratedSentence celebratedSentency : celebratedSentencesList) {
			celebratedSentencesOut.add(mapperCelebratedSentence.map(celebratedSentency, CelebratedSentenceBO.class));
		}
		
		return celebratedSentencesOut;
	}

	@Override
	public CelebratedSentenceBO save(CelebratedSentenceBO input) {
		
		CelebratedSentence output = celebratedSentencesRepository.save(mapperCelebratedSentence.map(input, CelebratedSentence.class));
		
		if(output != null) {
			return mapperCelebratedSentence.map(output, CelebratedSentenceBO.class);
		}else {
			return null;
		}
		
	}

	@Override
	public CelebratedSentenceBO update(Long id, CelebratedSentenceBO input) {
		
		CelebratedSentence entityToUpdate = celebratedSentencesRepository.getOne(id);
		
		if (entityToUpdate != null) {
		
			entityToUpdate.setTxtAutor(input.getTxtAutor());
			entityToUpdate.setTxtSentence(input.getTxtSentence());
			
			CelebratedSentence output = celebratedSentencesRepository.save(entityToUpdate);
			
			return mapperCelebratedSentence.map(output, CelebratedSentenceBO.class);
			
		}else {
			return null;
		}
		
	}

	@Override
	public boolean delete(Long id) {
		
		CelebratedSentence entityToDelete = celebratedSentencesRepository.findOne(id);
		
		if(entityToDelete != null) {
			celebratedSentencesRepository.delete(id);
			return true;
		}else {
			return false;
		}
		
	}

}
