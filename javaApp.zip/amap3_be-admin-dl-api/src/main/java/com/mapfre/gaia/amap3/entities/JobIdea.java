package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the JOB_IDEA database table.
 * 
 */
@Entity
@Table(name="JOB_IDEA")
@NamedQuery(name="JobIdea.findAll", query="SELECT j FROM JobIdea j")
public class JobIdea implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="JOB_IDEA_IDRELATIONPK_GENERATOR", sequenceName="JOB_IDEA_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="JOB_IDEA_IDRELATIONPK_GENERATOR")
	@Column(name="ID_RELATION_PK")
	private long idRelationPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Idea
	@ManyToOne
	@JoinColumn(name="ID_IDEA_FK")
	private Idea idea;

	//bi-directional many-to-one association to Job
	@ManyToOne
	@JoinColumn(name="ID_JOB_FK")
	private Job job;

	public JobIdea() {
	}

	public long getIdRelationPk() {
		return this.idRelationPk;
	}

	public void setIdRelationPk(long idRelationPk) {
		this.idRelationPk = idRelationPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Idea getIdea() {
		return this.idea;
	}

	public void setIdea(Idea idea) {
		this.idea = idea;
	}

	public Job getJob() {
		return this.job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

}