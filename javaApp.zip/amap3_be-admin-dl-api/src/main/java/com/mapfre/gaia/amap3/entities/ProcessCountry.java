package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PROCESS_COUNTRY database table.
 * 
 */
@Entity
@Table(name="PROCESS_COUNTRY")
@NamedQuery(name="ProcessCountry.findAll", query="SELECT p FROM ProcessCountry p")
public class ProcessCountry implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PROCESS_COUNTRY_IDPROCESSPK_GENERATOR", sequenceName="PROCESS_COUNTRY_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PROCESS_COUNTRY_IDPROCESSPK_GENERATOR")
	@Column(name="ID_PROCESS_PK")
	private long idProcessPk;

	@Column(name="CD_PROCESO")
	private String cdProceso;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_VERSION")
	private Date dateVersion;

	@Column(name="NMR_VERSION")
	private BigDecimal nmrVersion;

	@Column(name="TXT_NM")
	private String txtNm;

	//bi-directional many-to-one association to MatrixRiskValuation
	@OneToMany(mappedBy="processCountry")
	private List<MatrixRiskValuation> matrixRiskValuations;

	//bi-directional many-to-one association to Sector
	@ManyToOne
	@JoinColumn(name="ID_SECTOR_FK")
	private Sector sector;

	//bi-directional many-to-one association to TypeProcess
	@ManyToOne
	@JoinColumn(name="ID_TYPE_PROCESS_FK")
	private TypeProcess typeProcess;

	public ProcessCountry() {
	}

	public long getIdProcessPk() {
		return this.idProcessPk;
	}

	public void setIdProcessPk(long idProcessPk) {
		this.idProcessPk = idProcessPk;
	}

	public String getCdProceso() {
		return this.cdProceso;
	}

	public void setCdProceso(String cdProceso) {
		this.cdProceso = cdProceso;
	}

	public Date getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}

	public BigDecimal getNmrVersion() {
		return this.nmrVersion;
	}

	public void setNmrVersion(BigDecimal nmrVersion) {
		this.nmrVersion = nmrVersion;
	}

	public String getTxtNm() {
		return this.txtNm;
	}

	public void setTxtNm(String txtNm) {
		this.txtNm = txtNm;
	}

	public List<MatrixRiskValuation> getMatrixRiskValuations() {
		return this.matrixRiskValuations;
	}

	public void setMatrixRiskValuations(List<MatrixRiskValuation> matrixRiskValuations) {
		this.matrixRiskValuations = matrixRiskValuations;
	}

	public MatrixRiskValuation addMatrixRiskValuation(MatrixRiskValuation matrixRiskValuation) {
		getMatrixRiskValuations().add(matrixRiskValuation);
		matrixRiskValuation.setProcessCountry(this);

		return matrixRiskValuation;
	}

	public MatrixRiskValuation removeMatrixRiskValuation(MatrixRiskValuation matrixRiskValuation) {
		getMatrixRiskValuations().remove(matrixRiskValuation);
		matrixRiskValuation.setProcessCountry(null);

		return matrixRiskValuation;
	}

	public Sector getSector() {
		return this.sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	public TypeProcess getTypeProcess() {
		return this.typeProcess;
	}

	public void setTypeProcess(TypeProcess typeProcess) {
		this.typeProcess = typeProcess;
	}

}