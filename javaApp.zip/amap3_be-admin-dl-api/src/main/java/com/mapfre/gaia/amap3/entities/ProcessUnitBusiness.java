package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the PROCESS_UNIT_BUSINESS database table.
 * 
 */
@Entity
@Table(name="PROCESS_UNIT_BUSINESS")
@NamedQuery(name="ProcessUnitBusiness.findAll", query="SELECT p FROM ProcessUnitBusiness p")
public class ProcessUnitBusiness implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PROCESS_UNIT_BUSINESS_IDPROCESSPK_GENERATOR", sequenceName="PROCESS_UNIT_BUSINESS_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PROCESS_UNIT_BUSINESS_IDPROCESSPK_GENERATOR")
	@Column(name="ID_PROCESS_PK")
	private long idProcessPk;

	@Column(name="CD_PROCESS")
	private String cdProcess;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_VERSION")
	private Date dateVersion;

	@Column(name="NMR_VERSION")
	private BigDecimal nmrVersion;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to ProcessUnitBusiness
	@ManyToOne
	@JoinColumn(name="ID_PROCESS_FATHER_FK")
	private ProcessUnitBusiness processUnitBusiness;

	//bi-directional many-to-one association to ProcessUnitBusiness
	@OneToMany(mappedBy="processUnitBusiness")
	private List<ProcessUnitBusiness> processUnitBusinesses;

	//bi-directional many-to-one association to TypeProcess
	@ManyToOne
	@JoinColumn(name="ID_TYPE_PROCESS_FK")
	private TypeProcess typeProcess;

	//bi-directional many-to-one association to UnitBusiness
	@ManyToOne
	@JoinColumn(name="ID_UNIT_BUSINESS_FK")
	private UnitBusiness unitBusiness;

	public ProcessUnitBusiness() {
	}

	public long getIdProcessPk() {
		return this.idProcessPk;
	}

	public void setIdProcessPk(long idProcessPk) {
		this.idProcessPk = idProcessPk;
	}

	public String getCdProcess() {
		return this.cdProcess;
	}

	public void setCdProcess(String cdProcess) {
		this.cdProcess = cdProcess;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}

	public BigDecimal getNmrVersion() {
		return this.nmrVersion;
	}

	public void setNmrVersion(BigDecimal nmrVersion) {
		this.nmrVersion = nmrVersion;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public ProcessUnitBusiness getProcessUnitBusiness() {
		return this.processUnitBusiness;
	}

	public void setProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness) {
		this.processUnitBusiness = processUnitBusiness;
	}

	public List<ProcessUnitBusiness> getProcessUnitBusinesses() {
		return this.processUnitBusinesses;
	}

	public void setProcessUnitBusinesses(List<ProcessUnitBusiness> processUnitBusinesses) {
		this.processUnitBusinesses = processUnitBusinesses;
	}

	public ProcessUnitBusiness addProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness) {
		getProcessUnitBusinesses().add(processUnitBusiness);
		processUnitBusiness.setProcessUnitBusiness(this);

		return processUnitBusiness;
	}

	public ProcessUnitBusiness removeProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness) {
		getProcessUnitBusinesses().remove(processUnitBusiness);
		processUnitBusiness.setProcessUnitBusiness(null);

		return processUnitBusiness;
	}

	public TypeProcess getTypeProcess() {
		return this.typeProcess;
	}

	public void setTypeProcess(TypeProcess typeProcess) {
		this.typeProcess = typeProcess;
	}

	public UnitBusiness getUnitBusiness() {
		return this.unitBusiness;
	}

	public void setUnitBusiness(UnitBusiness unitBusiness) {
		this.unitBusiness = unitBusiness;
	}

}