package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_ALARM database table.
 * 
 */
@Entity
@Table(name="TYPE_ALARM")
@NamedQuery(name="TypeAlarm.findAll", query="SELECT t FROM TypeAlarm t")
public class TypeAlarm implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_ALARM_IDTYPEALARMPK_GENERATOR", sequenceName="TYPE_ALARM_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_ALARM_IDTYPEALARMPK_GENERATOR")
	@Column(name="ID_TYPE_ALARM_PK")
	private long idTypeAlarmPk;

	@Column(name="CD_TYPE_ALARM")
	private String cdTypeAlarm;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="FILE_LOGO")
	private String fileLogo;

	@Column(name="IS_COMUNICATION_MAIL")
	private BigDecimal isComunicationMail;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_TYPE_ALARM")
	private String txtTypeAlarm;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to TypeCategoryAlarm
	@ManyToOne
	@JoinColumn(name="ID_TYPE_CATEGORY")
	private TypeCategoryAlarm typeCategoryAlarm;

	//bi-directional many-to-one association to UserAlarm
	@OneToMany(mappedBy="typeAlarm")
	private List<UserAlarm> userAlarms;

	public TypeAlarm() {
	}

	public long getIdTypeAlarmPk() {
		return this.idTypeAlarmPk;
	}

	public void setIdTypeAlarmPk(long idTypeAlarmPk) {
		this.idTypeAlarmPk = idTypeAlarmPk;
	}

	public String getCdTypeAlarm() {
		return this.cdTypeAlarm;
	}

	public void setCdTypeAlarm(String cdTypeAlarm) {
		this.cdTypeAlarm = cdTypeAlarm;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getFileLogo() {
		return this.fileLogo;
	}

	public void setFileLogo(String fileLogo) {
		this.fileLogo = fileLogo;
	}

	public BigDecimal getIsComunicationMail() {
		return this.isComunicationMail;
	}

	public void setIsComunicationMail(BigDecimal isComunicationMail) {
		this.isComunicationMail = isComunicationMail;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtTypeAlarm() {
		return this.txtTypeAlarm;
	}

	public void setTxtTypeAlarm(String txtTypeAlarm) {
		this.txtTypeAlarm = txtTypeAlarm;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public TypeCategoryAlarm getTypeCategoryAlarm() {
		return this.typeCategoryAlarm;
	}

	public void setTypeCategoryAlarm(TypeCategoryAlarm typeCategoryAlarm) {
		this.typeCategoryAlarm = typeCategoryAlarm;
	}

	public List<UserAlarm> getUserAlarms() {
		return this.userAlarms;
	}

	public void setUserAlarms(List<UserAlarm> userAlarms) {
		this.userAlarms = userAlarms;
	}

	public UserAlarm addUserAlarm(UserAlarm userAlarm) {
		getUserAlarms().add(userAlarm);
		userAlarm.setTypeAlarm(this);

		return userAlarm;
	}

	public UserAlarm removeUserAlarm(UserAlarm userAlarm) {
		getUserAlarms().remove(userAlarm);
		userAlarm.setTypeAlarm(null);

		return userAlarm;
	}

}