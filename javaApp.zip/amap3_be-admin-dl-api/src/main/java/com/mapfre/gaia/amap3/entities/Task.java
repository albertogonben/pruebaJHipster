package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TASK database table.
 * 
 */
@Entity
@NamedQuery(name="Task.findAll", query="SELECT t FROM Task t")
public class Task implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TASK_IDTASKPK_GENERATOR", sequenceName="TASK_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TASK_IDTASKPK_GENERATOR")
	@Column(name="ID_TASK_PK")
	private long idTaskPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXTO_DESCRIPTION")
	private String txtoDescription;

	@Column(name="TXTO_JOB")
	private String txtoJob;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to GuideJob
	@ManyToOne
	@JoinColumn(name="ID_NODE_FK")
	private GuideJob guideJob;

	//bi-directional many-to-one association to TypeStateNode
	@ManyToOne
	@JoinColumn(name="ID_STATE_NODE_FK")
	private TypeStateNode typeStateNode;

	//bi-directional many-to-one association to UserAmap
	@ManyToOne
	@JoinColumn(name="ID_AUDITOR_FK")
	private UserAmap userAmap1;

	//bi-directional many-to-one association to UserAmap
	@ManyToOne
	@JoinColumn(name="ID_RESPONSIBLE_FK")
	private UserAmap userAmap2;

	//bi-directional many-to-one association to TaskDocument
	@OneToMany(mappedBy="task")
	private List<TaskDocument> taskDocuments;

	public Task() {
	}

	public long getIdTaskPk() {
		return this.idTaskPk;
	}

	public void setIdTaskPk(long idTaskPk) {
		this.idTaskPk = idTaskPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtoDescription() {
		return this.txtoDescription;
	}

	public void setTxtoDescription(String txtoDescription) {
		this.txtoDescription = txtoDescription;
	}

	public String getTxtoJob() {
		return this.txtoJob;
	}

	public void setTxtoJob(String txtoJob) {
		this.txtoJob = txtoJob;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public GuideJob getGuideJob() {
		return this.guideJob;
	}

	public void setGuideJob(GuideJob guideJob) {
		this.guideJob = guideJob;
	}

	public TypeStateNode getTypeStateNode() {
		return this.typeStateNode;
	}

	public void setTypeStateNode(TypeStateNode typeStateNode) {
		this.typeStateNode = typeStateNode;
	}

	public UserAmap getUserAmap1() {
		return this.userAmap1;
	}

	public void setUserAmap1(UserAmap userAmap1) {
		this.userAmap1 = userAmap1;
	}

	public UserAmap getUserAmap2() {
		return this.userAmap2;
	}

	public void setUserAmap2(UserAmap userAmap2) {
		this.userAmap2 = userAmap2;
	}

	public List<TaskDocument> getTaskDocuments() {
		return this.taskDocuments;
	}

	public void setTaskDocuments(List<TaskDocument> taskDocuments) {
		this.taskDocuments = taskDocuments;
	}

	public TaskDocument addTaskDocument(TaskDocument taskDocument) {
		getTaskDocuments().add(taskDocument);
		taskDocument.setTask(this);

		return taskDocument;
	}

	public TaskDocument removeTaskDocument(TaskDocument taskDocument) {
		getTaskDocuments().remove(taskDocument);
		taskDocument.setTask(null);

		return taskDocument;
	}

}