package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the ORIGIN database table.
 * 
 */
@Entity
@NamedQuery(name="Origin.findAll", query="SELECT o FROM Origin o")
public class Origin implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ORIGIN_IDORIGINPK_GENERATOR", sequenceName="ORIGIN_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ORIGIN_IDORIGINPK_GENERATOR")
	@Column(name="ID_ORIGIN_PK")
	private long idOriginPk;

	@Column(name="CD_ORIGIN")
	private String cdOrigin;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private String mrkActive;

	@Column(name="TXT_ORIGIN")
	private String txtOrigin;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to JobOrigin
	@OneToMany(mappedBy="origin")
	private List<JobOrigin> jobOrigins;

	public Origin() {
	}

	public long getIdOriginPk() {
		return this.idOriginPk;
	}

	public void setIdOriginPk(long idOriginPk) {
		this.idOriginPk = idOriginPk;
	}

	public String getCdOrigin() {
		return this.cdOrigin;
	}

	public void setCdOrigin(String cdOrigin) {
		this.cdOrigin = cdOrigin;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(String mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtOrigin() {
		return this.txtOrigin;
	}

	public void setTxtOrigin(String txtOrigin) {
		this.txtOrigin = txtOrigin;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<JobOrigin> getJobOrigins() {
		return this.jobOrigins;
	}

	public void setJobOrigins(List<JobOrigin> jobOrigins) {
		this.jobOrigins = jobOrigins;
	}

	public JobOrigin addJobOrigin(JobOrigin jobOrigin) {
		getJobOrigins().add(jobOrigin);
		jobOrigin.setOrigin(this);

		return jobOrigin;
	}

	public JobOrigin removeJobOrigin(JobOrigin jobOrigin) {
		getJobOrigins().remove(jobOrigin);
		jobOrigin.setOrigin(null);

		return jobOrigin;
	}

}