package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the ORGANIZATIONAL_STRUCTURE database table.
 * 
 */
@Entity
@Table(name="ORGANIZATIONAL_STRUCTURE")
@NamedQuery(name="OrganizationalStructure.findAll", query="SELECT o FROM OrganizationalStructure o")
public class OrganizationalStructure implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ORGANIZATIONAL_STRUCTURE_IDORGANIZATIONALSTRUCTUREPK_GENERATOR", sequenceName="ORGANIZATIONAL_STRUCTURE_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ORGANIZATIONAL_STRUCTURE_IDORGANIZATIONALSTRUCTUREPK_GENERATOR")
	@Column(name="ID_ORGANIZATIONAL_STRUCTURE_PK")
	private long idOrganizationalStructurePk;

	@Column(name="CD_ORGANIZATIONAL_STRUCTURE")
	private String cdOrganizationalStructure;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private String mrkActive;

	@Column(name="NMR_DAYS_LAB")
	private BigDecimal nmrDaysLab;

	@Column(name="NMR_HOURS_LAB")
	private BigDecimal nmrHoursLab;

	@Column(name="TXT_ABBREVIATION")
	private String txtAbbreviation;

	@Column(name="TXT_DESCRIPTION")
	private String txtDescription;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Budget
	@OneToMany(mappedBy="organizationalStructure")
	private List<Budget> budgets;

	//bi-directional many-to-one association to Country
	@OneToMany(mappedBy="organizationalStructure")
	private List<Country> countries;

	//bi-directional many-to-one association to Entamap
	@OneToMany(mappedBy="organizationalStructure")
	private List<Entamap> entamaps;

	//bi-directional many-to-one association to Idea
	@OneToMany(mappedBy="organizationalStructure")
	private List<Idea> ideas;

	//bi-directional many-to-one association to Currency
	@ManyToOne
	@JoinColumn(name="ID_CURRENCY_FK")
	private Currency currency;

	//bi-directional many-to-one association to OrganizationalStructure
	@ManyToOne
	@JoinColumn(name="ID_FATHER_FK")
	private OrganizationalStructure organizationalStructure;

	//bi-directional many-to-one association to OrganizationalStructure
	@OneToMany(mappedBy="organizationalStructure")
	private List<OrganizationalStructure> organizationalStructures;

	//bi-directional many-to-one association to TypeOrganizationalStructure
	@ManyToOne
	@JoinColumn(name="ID_TYPE_ORGANIZATIONAL_STRUCTURE_FK")
	private TypeOrganizationalStructure typeOrganizationalStructure;

	//bi-directional many-to-one association to Pai
	@OneToMany(mappedBy="organizationalStructure")
	private List<Pai> pais;

	//bi-directional many-to-one association to PredictionPersonnel
	@OneToMany(mappedBy="organizationalStructure")
	private List<PredictionPersonnel> predictionPersonnels;

	//bi-directional many-to-one association to UserAmap
	@OneToMany(mappedBy="organizationalStructure")
	private List<UserAmap> userAmaps;

	//bi-directional many-to-one association to UserCategory
	@OneToMany(mappedBy="organizationalStructure")
	private List<UserCategory> userCategories;

	public OrganizationalStructure() {
	}

	public long getIdOrganizationalStructurePk() {
		return this.idOrganizationalStructurePk;
	}

	public void setIdOrganizationalStructurePk(long idOrganizationalStructurePk) {
		this.idOrganizationalStructurePk = idOrganizationalStructurePk;
	}

	public String getCdOrganizationalStructure() {
		return this.cdOrganizationalStructure;
	}

	public void setCdOrganizationalStructure(String cdOrganizationalStructure) {
		this.cdOrganizationalStructure = cdOrganizationalStructure;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(String mrkActive) {
		this.mrkActive = mrkActive;
	}

	public BigDecimal getNmrDaysLab() {
		return this.nmrDaysLab;
	}

	public void setNmrDaysLab(BigDecimal nmrDaysLab) {
		this.nmrDaysLab = nmrDaysLab;
	}

	public BigDecimal getNmrHoursLab() {
		return this.nmrHoursLab;
	}

	public void setNmrHoursLab(BigDecimal nmrHoursLab) {
		this.nmrHoursLab = nmrHoursLab;
	}

	public String getTxtAbbreviation() {
		return this.txtAbbreviation;
	}

	public void setTxtAbbreviation(String txtAbbreviation) {
		this.txtAbbreviation = txtAbbreviation;
	}

	public String getTxtDescription() {
		return this.txtDescription;
	}

	public void setTxtDescription(String txtDescription) {
		this.txtDescription = txtDescription;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<Budget> getBudgets() {
		return this.budgets;
	}

	public void setBudgets(List<Budget> budgets) {
		this.budgets = budgets;
	}

	public Budget addBudget(Budget budget) {
		getBudgets().add(budget);
		budget.setOrganizationalStructure(this);

		return budget;
	}

	public Budget removeBudget(Budget budget) {
		getBudgets().remove(budget);
		budget.setOrganizationalStructure(null);

		return budget;
	}

	public List<Country> getCountries() {
		return this.countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}

	public Country addCountry(Country country) {
		getCountries().add(country);
		country.setOrganizationalStructure(this);

		return country;
	}

	public Country removeCountry(Country country) {
		getCountries().remove(country);
		country.setOrganizationalStructure(null);

		return country;
	}

	public List<Entamap> getEntamaps() {
		return this.entamaps;
	}

	public void setEntamaps(List<Entamap> entamaps) {
		this.entamaps = entamaps;
	}

	public Entamap addEntamap(Entamap entamap) {
		getEntamaps().add(entamap);
		entamap.setOrganizationalStructure(this);

		return entamap;
	}

	public Entamap removeEntamap(Entamap entamap) {
		getEntamaps().remove(entamap);
		entamap.setOrganizationalStructure(null);

		return entamap;
	}

	public List<Idea> getIdeas() {
		return this.ideas;
	}

	public void setIdeas(List<Idea> ideas) {
		this.ideas = ideas;
	}

	public Idea addIdea(Idea idea) {
		getIdeas().add(idea);
		idea.setOrganizationalStructure(this);

		return idea;
	}

	public Idea removeIdea(Idea idea) {
		getIdeas().remove(idea);
		idea.setOrganizationalStructure(null);

		return idea;
	}

	public Currency getCurrency() {
		return this.currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public OrganizationalStructure getOrganizationalStructure() {
		return this.organizationalStructure;
	}

	public void setOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		this.organizationalStructure = organizationalStructure;
	}

	public List<OrganizationalStructure> getOrganizationalStructures() {
		return this.organizationalStructures;
	}

	public void setOrganizationalStructures(List<OrganizationalStructure> organizationalStructures) {
		this.organizationalStructures = organizationalStructures;
	}

	public OrganizationalStructure addOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		getOrganizationalStructures().add(organizationalStructure);
		organizationalStructure.setOrganizationalStructure(this);

		return organizationalStructure;
	}

	public OrganizationalStructure removeOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		getOrganizationalStructures().remove(organizationalStructure);
		organizationalStructure.setOrganizationalStructure(null);

		return organizationalStructure;
	}

	public TypeOrganizationalStructure getTypeOrganizationalStructure() {
		return this.typeOrganizationalStructure;
	}

	public void setTypeOrganizationalStructure(TypeOrganizationalStructure typeOrganizationalStructure) {
		this.typeOrganizationalStructure = typeOrganizationalStructure;
	}

	public List<Pai> getPais() {
		return this.pais;
	}

	public void setPais(List<Pai> pais) {
		this.pais = pais;
	}

	public Pai addPai(Pai pai) {
		getPais().add(pai);
		pai.setOrganizationalStructure(this);

		return pai;
	}

	public Pai removePai(Pai pai) {
		getPais().remove(pai);
		pai.setOrganizationalStructure(null);

		return pai;
	}

	public List<PredictionPersonnel> getPredictionPersonnels() {
		return this.predictionPersonnels;
	}

	public void setPredictionPersonnels(List<PredictionPersonnel> predictionPersonnels) {
		this.predictionPersonnels = predictionPersonnels;
	}

	public PredictionPersonnel addPredictionPersonnel(PredictionPersonnel predictionPersonnel) {
		getPredictionPersonnels().add(predictionPersonnel);
		predictionPersonnel.setOrganizationalStructure(this);

		return predictionPersonnel;
	}

	public PredictionPersonnel removePredictionPersonnel(PredictionPersonnel predictionPersonnel) {
		getPredictionPersonnels().remove(predictionPersonnel);
		predictionPersonnel.setOrganizationalStructure(null);

		return predictionPersonnel;
	}

	public List<UserAmap> getUserAmaps() {
		return this.userAmaps;
	}

	public void setUserAmaps(List<UserAmap> userAmaps) {
		this.userAmaps = userAmaps;
	}

	public UserAmap addUserAmap(UserAmap userAmap) {
		getUserAmaps().add(userAmap);
		userAmap.setOrganizationalStructure(this);

		return userAmap;
	}

	public UserAmap removeUserAmap(UserAmap userAmap) {
		getUserAmaps().remove(userAmap);
		userAmap.setOrganizationalStructure(null);

		return userAmap;
	}

	public List<UserCategory> getUserCategories() {
		return this.userCategories;
	}

	public void setUserCategories(List<UserCategory> userCategories) {
		this.userCategories = userCategories;
	}

	public UserCategory addUserCategory(UserCategory userCategory) {
		getUserCategories().add(userCategory);
		userCategory.setOrganizationalStructure(this);

		return userCategory;
	}

	public UserCategory removeUserCategory(UserCategory userCategory) {
		getUserCategories().remove(userCategory);
		userCategory.setOrganizationalStructure(null);

		return userCategory;
	}

}