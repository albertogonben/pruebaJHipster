package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the "LANGUAGE" database table.
 * 
 */
@Entity
@Table(name="LANGUAGE")
@NamedQuery(name="Language.findAll", query="SELECT l FROM Language l")
public class Language implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="LANGUAGE_IDLANGUAGEPK_GENERATOR", sequenceName="LANGUAGE_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="LANGUAGE_IDLANGUAGEPK_GENERATOR")
	@Column(name="ID_LANGUAGE_PK")
	private long idLanguagePk;

	@Column(name="CD_LANGUAGE")
	private String cdLanguage;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="MRK_POSSIBLE_TRANSLATION")
	private BigDecimal mrkPossibleTranslation;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to UserAmap
	@OneToMany(mappedBy="language")
	private List<UserAmap> userAmaps;

	//bi-directional many-to-one association to UserLanguage
	@OneToMany(mappedBy="language")
	private List<UserLanguage> userLanguages;

	public Language() {
	}

	public long getIdLanguagePk() {
		return this.idLanguagePk;
	}

	public void setIdLanguagePk(long idLanguagePk) {
		this.idLanguagePk = idLanguagePk;
	}

	public String getCdLanguage() {
		return this.cdLanguage;
	}

	public void setCdLanguage(String cdLanguage) {
		this.cdLanguage = cdLanguage;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public BigDecimal getMrkPossibleTranslation() {
		return this.mrkPossibleTranslation;
	}

	public void setMrkPossibleTranslation(BigDecimal mrkPossibleTranslation) {
		this.mrkPossibleTranslation = mrkPossibleTranslation;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<UserAmap> getUserAmaps() {
		return this.userAmaps;
	}

	public void setUserAmaps(List<UserAmap> userAmaps) {
		this.userAmaps = userAmaps;
	}

	public UserAmap addUserAmap(UserAmap userAmap) {
		getUserAmaps().add(userAmap);
		userAmap.setLanguage(this);

		return userAmap;
	}

	public UserAmap removeUserAmap(UserAmap userAmap) {
		getUserAmaps().remove(userAmap);
		userAmap.setLanguage(null);

		return userAmap;
	}

	public List<UserLanguage> getUserLanguages() {
		return this.userLanguages;
	}

	public void setUserLanguages(List<UserLanguage> userLanguages) {
		this.userLanguages = userLanguages;
	}

	public UserLanguage addUserLanguage(UserLanguage userLanguage) {
		getUserLanguages().add(userLanguage);
		userLanguage.setLanguage(this);

		return userLanguage;
	}

	public UserLanguage removeUserLanguage(UserLanguage userLanguage) {
		getUserLanguages().remove(userLanguage);
		userLanguage.setLanguage(null);

		return userLanguage;
	}

}