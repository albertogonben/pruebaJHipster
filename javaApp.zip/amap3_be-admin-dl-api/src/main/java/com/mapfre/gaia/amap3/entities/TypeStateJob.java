package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_STATE_JOB database table.
 * 
 */
@Entity
@Table(name="TYPE_STATE_JOB")
@NamedQuery(name="TypeStateJob.findAll", query="SELECT t FROM TypeStateJob t")
public class TypeStateJob implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_STATE_JOB_IDTYPESTATEPK_GENERATOR", sequenceName="TYPE_STATE_JOB_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_STATE_JOB_IDTYPESTATEPK_GENERATOR")
	@Column(name="ID_TYPE_STATE_PK")
	private long idTypeStatePk;

	@Column(name="CD_TYPE_STATE")
	private String cdTypeState;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Job
	@OneToMany(mappedBy="typeStateJob")
	private List<Job> jobs;

	public TypeStateJob() {
	}

	public long getIdTypeStatePk() {
		return this.idTypeStatePk;
	}

	public void setIdTypeStatePk(long idTypeStatePk) {
		this.idTypeStatePk = idTypeStatePk;
	}

	public String getCdTypeState() {
		return this.cdTypeState;
	}

	public void setCdTypeState(String cdTypeState) {
		this.cdTypeState = cdTypeState;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

	public Job addJob(Job job) {
		getJobs().add(job);
		job.setTypeStateJob(this);

		return job;
	}

	public Job removeJob(Job job) {
		getJobs().remove(job);
		job.setTypeStateJob(null);

		return job;
	}

}