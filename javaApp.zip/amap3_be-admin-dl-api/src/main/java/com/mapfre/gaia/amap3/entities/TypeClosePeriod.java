package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the TYPE_CLOSE_PERIOD database table.
 * 
 */
@Entity
@Table(name="TYPE_CLOSE_PERIOD")
@NamedQuery(name="TypeClosePeriod.findAll", query="SELECT t FROM TypeClosePeriod t")
public class TypeClosePeriod implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_CLOSE_PERIOD_IDTYPECLOSEPERIODPK_GENERATOR", sequenceName="TYPE_CLOSE_PERIOD_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_CLOSE_PERIOD_IDTYPECLOSEPERIODPK_GENERATOR")
	@Column(name="ID_TYPE_CLOSE_PERIOD_PK")
	private long idTypeClosePeriodPk;

	@Column(name="CD_TYPE_CLOSE_PERIOD")
	private String cdTypeClosePeriod;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_TYPE_CLOSE_PERIOD")
	private String txtTypeClosePeriod;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public TypeClosePeriod() {
	}

	public long getIdTypeClosePeriodPk() {
		return this.idTypeClosePeriodPk;
	}

	public void setIdTypeClosePeriodPk(long idTypeClosePeriodPk) {
		this.idTypeClosePeriodPk = idTypeClosePeriodPk;
	}

	public String getCdTypeClosePeriod() {
		return this.cdTypeClosePeriod;
	}

	public void setCdTypeClosePeriod(String cdTypeClosePeriod) {
		this.cdTypeClosePeriod = cdTypeClosePeriod;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtTypeClosePeriod() {
		return this.txtTypeClosePeriod;
	}

	public void setTxtTypeClosePeriod(String txtTypeClosePeriod) {
		this.txtTypeClosePeriod = txtTypeClosePeriod;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}