package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the BUDGET database table.
 * 
 */
@Entity
@NamedQuery(name="Budget.findAll", query="SELECT b FROM Budget b")
public class Budget implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="BUDGET_IDBUDGETPK_GENERATOR", sequenceName="BUDGET_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BUDGET_IDBUDGETPK_GENERATOR")
	@Column(name="ID_BUDGET_PK")
	private long idBudgetPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_FINISH")
	private Date dateFinish;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_START")
	private Date dateStart;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_VALITACION")
	private Date dateValitacion;

	@Column(name="NMR_EXERCIESE")
	private BigDecimal nmrExerciese;

	@Column(name="TXT_COMMENTS")
	private String txtComments;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="TXTO_NAME_STANDARD")
	private String txtoNameStandard;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Currency
	@ManyToOne
	@JoinColumn(name="ID_CURRENCY_FK")
	private Currency currency;

	//bi-directional many-to-one association to OrganizationalStructure
	@ManyToOne
	@JoinColumn(name="ID_ORGANIZATIONAL_STRUCTURE_FK")
	private OrganizationalStructure organizationalStructure;

	//bi-directional many-to-one association to TypeStatusBudget
	@ManyToOne
	@JoinColumn(name="ID_STATUS_BUDGET_FK")
	private TypeStatusBudget typeStatusBudget;

	//bi-directional many-to-one association to UserAmap
	@ManyToOne
	@JoinColumn(name="ID_USER_CREATOR_FK")
	private UserAmap userAmap1;

	//bi-directional many-to-one association to UserAmap
	@ManyToOne
	@JoinColumn(name="ID_USER_APPROVED_FK")
	private UserAmap userAmap2;

	//bi-directional many-to-one association to Pai
	@OneToMany(mappedBy="budget")
	private List<Pai> pais;

	public Budget() {
	}

	public long getIdBudgetPk() {
		return this.idBudgetPk;
	}

	public void setIdBudgetPk(long idBudgetPk) {
		this.idBudgetPk = idBudgetPk;
	}

	public Date getDateFinish() {
		return this.dateFinish;
	}

	public void setDateFinish(Date dateFinish) {
		this.dateFinish = dateFinish;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateStart() {
		return this.dateStart;
	}

	public void setDateStart(Date dateStart) {
		this.dateStart = dateStart;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getDateValitacion() {
		return this.dateValitacion;
	}

	public void setDateValitacion(Date dateValitacion) {
		this.dateValitacion = dateValitacion;
	}

	public BigDecimal getNmrExerciese() {
		return this.nmrExerciese;
	}

	public void setNmrExerciese(BigDecimal nmrExerciese) {
		this.nmrExerciese = nmrExerciese;
	}

	public String getTxtComments() {
		return this.txtComments;
	}

	public void setTxtComments(String txtComments) {
		this.txtComments = txtComments;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getTxtoNameStandard() {
		return this.txtoNameStandard;
	}

	public void setTxtoNameStandard(String txtoNameStandard) {
		this.txtoNameStandard = txtoNameStandard;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Currency getCurrency() {
		return this.currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public OrganizationalStructure getOrganizationalStructure() {
		return this.organizationalStructure;
	}

	public void setOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		this.organizationalStructure = organizationalStructure;
	}

	public TypeStatusBudget getTypeStatusBudget() {
		return this.typeStatusBudget;
	}

	public void setTypeStatusBudget(TypeStatusBudget typeStatusBudget) {
		this.typeStatusBudget = typeStatusBudget;
	}

	public UserAmap getUserAmap1() {
		return this.userAmap1;
	}

	public void setUserAmap1(UserAmap userAmap1) {
		this.userAmap1 = userAmap1;
	}

	public UserAmap getUserAmap2() {
		return this.userAmap2;
	}

	public void setUserAmap2(UserAmap userAmap2) {
		this.userAmap2 = userAmap2;
	}

	public List<Pai> getPais() {
		return this.pais;
	}

	public void setPais(List<Pai> pais) {
		this.pais = pais;
	}

	public Pai addPai(Pai pai) {
		getPais().add(pai);
		pai.setBudget(this);

		return pai;
	}

	public Pai removePai(Pai pai) {
		getPais().remove(pai);
		pai.setBudget(null);

		return pai;
	}

}