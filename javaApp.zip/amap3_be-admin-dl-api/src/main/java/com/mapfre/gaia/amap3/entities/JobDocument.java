package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the JOB_DOCUMENT database table.
 * 
 */
@Entity
@Table(name="JOB_DOCUMENT")
@NamedQuery(name="JobDocument.findAll", query="SELECT j FROM JobDocument j")
public class JobDocument implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="JOB_DOCUMENT_IDRELATIONPK_GENERATOR", sequenceName="JOB_DOCUMENT_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="JOB_DOCUMENT_IDRELATIONPK_GENERATOR")
	@Column(name="ID_RELATION_PK")
	private long idRelationPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Lob
	@Column(name="FILE_DOCUMENT")
	private byte[] fileDocument;

	@Column(name="NMR_SIZE")
	private BigDecimal nmrSize;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="TYPE_DOCUMENT")
	private String typeDocument;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Job
	@ManyToOne
	@JoinColumn(name="ID_JOB_FK")
	private Job job;

	public JobDocument() {
	}

	public long getIdRelationPk() {
		return this.idRelationPk;
	}

	public void setIdRelationPk(long idRelationPk) {
		this.idRelationPk = idRelationPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public byte[] getFileDocument() {
		return this.fileDocument;
	}

	public void setFileDocument(byte[] fileDocument) {
		this.fileDocument = fileDocument;
	}

	public BigDecimal getNmrSize() {
		return this.nmrSize;
	}

	public void setNmrSize(BigDecimal nmrSize) {
		this.nmrSize = nmrSize;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getTypeDocument() {
		return this.typeDocument;
	}

	public void setTypeDocument(String typeDocument) {
		this.typeDocument = typeDocument;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Job getJob() {
		return this.job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

}