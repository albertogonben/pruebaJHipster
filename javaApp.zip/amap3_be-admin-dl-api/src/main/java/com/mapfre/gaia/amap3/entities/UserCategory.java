package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the USER_CATEGORY database table.
 * 
 */
@Entity
@Table(name="USER_CATEGORY")
@NamedQuery(name="UserCategory.findAll", query="SELECT u FROM UserCategory u")
public class UserCategory implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="USER_CATEGORY_IDCATEGORYUSERPK_GENERATOR", sequenceName="USER_CATEGORY_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_CATEGORY_IDCATEGORYUSERPK_GENERATOR")
	@Column(name="ID_CATEGORY_USER_PK")
	private long idCategoryUserPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_FINISH")
	private Date dateFinish;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_START")
	private Date dateStart;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to OrganizationalStructure
	@ManyToOne
	@JoinColumn(name="ID_ORGANIZATIONAL_STRUCTURE_FK")
	private OrganizationalStructure organizationalStructure;

	//bi-directional many-to-one association to TypeCategoryProfessional
	@ManyToOne
	@JoinColumn(name="ID_CATEGORY_FK")
	private TypeCategoryProfessional typeCategoryProfessional;

	//bi-directional many-to-one association to TypeReasonChangeCategory
	@ManyToOne
	@JoinColumn(name="ID_OTHER_MOTIVE_FK")
	private TypeReasonChangeCategory typeReasonChangeCategory;

	//bi-directional many-to-one association to UserAmap
	@ManyToOne
	@JoinColumn(name="ID_USER_FK")
	private UserAmap userAmap;

	public UserCategory() {
	}

	public long getIdCategoryUserPk() {
		return this.idCategoryUserPk;
	}

	public void setIdCategoryUserPk(long idCategoryUserPk) {
		this.idCategoryUserPk = idCategoryUserPk;
	}

	public Date getDateFinish() {
		return this.dateFinish;
	}

	public void setDateFinish(Date dateFinish) {
		this.dateFinish = dateFinish;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateStart() {
		return this.dateStart;
	}

	public void setDateStart(Date dateStart) {
		this.dateStart = dateStart;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public OrganizationalStructure getOrganizationalStructure() {
		return this.organizationalStructure;
	}

	public void setOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		this.organizationalStructure = organizationalStructure;
	}

	public TypeCategoryProfessional getTypeCategoryProfessional() {
		return this.typeCategoryProfessional;
	}

	public void setTypeCategoryProfessional(TypeCategoryProfessional typeCategoryProfessional) {
		this.typeCategoryProfessional = typeCategoryProfessional;
	}

	public TypeReasonChangeCategory getTypeReasonChangeCategory() {
		return this.typeReasonChangeCategory;
	}

	public void setTypeReasonChangeCategory(TypeReasonChangeCategory typeReasonChangeCategory) {
		this.typeReasonChangeCategory = typeReasonChangeCategory;
	}

	public UserAmap getUserAmap() {
		return this.userAmap;
	}

	public void setUserAmap(UserAmap userAmap) {
		this.userAmap = userAmap;
	}

}