package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the TYPE_SPECIALITY database table.
 * 
 */
@Entity
@Table(name="TYPE_SPECIALITY")
@NamedQuery(name="TypeSpeciality.findAll", query="SELECT t FROM TypeSpeciality t")
public class TypeSpeciality implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_SPECIALITY_IDTYPESPECIALITYPK_GENERATOR", sequenceName="TYPE_SPECIALITY_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_SPECIALITY_IDTYPESPECIALITYPK_GENERATOR")
	@Column(name="ID_TYPE_SPECIALITY_PK")
	private long idTypeSpecialityPk;

	@Column(name="CD_TYPE_SPECIALITY")
	private String cdTypeSpeciality;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private String mrkActive;

	@Column(name="TXT_TYPE_SPECIALITY")
	private String txtTypeSpeciality;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public TypeSpeciality() {
	}

	public long getIdTypeSpecialityPk() {
		return this.idTypeSpecialityPk;
	}

	public void setIdTypeSpecialityPk(long idTypeSpecialityPk) {
		this.idTypeSpecialityPk = idTypeSpecialityPk;
	}

	public String getCdTypeSpeciality() {
		return this.cdTypeSpeciality;
	}

	public void setCdTypeSpeciality(String cdTypeSpeciality) {
		this.cdTypeSpeciality = cdTypeSpeciality;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(String mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtTypeSpeciality() {
		return this.txtTypeSpeciality;
	}

	public void setTxtTypeSpeciality(String txtTypeSpeciality) {
		this.txtTypeSpeciality = txtTypeSpeciality;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}