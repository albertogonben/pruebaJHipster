package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the USER_AMAP database table.
 * 
 */
@Entity
@Table(name="USER_AMAP")
@NamedQuery(name="UserAmap.findAll", query="SELECT u FROM UserAmap u")
public class UserAmap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="USER_AMAP_IDUSERPK_GENERATOR", sequenceName="USER_AMAP_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_AMAP_IDUSERPK_GENERATOR")
	@Column(name="ID_USER_PK")
	private long idUserPk;

	@Column(name="CD_NUUMA")
	private BigDecimal cdNuuma;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_ADMISSION")
	private Date dateAdmission;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OFF_SICK")
	private Date dateOffSick;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Lob
	@Column(name="FILE_CV_EN")
	private byte[] fileCvEn;

	@Lob
	@Column(name="FILE_CV_ES")
	private byte[] fileCvEs;

	@Lob
	@Column(name="FILE_FIRM")
	private byte[] fileFirm;

	@Lob
	@Column(name="FILE_PHOTO")
	private byte[] filePhoto;

	@Column(name="IS_MOBILITY_FUNCTIONAL")
	private BigDecimal isMobilityFunctional;

	@Column(name="IS_MOBILITY_GEOGRAPHIC")
	private BigDecimal isMobilityGeographic;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="NMR_LABORAL_HOURS")
	private BigDecimal nmrLaboralHours;

	@Column(name="NMR_MOBILE")
	private BigDecimal nmrMobile;

	@Column(name="TXT_COMMENT")
	private String txtComment;

	@Column(name="TXT_EXPERIENCE")
	private String txtExperience;

	@Column(name="TXT_LASTNAME_1")
	private String txtLastname1;

	@Column(name="TXT_LASTNAME_2")
	private String txtLastname2;

	@Column(name="TXT_MAIL")
	private String txtMail;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="TYPE_TREATMENT")
	private String typeTreatment;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Budget
	@OneToMany(mappedBy="userAmap1")
	private List<Budget> budgets1;

	//bi-directional many-to-one association to Budget
	@OneToMany(mappedBy="userAmap2")
	private List<Budget> budgets2;

	//bi-directional many-to-one association to Task
	@OneToMany(mappedBy="userAmap1")
	private List<Task> tasks1;

	//bi-directional many-to-one association to Task
	@OneToMany(mappedBy="userAmap2")
	private List<Task> tasks2;

	//bi-directional many-to-one association to UserAlarm
	@OneToMany(mappedBy="userAmap")
	private List<UserAlarm> userAlarms;

	//bi-directional many-to-one association to Department
	@ManyToOne
	@JoinColumn(name="ID_DEPARTMENT_FK")
	private Department department;

	//bi-directional many-to-one association to Entamap
	@ManyToOne
	@JoinColumn(name="ID_ENTITY_FK")
	private Entamap entamap;

	//bi-directional many-to-one association to Language
	@ManyToOne
	@JoinColumn(name="ID_TYPE_LANGUAGE_FK")
	private Language language;

	//bi-directional many-to-one association to OrganizationalStructure
	@ManyToOne
	@JoinColumn(name="ID_ORGANIZATIONAL_STRUCTURE_FK")
	private OrganizationalStructure organizationalStructure;

	//bi-directional many-to-one association to TypeRole
	@ManyToOne
	@JoinColumn(name="ID_TYPE_USER_FK")
	private TypeRole typeRole;

	//bi-directional many-to-one association to UserCategory
	@OneToMany(mappedBy="userAmap")
	private List<UserCategory> userCategories;

	//bi-directional many-to-one association to UserLanguage
	@OneToMany(mappedBy="userAmap")
	private List<UserLanguage> userLanguages;

	//bi-directional many-to-one association to UserTraining
	@OneToMany(mappedBy="userAmap")
	private List<UserTraining> userTrainings;

	public UserAmap() {
	}

	public long getIdUserPk() {
		return this.idUserPk;
	}

	public void setIdUserPk(long idUserPk) {
		this.idUserPk = idUserPk;
	}

	public BigDecimal getCdNuuma() {
		return this.cdNuuma;
	}

	public void setCdNuuma(BigDecimal cdNuuma) {
		this.cdNuuma = cdNuuma;
	}

	public Date getDateAdmission() {
		return this.dateAdmission;
	}

	public void setDateAdmission(Date dateAdmission) {
		this.dateAdmission = dateAdmission;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateOffSick() {
		return this.dateOffSick;
	}

	public void setDateOffSick(Date dateOffSick) {
		this.dateOffSick = dateOffSick;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public byte[] getFileCvEn() {
		return this.fileCvEn;
	}

	public void setFileCvEn(byte[] fileCvEn) {
		this.fileCvEn = fileCvEn;
	}

	public byte[] getFileCvEs() {
		return this.fileCvEs;
	}

	public void setFileCvEs(byte[] fileCvEs) {
		this.fileCvEs = fileCvEs;
	}

	public byte[] getFileFirm() {
		return this.fileFirm;
	}

	public void setFileFirm(byte[] fileFirm) {
		this.fileFirm = fileFirm;
	}

	public byte[] getFilePhoto() {
		return this.filePhoto;
	}

	public void setFilePhoto(byte[] filePhoto) {
		this.filePhoto = filePhoto;
	}

	public BigDecimal getIsMobilityFunctional() {
		return this.isMobilityFunctional;
	}

	public void setIsMobilityFunctional(BigDecimal isMobilityFunctional) {
		this.isMobilityFunctional = isMobilityFunctional;
	}

	public BigDecimal getIsMobilityGeographic() {
		return this.isMobilityGeographic;
	}

	public void setIsMobilityGeographic(BigDecimal isMobilityGeographic) {
		this.isMobilityGeographic = isMobilityGeographic;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public BigDecimal getNmrLaboralHours() {
		return this.nmrLaboralHours;
	}

	public void setNmrLaboralHours(BigDecimal nmrLaboralHours) {
		this.nmrLaboralHours = nmrLaboralHours;
	}

	public BigDecimal getNmrMobile() {
		return this.nmrMobile;
	}

	public void setNmrMobile(BigDecimal nmrMobile) {
		this.nmrMobile = nmrMobile;
	}

	public String getTxtComment() {
		return this.txtComment;
	}

	public void setTxtComment(String txtComment) {
		this.txtComment = txtComment;
	}

	public String getTxtExperience() {
		return this.txtExperience;
	}

	public void setTxtExperience(String txtExperience) {
		this.txtExperience = txtExperience;
	}

	public String getTxtLastname1() {
		return this.txtLastname1;
	}

	public void setTxtLastname1(String txtLastname1) {
		this.txtLastname1 = txtLastname1;
	}

	public String getTxtLastname2() {
		return this.txtLastname2;
	}

	public void setTxtLastname2(String txtLastname2) {
		this.txtLastname2 = txtLastname2;
	}

	public String getTxtMail() {
		return this.txtMail;
	}

	public void setTxtMail(String txtMail) {
		this.txtMail = txtMail;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getTypeTreatment() {
		return this.typeTreatment;
	}

	public void setTypeTreatment(String typeTreatment) {
		this.typeTreatment = typeTreatment;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<Budget> getBudgets1() {
		return this.budgets1;
	}

	public void setBudgets1(List<Budget> budgets1) {
		this.budgets1 = budgets1;
	}

	public Budget addBudgets1(Budget budgets1) {
		getBudgets1().add(budgets1);
		budgets1.setUserAmap1(this);

		return budgets1;
	}

	public Budget removeBudgets1(Budget budgets1) {
		getBudgets1().remove(budgets1);
		budgets1.setUserAmap1(null);

		return budgets1;
	}

	public List<Budget> getBudgets2() {
		return this.budgets2;
	}

	public void setBudgets2(List<Budget> budgets2) {
		this.budgets2 = budgets2;
	}

	public Budget addBudgets2(Budget budgets2) {
		getBudgets2().add(budgets2);
		budgets2.setUserAmap2(this);

		return budgets2;
	}

	public Budget removeBudgets2(Budget budgets2) {
		getBudgets2().remove(budgets2);
		budgets2.setUserAmap2(null);

		return budgets2;
	}

	public List<Task> getTasks1() {
		return this.tasks1;
	}

	public void setTasks1(List<Task> tasks1) {
		this.tasks1 = tasks1;
	}

	public Task addTasks1(Task tasks1) {
		getTasks1().add(tasks1);
		tasks1.setUserAmap1(this);

		return tasks1;
	}

	public Task removeTasks1(Task tasks1) {
		getTasks1().remove(tasks1);
		tasks1.setUserAmap1(null);

		return tasks1;
	}

	public List<Task> getTasks2() {
		return this.tasks2;
	}

	public void setTasks2(List<Task> tasks2) {
		this.tasks2 = tasks2;
	}

	public Task addTasks2(Task tasks2) {
		getTasks2().add(tasks2);
		tasks2.setUserAmap2(this);

		return tasks2;
	}

	public Task removeTasks2(Task tasks2) {
		getTasks2().remove(tasks2);
		tasks2.setUserAmap2(null);

		return tasks2;
	}

	public List<UserAlarm> getUserAlarms() {
		return this.userAlarms;
	}

	public void setUserAlarms(List<UserAlarm> userAlarms) {
		this.userAlarms = userAlarms;
	}

	public UserAlarm addUserAlarm(UserAlarm userAlarm) {
		getUserAlarms().add(userAlarm);
		userAlarm.setUserAmap(this);

		return userAlarm;
	}

	public UserAlarm removeUserAlarm(UserAlarm userAlarm) {
		getUserAlarms().remove(userAlarm);
		userAlarm.setUserAmap(null);

		return userAlarm;
	}

	public Department getDepartment() {
		return this.department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Entamap getEntamap() {
		return this.entamap;
	}

	public void setEntamap(Entamap entamap) {
		this.entamap = entamap;
	}

	public Language getLanguage() {
		return this.language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}

	public OrganizationalStructure getOrganizationalStructure() {
		return this.organizationalStructure;
	}

	public void setOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		this.organizationalStructure = organizationalStructure;
	}

	public TypeRole getTypeRole() {
		return this.typeRole;
	}

	public void setTypeRole(TypeRole typeRole) {
		this.typeRole = typeRole;
	}

	public List<UserCategory> getUserCategories() {
		return this.userCategories;
	}

	public void setUserCategories(List<UserCategory> userCategories) {
		this.userCategories = userCategories;
	}

	public UserCategory addUserCategory(UserCategory userCategory) {
		getUserCategories().add(userCategory);
		userCategory.setUserAmap(this);

		return userCategory;
	}

	public UserCategory removeUserCategory(UserCategory userCategory) {
		getUserCategories().remove(userCategory);
		userCategory.setUserAmap(null);

		return userCategory;
	}

	public List<UserLanguage> getUserLanguages() {
		return this.userLanguages;
	}

	public void setUserLanguages(List<UserLanguage> userLanguages) {
		this.userLanguages = userLanguages;
	}

	public UserLanguage addUserLanguage(UserLanguage userLanguage) {
		getUserLanguages().add(userLanguage);
		userLanguage.setUserAmap(this);

		return userLanguage;
	}

	public UserLanguage removeUserLanguage(UserLanguage userLanguage) {
		getUserLanguages().remove(userLanguage);
		userLanguage.setUserAmap(null);

		return userLanguage;
	}

	public List<UserTraining> getUserTrainings() {
		return this.userTrainings;
	}

	public void setUserTrainings(List<UserTraining> userTrainings) {
		this.userTrainings = userTrainings;
	}

	public UserTraining addUserTraining(UserTraining userTraining) {
		getUserTrainings().add(userTraining);
		userTraining.setUserAmap(this);

		return userTraining;
	}

	public UserTraining removeUserTraining(UserTraining userTraining) {
		getUserTrainings().remove(userTraining);
		userTraining.setUserAmap(null);

		return userTraining;
	}

}