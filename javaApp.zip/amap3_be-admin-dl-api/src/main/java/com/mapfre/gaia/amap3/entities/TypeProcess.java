package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_PROCESS database table.
 * 
 */
@Entity
@Table(name="TYPE_PROCESS")
@NamedQuery(name="TypeProcess.findAll", query="SELECT t FROM TypeProcess t")
public class TypeProcess implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_PROCESS_IDTYPEPROCESSPK_GENERATOR", sequenceName="TYPE_PROCESS_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_PROCESS_IDTYPEPROCESSPK_GENERATOR")
	@Column(name="ID_TYPE_PROCESS_PK")
	private long idTypeProcessPk;

	@Column(name="CD_TYPE_PROCESS")
	private String cdTypeProcess;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_DESCRIPTION")
	private String txtDescription;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to ProcessCountry
	@OneToMany(mappedBy="typeProcess")
	private List<ProcessCountry> processCountries;

	//bi-directional many-to-one association to ProcessUnitBusiness
	@OneToMany(mappedBy="typeProcess")
	private List<ProcessUnitBusiness> processUnitBusinesses;

	public TypeProcess() {
	}

	public long getIdTypeProcessPk() {
		return this.idTypeProcessPk;
	}

	public void setIdTypeProcessPk(long idTypeProcessPk) {
		this.idTypeProcessPk = idTypeProcessPk;
	}

	public String getCdTypeProcess() {
		return this.cdTypeProcess;
	}

	public void setCdTypeProcess(String cdTypeProcess) {
		this.cdTypeProcess = cdTypeProcess;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtDescription() {
		return this.txtDescription;
	}

	public void setTxtDescription(String txtDescription) {
		this.txtDescription = txtDescription;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<ProcessCountry> getProcessCountries() {
		return this.processCountries;
	}

	public void setProcessCountries(List<ProcessCountry> processCountries) {
		this.processCountries = processCountries;
	}

	public ProcessCountry addProcessCountry(ProcessCountry processCountry) {
		getProcessCountries().add(processCountry);
		processCountry.setTypeProcess(this);

		return processCountry;
	}

	public ProcessCountry removeProcessCountry(ProcessCountry processCountry) {
		getProcessCountries().remove(processCountry);
		processCountry.setTypeProcess(null);

		return processCountry;
	}

	public List<ProcessUnitBusiness> getProcessUnitBusinesses() {
		return this.processUnitBusinesses;
	}

	public void setProcessUnitBusinesses(List<ProcessUnitBusiness> processUnitBusinesses) {
		this.processUnitBusinesses = processUnitBusinesses;
	}

	public ProcessUnitBusiness addProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness) {
		getProcessUnitBusinesses().add(processUnitBusiness);
		processUnitBusiness.setTypeProcess(this);

		return processUnitBusiness;
	}

	public ProcessUnitBusiness removeProcessUnitBusiness(ProcessUnitBusiness processUnitBusiness) {
		getProcessUnitBusinesses().remove(processUnitBusiness);
		processUnitBusiness.setTypeProcess(null);

		return processUnitBusiness;
	}

}