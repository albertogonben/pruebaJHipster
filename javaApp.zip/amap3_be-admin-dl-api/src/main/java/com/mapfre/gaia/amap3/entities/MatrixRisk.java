package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the MATRIX_RISK database table.
 * 
 */
@Entity
@Table(name="MATRIX_RISK")
@NamedQuery(name="MatrixRisk.findAll", query="SELECT m FROM MatrixRisk m")
public class MatrixRisk implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="MATRIX_RISK_IDMATRIXRISKPK_GENERATOR", sequenceName="MATRIX_RISK_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="MATRIX_RISK_IDMATRIXRISKPK_GENERATOR")
	@Column(name="ID_MATRIX_RISK_PK")
	private long idMatrixRiskPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="NMR_EXERCIESE")
	private BigDecimal nmrExerciese;

	@Column(name="TXT_COMMENT")
	private String txtComment;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="TXT_STANDARD_NAME")
	private String txtStandardName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Country
	@ManyToOne
	@JoinColumn(name="ID_COUNTRY_FK")
	private Country country;

	//bi-directional many-to-one association to UnitBusiness
	@ManyToOne
	@JoinColumn(name="ID_UNIT_BUSINESS_FK")
	private UnitBusiness unitBusiness;

	//bi-directional many-to-one association to MatrixRiskValuation
	@OneToMany(mappedBy="matrixRisk")
	private List<MatrixRiskValuation> matrixRiskValuations;

	public MatrixRisk() {
	}

	public long getIdMatrixRiskPk() {
		return this.idMatrixRiskPk;
	}

	public void setIdMatrixRiskPk(long idMatrixRiskPk) {
		this.idMatrixRiskPk = idMatrixRiskPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getNmrExerciese() {
		return this.nmrExerciese;
	}

	public void setNmrExerciese(BigDecimal nmrExerciese) {
		this.nmrExerciese = nmrExerciese;
	}

	public String getTxtComment() {
		return this.txtComment;
	}

	public void setTxtComment(String txtComment) {
		this.txtComment = txtComment;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getTxtStandardName() {
		return this.txtStandardName;
	}

	public void setTxtStandardName(String txtStandardName) {
		this.txtStandardName = txtStandardName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Country getCountry() {
		return this.country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public UnitBusiness getUnitBusiness() {
		return this.unitBusiness;
	}

	public void setUnitBusiness(UnitBusiness unitBusiness) {
		this.unitBusiness = unitBusiness;
	}

	public List<MatrixRiskValuation> getMatrixRiskValuations() {
		return this.matrixRiskValuations;
	}

	public void setMatrixRiskValuations(List<MatrixRiskValuation> matrixRiskValuations) {
		this.matrixRiskValuations = matrixRiskValuations;
	}

	public MatrixRiskValuation addMatrixRiskValuation(MatrixRiskValuation matrixRiskValuation) {
		getMatrixRiskValuations().add(matrixRiskValuation);
		matrixRiskValuation.setMatrixRisk(this);

		return matrixRiskValuation;
	}

	public MatrixRiskValuation removeMatrixRiskValuation(MatrixRiskValuation matrixRiskValuation) {
		getMatrixRiskValuations().remove(matrixRiskValuation);
		matrixRiskValuation.setMatrixRisk(null);

		return matrixRiskValuation;
	}

}