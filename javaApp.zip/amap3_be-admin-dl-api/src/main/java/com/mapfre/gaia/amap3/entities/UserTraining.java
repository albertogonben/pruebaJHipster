package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the USER_TRAINING database table.
 * 
 */
@Entity
@Table(name="USER_TRAINING")
@NamedQuery(name="UserTraining.findAll", query="SELECT u FROM UserTraining u")
public class UserTraining implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="USER_TRAINING_IDTRAININGPK_GENERATOR", sequenceName="USER_TRAINING_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="USER_TRAINING_IDTRAININGPK_GENERATOR")
	@Column(name="ID_TRAINING_PK")
	private long idTrainingPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_FINISH")
	private Date dateFinish;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_START")
	private Date dateStart;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name="NMR_EXERCIESE")
	private Date nmrExerciese;

	@Column(name="TXT_CENTER")
	private String txtCenter;

	@Column(name="TXT_COMMENT")
	private String txtComment;

	@Column(name="TXT_TITLE")
	private String txtTitle;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to UserAmap
	@ManyToOne
	@JoinColumn(name="ID_USER_FK")
	private UserAmap userAmap;

	public UserTraining() {
	}

	public long getIdTrainingPk() {
		return this.idTrainingPk;
	}

	public void setIdTrainingPk(long idTrainingPk) {
		this.idTrainingPk = idTrainingPk;
	}

	public Date getDateFinish() {
		return this.dateFinish;
	}

	public void setDateFinish(Date dateFinish) {
		this.dateFinish = dateFinish;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateStart() {
		return this.dateStart;
	}

	public void setDateStart(Date dateStart) {
		this.dateStart = dateStart;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getNmrExerciese() {
		return this.nmrExerciese;
	}

	public void setNmrExerciese(Date nmrExerciese) {
		this.nmrExerciese = nmrExerciese;
	}

	public String getTxtCenter() {
		return this.txtCenter;
	}

	public void setTxtCenter(String txtCenter) {
		this.txtCenter = txtCenter;
	}

	public String getTxtComment() {
		return this.txtComment;
	}

	public void setTxtComment(String txtComment) {
		this.txtComment = txtComment;
	}

	public String getTxtTitle() {
		return this.txtTitle;
	}

	public void setTxtTitle(String txtTitle) {
		this.txtTitle = txtTitle;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public UserAmap getUserAmap() {
		return this.userAmap;
	}

	public void setUserAmap(UserAmap userAmap) {
		this.userAmap = userAmap;
	}

}