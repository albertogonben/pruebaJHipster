package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the PAI database table.
 * 
 */
@Entity
@NamedQuery(name="Pai.findAll", query="SELECT p FROM Pai p")
public class Pai implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PAI_IDPAIPK_GENERATOR", sequenceName="PAI_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PAI_IDPAIPK_GENERATOR")
	@Column(name="ID_PAI_PK")
	private long idPaiPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="NMR_EXERCIESE")
	private BigDecimal nmrExerciese;

	@Column(name="TXT_NM")
	private String txtNm;

	@Column(name="TXT_NM_STANDARD")
	private String txtNmStandard;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Budget
	@ManyToOne
	@JoinColumn(name="ID_BUDGET_FK")
	private Budget budget;

	//bi-directional many-to-one association to OrganizationalStructure
	@ManyToOne
	@JoinColumn(name="ID_ORGANIZATIONAL_STRUCTURE_FK")
	private OrganizationalStructure organizationalStructure;

	//bi-directional many-to-one association to PredictionPersonnel
	@ManyToOne
	@JoinColumn(name="ID_PERSONNEL_FK")
	private PredictionPersonnel predictionPersonnel;

	public Pai() {
	}

	public long getIdPaiPk() {
		return this.idPaiPk;
	}

	public void setIdPaiPk(long idPaiPk) {
		this.idPaiPk = idPaiPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getNmrExerciese() {
		return this.nmrExerciese;
	}

	public void setNmrExerciese(BigDecimal nmrExerciese) {
		this.nmrExerciese = nmrExerciese;
	}

	public String getTxtNm() {
		return this.txtNm;
	}

	public void setTxtNm(String txtNm) {
		this.txtNm = txtNm;
	}

	public String getTxtNmStandard() {
		return this.txtNmStandard;
	}

	public void setTxtNmStandard(String txtNmStandard) {
		this.txtNmStandard = txtNmStandard;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Budget getBudget() {
		return this.budget;
	}

	public void setBudget(Budget budget) {
		this.budget = budget;
	}

	public OrganizationalStructure getOrganizationalStructure() {
		return this.organizationalStructure;
	}

	public void setOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		this.organizationalStructure = organizationalStructure;
	}

	public PredictionPersonnel getPredictionPersonnel() {
		return this.predictionPersonnel;
	}

	public void setPredictionPersonnel(PredictionPersonnel predictionPersonnel) {
		this.predictionPersonnel = predictionPersonnel;
	}

}