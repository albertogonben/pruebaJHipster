package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the FACTOR_RISK database table.
 * 
 */
@Entity
@Table(name="FACTOR_RISK")
@NamedQuery(name="FactorRisk.findAll", query="SELECT f FROM FactorRisk f")
public class FactorRisk implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="FACTOR_RISK_IDFACTORRISKPK_GENERATOR", sequenceName="FACTOR_RISK_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="FACTOR_RISK_IDFACTORRISKPK_GENERATOR")
	@Column(name="ID_FACTOR_RISK_PK")
	private long idFactorRiskPk;

	@Column(name="CD_FACTOR")
	private String cdFactor;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_VERSION")
	private Date dateVersion;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="NMR_EXERCIESE")
	private BigDecimal nmrExerciese;

	@Column(name="NMR_SIZE")
	private BigDecimal nmrSize;

	@Column(name="NMR_VERSION")
	private BigDecimal nmrVersion;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="TXT_VALUES")
	private String txtValues;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to MatrixRiskValuation
	@OneToMany(mappedBy="factorRisk")
	private List<MatrixRiskValuation> matrixRiskValuations;

	public FactorRisk() {
	}

	public long getIdFactorRiskPk() {
		return this.idFactorRiskPk;
	}

	public void setIdFactorRiskPk(long idFactorRiskPk) {
		this.idFactorRiskPk = idFactorRiskPk;
	}

	public String getCdFactor() {
		return this.cdFactor;
	}

	public void setCdFactor(String cdFactor) {
		this.cdFactor = cdFactor;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public Date getDateVersion() {
		return this.dateVersion;
	}

	public void setDateVersion(Date dateVersion) {
		this.dateVersion = dateVersion;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public BigDecimal getNmrExerciese() {
		return this.nmrExerciese;
	}

	public void setNmrExerciese(BigDecimal nmrExerciese) {
		this.nmrExerciese = nmrExerciese;
	}

	public BigDecimal getNmrSize() {
		return this.nmrSize;
	}

	public void setNmrSize(BigDecimal nmrSize) {
		this.nmrSize = nmrSize;
	}

	public BigDecimal getNmrVersion() {
		return this.nmrVersion;
	}

	public void setNmrVersion(BigDecimal nmrVersion) {
		this.nmrVersion = nmrVersion;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getTxtValues() {
		return this.txtValues;
	}

	public void setTxtValues(String txtValues) {
		this.txtValues = txtValues;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<MatrixRiskValuation> getMatrixRiskValuations() {
		return this.matrixRiskValuations;
	}

	public void setMatrixRiskValuations(List<MatrixRiskValuation> matrixRiskValuations) {
		this.matrixRiskValuations = matrixRiskValuations;
	}

	public MatrixRiskValuation addMatrixRiskValuation(MatrixRiskValuation matrixRiskValuation) {
		getMatrixRiskValuations().add(matrixRiskValuation);
		matrixRiskValuation.setFactorRisk(this);

		return matrixRiskValuation;
	}

	public MatrixRiskValuation removeMatrixRiskValuation(MatrixRiskValuation matrixRiskValuation) {
		getMatrixRiskValuations().remove(matrixRiskValuation);
		matrixRiskValuation.setFactorRisk(null);

		return matrixRiskValuation;
	}

}