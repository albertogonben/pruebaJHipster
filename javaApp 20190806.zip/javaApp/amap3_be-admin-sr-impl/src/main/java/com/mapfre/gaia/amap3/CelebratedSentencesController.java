package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mapfre.gaia.amap3.exception.CustomException;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CelebratedSentencesController implements ICelebratedSentencesController{

	private ICelebratedSentencesBL celebritiesSentenceBL;
	
	@Autowired
	public CelebratedSentencesController(ICelebratedSentencesBL celebritiesSentenceBL) {
		this.celebritiesSentenceBL = celebritiesSentenceBL;
	}
	
	@Override
	public ResponseEntity<List<CelebratedSentenceBO>> getAll() throws CustomException {
		
		celebritiesSentenceBL.getAll();
		
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		
//		try {
//			return ResponseEntity.ok().body(celebritiesSentenceBL.getAll());
//		} catch (Exception e) {
//			log.error("CelebratedSentencesController:getAll", e);
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
//		}
	}

	@Override
	public ResponseEntity<CelebratedSentenceBO> post(@Valid @RequestBody CelebratedSentenceBO input) {
		
		try {
			CelebratedSentenceBO output = celebritiesSentenceBL.save(input);
			
			if(output != null) {
				return ResponseEntity.ok().body(output);
			}else {
				return ResponseEntity.status(HttpStatus.CONFLICT).build();
			}
			
		} catch (Exception e) {
			log.error("CelebratedSentencesController:post", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@Override
	public ResponseEntity<CelebratedSentenceBO> put(@PathVariable("id") Long id, @Valid @RequestBody CelebratedSentenceBO input) {
		
		try {
			CelebratedSentenceBO output = celebritiesSentenceBL.update(id, input);
			
			if(output != null) {
				return ResponseEntity.ok().body(output);
			}else {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
		
		} catch (Exception e) {
			log.error("CelebratedSentencesController:put", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
		
	}

	@Override
	public ResponseEntity<?> delete(@PathVariable("id") Long id) {
		
		throw new NullPointerException(); 
		
//		try {
//			if(celebritiesSentenceBL.delete(id)) {
//				return new ResponseEntity<>(HttpStatus.OK);
//			}else {
//				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
//			}
//		} catch (Exception e) {
//			log.error("CelebratedSentencesController:delete", e);
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
//		}
		
	}

}
