package com.mapfre.gaia.amap3;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class CurrencyController implements ICurrencyController {
    
    private ICurrencyBL currencyBL;
    
    @Autowired
    public CurrencyController(ICurrencyBL currencyBL) {
	this.currencyBL = currencyBL;
    }
    
    @Override
    public ResponseEntity<List<CurrencyBO>> get() {
	try {
	    return ResponseEntity.ok().body(currencyBL.getlAll());
	} catch(Exception e) {
	    log.error("CurrencyController:get", e);
	    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	}
    }

    @Override
    public ResponseEntity<CurrencyBO> add(@Valid @RequestBody CurrencyBO input) {
	try {
	    CurrencyBO output = currencyBL.save(input);
	    
	    if(output != null) {
		return ResponseEntity.ok().body(output);
	    } else {
		return ResponseEntity.status(HttpStatus.CONFLICT).build();
	    }
	} catch(Exception e) {
	   log.error("CurrencyController_post", e);
	   return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	}
    }

    @Override
    public ResponseEntity<CurrencyBO> update(@PathVariable("currencyId") Long currencyId, @Valid @RequestBody CurrencyBO input) {
	try {
	    CurrencyBO output = currencyBL.update(currencyId, input);
	    
	    if(output != null) {
		return ResponseEntity.ok().body(output);
	    } else {
		return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
	    }
	} catch(Exception e) {
	    log.error("CurrencyController:update", e);
	    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
	}
    }
    
}
