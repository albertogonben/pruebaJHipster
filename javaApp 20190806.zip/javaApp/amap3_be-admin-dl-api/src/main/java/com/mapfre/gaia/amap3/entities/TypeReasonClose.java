package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_REASON_CLOSE database table.
 * 
 */
@Entity
@Table(name="TYPE_REASON_CLOSE")
@NamedQuery(name="TypeReasonClose.findAll", query="SELECT t FROM TypeReasonClose t")
public class TypeReasonClose implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_REASON_CLOSE_IDREASONCLOSEPK_GENERATOR", sequenceName="TYPE_REASON_CLOSE_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_REASON_CLOSE_IDREASONCLOSEPK_GENERATOR")
	@Column(name="ID_REASON_CLOSE_PK")
	private long idReasonClosePk;

	@Column(name="CD_REASON")
	private String cdReason;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private String mrkActive;

	@Column(name="TXT_REASON")
	private String txtReason;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Job
	@OneToMany(mappedBy="typeReasonClose")
	private List<Job> jobs;

	public TypeReasonClose() {
	}

	public long getIdReasonClosePk() {
		return this.idReasonClosePk;
	}

	public void setIdReasonClosePk(long idReasonClosePk) {
		this.idReasonClosePk = idReasonClosePk;
	}

	public String getCdReason() {
		return this.cdReason;
	}

	public void setCdReason(String cdReason) {
		this.cdReason = cdReason;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(String mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtReason() {
		return this.txtReason;
	}

	public void setTxtReason(String txtReason) {
		this.txtReason = txtReason;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

	public Job addJob(Job job) {
		getJobs().add(job);
		job.setTypeReasonClose(this);

		return job;
	}

	public Job removeJob(Job job) {
		getJobs().remove(job);
		job.setTypeReasonClose(null);

		return job;
	}

}