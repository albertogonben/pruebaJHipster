package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the MODULE_APP database table.
 * 
 */
@Entity
@Table(name="MODULE_APP")
@NamedQuery(name="ModuleApp.findAll", query="SELECT m FROM ModuleApp m")
public class ModuleApp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="MODULE_APP_IDMODULEAPPPK_GENERATOR", sequenceName="MODULE_APP_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="MODULE_APP_IDMODULEAPPPK_GENERATOR")
	@Column(name="ID_MODULE_APP_PK")
	private long idModuleAppPk;

	@Column(name="CD_MODULE_APP")
	private String cdModuleApp;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_DESCRIPTION")
	private String txtDescription;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public ModuleApp() {
	}

	public long getIdModuleAppPk() {
		return this.idModuleAppPk;
	}

	public void setIdModuleAppPk(long idModuleAppPk) {
		this.idModuleAppPk = idModuleAppPk;
	}

	public String getCdModuleApp() {
		return this.cdModuleApp;
	}

	public void setCdModuleApp(String cdModuleApp) {
		this.cdModuleApp = cdModuleApp;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtDescription() {
		return this.txtDescription;
	}

	public void setTxtDescription(String txtDescription) {
		this.txtDescription = txtDescription;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}