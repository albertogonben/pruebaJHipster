package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the TYPE_PREDICTION_CHANGE database table.
 * 
 */
@Entity
@Table(name="TYPE_PREDICTION_CHANGE")
@NamedQuery(name="TypePredictionChange.findAll", query="SELECT t FROM TypePredictionChange t")
public class TypePredictionChange implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_PREDICTION_CHANGE_IDTYPEPREDICTIONCHANGEPK_GENERATOR", sequenceName="TYPE_PREDICTION_CHANGE_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_PREDICTION_CHANGE_IDTYPEPREDICTIONCHANGEPK_GENERATOR")
	@Column(name="ID_TYPE_PREDICTION_CHANGE_PK")
	private long idTypePredictionChangePk;

	@Column(name="CDGO_TYPE_PREDICTION")
	private String cdgoTypePrediction;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="ID_TYPE_CURRENCY_FK")
	private BigDecimal idTypeCurrencyFk;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="NMR_CHANGE")
	private BigDecimal nmrChange;

	@Column(name="NMR_EXERCIESE")
	private BigDecimal nmrExerciese;

	@Column(name="NMR_EXERCIESE_APPLY")
	private BigDecimal nmrExercieseApply;

	@Column(name="TXTO_TYPE_PREDICTION")
	private String txtoTypePrediction;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	public TypePredictionChange() {
	}

	public long getIdTypePredictionChangePk() {
		return this.idTypePredictionChangePk;
	}

	public void setIdTypePredictionChangePk(long idTypePredictionChangePk) {
		this.idTypePredictionChangePk = idTypePredictionChangePk;
	}

	public String getCdgoTypePrediction() {
		return this.cdgoTypePrediction;
	}

	public void setCdgoTypePrediction(String cdgoTypePrediction) {
		this.cdgoTypePrediction = cdgoTypePrediction;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getIdTypeCurrencyFk() {
		return this.idTypeCurrencyFk;
	}

	public void setIdTypeCurrencyFk(BigDecimal idTypeCurrencyFk) {
		this.idTypeCurrencyFk = idTypeCurrencyFk;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public BigDecimal getNmrChange() {
		return this.nmrChange;
	}

	public void setNmrChange(BigDecimal nmrChange) {
		this.nmrChange = nmrChange;
	}

	public BigDecimal getNmrExerciese() {
		return this.nmrExerciese;
	}

	public void setNmrExerciese(BigDecimal nmrExerciese) {
		this.nmrExerciese = nmrExerciese;
	}

	public BigDecimal getNmrExercieseApply() {
		return this.nmrExercieseApply;
	}

	public void setNmrExercieseApply(BigDecimal nmrExercieseApply) {
		this.nmrExercieseApply = nmrExercieseApply;
	}

	public String getTxtoTypePrediction() {
		return this.txtoTypePrediction;
	}

	public void setTxtoTypePrediction(String txtoTypePrediction) {
		this.txtoTypePrediction = txtoTypePrediction;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

}