package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the JOB database table.
 * 
 */
@Entity
@NamedQuery(name="Job.findAll", query="SELECT j FROM Job j")
public class Job implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="JOB_IDJOBPK_GENERATOR", sequenceName="JOB_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="JOB_IDJOBPK_GENERATOR")
	@Column(name="ID_JOB_PK")
	private long idJobPk;

	@Column(name="CD_JOB")
	private String cdJob;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_EXPECT_FINISH")
	private Date dateExpectFinish;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_EXPECT_START")
	private Date dateExpectStart;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_FINISH")
	private Date dateFinish;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_START")
	private Date dateStart;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="IS_PLANNED_JOB")
	private BigDecimal isPlannedJob;

	@Column(name="TXT_EFFECT")
	private String txtEffect;

	@Column(name="TXT_NM")
	private String txtNm;

	@Column(name="TXT_NM_STANDAR")
	private String txtNmStandar;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Job
	@ManyToOne
	@JoinColumn(name="ID_JOB_EFFECT_70_FK")
	private Job job;

	//bi-directional many-to-one association to Job
	@OneToMany(mappedBy="job")
	private List<Job> jobs;

	//bi-directional many-to-one association to ProgramJob
	@ManyToOne
	@JoinColumn(name="ID_PROGRAM_JOB_FK")
	private ProgramJob programJob;

	//bi-directional many-to-one association to TypeJob
	@ManyToOne
	@JoinColumn(name="ID_JOB_TYPE_FK")
	private TypeJob typeJob;

	//bi-directional many-to-one association to TypeReasonClose
	@ManyToOne
	@JoinColumn(name="ID_REASON_CLOSE")
	private TypeReasonClose typeReasonClose;

	//bi-directional many-to-one association to TypeStateJob
	@ManyToOne
	@JoinColumn(name="ID_JOB_STATE_FK")
	private TypeStateJob typeStateJob;

	//bi-directional many-to-one association to JobDocument
	@OneToMany(mappedBy="job")
	private List<JobDocument> jobDocuments;

	//bi-directional many-to-one association to JobIdea
	@OneToMany(mappedBy="job")
	private List<JobIdea> jobIdeas;

	//bi-directional many-to-one association to JobLog
	@OneToMany(mappedBy="job")
	private List<JobLog> jobLogs;

	//bi-directional many-to-one association to JobOrigin
	@OneToMany(mappedBy="job")
	private List<JobOrigin> jobOrigins;

	//bi-directional many-to-one association to JobTag
	@OneToMany(mappedBy="job")
	private List<JobTag> jobTags;

	//bi-directional many-to-one association to ProgramJob
	@OneToMany(mappedBy="job")
	private List<ProgramJob> programJobs;

	public Job() {
	}

	public long getIdJobPk() {
		return this.idJobPk;
	}

	public void setIdJobPk(long idJobPk) {
		this.idJobPk = idJobPk;
	}

	public String getCdJob() {
		return this.cdJob;
	}

	public void setCdJob(String cdJob) {
		this.cdJob = cdJob;
	}

	public Date getDateExpectFinish() {
		return this.dateExpectFinish;
	}

	public void setDateExpectFinish(Date dateExpectFinish) {
		this.dateExpectFinish = dateExpectFinish;
	}

	public Date getDateExpectStart() {
		return this.dateExpectStart;
	}

	public void setDateExpectStart(Date dateExpectStart) {
		this.dateExpectStart = dateExpectStart;
	}

	public Date getDateFinish() {
		return this.dateFinish;
	}

	public void setDateFinish(Date dateFinish) {
		this.dateFinish = dateFinish;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateStart() {
		return this.dateStart;
	}

	public void setDateStart(Date dateStart) {
		this.dateStart = dateStart;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getIsPlannedJob() {
		return this.isPlannedJob;
	}

	public void setIsPlannedJob(BigDecimal isPlannedJob) {
		this.isPlannedJob = isPlannedJob;
	}

	public String getTxtEffect() {
		return this.txtEffect;
	}

	public void setTxtEffect(String txtEffect) {
		this.txtEffect = txtEffect;
	}

	public String getTxtNm() {
		return this.txtNm;
	}

	public void setTxtNm(String txtNm) {
		this.txtNm = txtNm;
	}

	public String getTxtNmStandar() {
		return this.txtNmStandar;
	}

	public void setTxtNmStandar(String txtNmStandar) {
		this.txtNmStandar = txtNmStandar;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Job getJob() {
		return this.job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public List<Job> getJobs() {
		return this.jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

	public Job addJob(Job job) {
		getJobs().add(job);
		job.setJob(this);

		return job;
	}

	public Job removeJob(Job job) {
		getJobs().remove(job);
		job.setJob(null);

		return job;
	}

	public ProgramJob getProgramJob() {
		return this.programJob;
	}

	public void setProgramJob(ProgramJob programJob) {
		this.programJob = programJob;
	}

	public TypeJob getTypeJob() {
		return this.typeJob;
	}

	public void setTypeJob(TypeJob typeJob) {
		this.typeJob = typeJob;
	}

	public TypeReasonClose getTypeReasonClose() {
		return this.typeReasonClose;
	}

	public void setTypeReasonClose(TypeReasonClose typeReasonClose) {
		this.typeReasonClose = typeReasonClose;
	}

	public TypeStateJob getTypeStateJob() {
		return this.typeStateJob;
	}

	public void setTypeStateJob(TypeStateJob typeStateJob) {
		this.typeStateJob = typeStateJob;
	}

	public List<JobDocument> getJobDocuments() {
		return this.jobDocuments;
	}

	public void setJobDocuments(List<JobDocument> jobDocuments) {
		this.jobDocuments = jobDocuments;
	}

	public JobDocument addJobDocument(JobDocument jobDocument) {
		getJobDocuments().add(jobDocument);
		jobDocument.setJob(this);

		return jobDocument;
	}

	public JobDocument removeJobDocument(JobDocument jobDocument) {
		getJobDocuments().remove(jobDocument);
		jobDocument.setJob(null);

		return jobDocument;
	}

	public List<JobIdea> getJobIdeas() {
		return this.jobIdeas;
	}

	public void setJobIdeas(List<JobIdea> jobIdeas) {
		this.jobIdeas = jobIdeas;
	}

	public JobIdea addJobIdea(JobIdea jobIdea) {
		getJobIdeas().add(jobIdea);
		jobIdea.setJob(this);

		return jobIdea;
	}

	public JobIdea removeJobIdea(JobIdea jobIdea) {
		getJobIdeas().remove(jobIdea);
		jobIdea.setJob(null);

		return jobIdea;
	}

	public List<JobLog> getJobLogs() {
		return this.jobLogs;
	}

	public void setJobLogs(List<JobLog> jobLogs) {
		this.jobLogs = jobLogs;
	}

	public JobLog addJobLog(JobLog jobLog) {
		getJobLogs().add(jobLog);
		jobLog.setJob(this);

		return jobLog;
	}

	public JobLog removeJobLog(JobLog jobLog) {
		getJobLogs().remove(jobLog);
		jobLog.setJob(null);

		return jobLog;
	}

	public List<JobOrigin> getJobOrigins() {
		return this.jobOrigins;
	}

	public void setJobOrigins(List<JobOrigin> jobOrigins) {
		this.jobOrigins = jobOrigins;
	}

	public JobOrigin addJobOrigin(JobOrigin jobOrigin) {
		getJobOrigins().add(jobOrigin);
		jobOrigin.setJob(this);

		return jobOrigin;
	}

	public JobOrigin removeJobOrigin(JobOrigin jobOrigin) {
		getJobOrigins().remove(jobOrigin);
		jobOrigin.setJob(null);

		return jobOrigin;
	}

	public List<JobTag> getJobTags() {
		return this.jobTags;
	}

	public void setJobTags(List<JobTag> jobTags) {
		this.jobTags = jobTags;
	}

	public JobTag addJobTag(JobTag jobTag) {
		getJobTags().add(jobTag);
		jobTag.setJob(this);

		return jobTag;
	}

	public JobTag removeJobTag(JobTag jobTag) {
		getJobTags().remove(jobTag);
		jobTag.setJob(null);

		return jobTag;
	}

	public List<ProgramJob> getProgramJobs() {
		return this.programJobs;
	}

	public void setProgramJobs(List<ProgramJob> programJobs) {
		this.programJobs = programJobs;
	}

	public ProgramJob addProgramJob(ProgramJob programJob) {
		getProgramJobs().add(programJob);
		programJob.setJob(this);

		return programJob;
	}

	public ProgramJob removeProgramJob(ProgramJob programJob) {
		getProgramJobs().remove(programJob);
		programJob.setJob(null);

		return programJob;
	}

}