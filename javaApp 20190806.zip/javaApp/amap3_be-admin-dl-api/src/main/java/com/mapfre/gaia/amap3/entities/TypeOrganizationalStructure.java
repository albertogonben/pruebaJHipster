package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_ORGANIZATIONAL_STRUCTURE database table.
 * 
 */
@Entity
@Table(name="TYPE_ORGANIZATIONAL_STRUCTURE")
@NamedQuery(name="TypeOrganizationalStructure.findAll", query="SELECT t FROM TypeOrganizationalStructure t")
public class TypeOrganizationalStructure implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_ORGANIZATIONAL_STRUCTURE_IDTYPEPK_GENERATOR", sequenceName="TYPE_ORGANIZATIONAL_STRUCTURE_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_ORGANIZATIONAL_STRUCTURE_IDTYPEPK_GENERATOR")
	@Column(name="ID_TYPE_PK")
	private long idTypePk;

	@Column(name="CD_TYPE")
	private String cdType;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_AUDITABLE")
	private String mrkAuditable;

	@Column(name="TXT_TYPE")
	private String txtType;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Entamap
	@OneToMany(mappedBy="typeOrganizationalStructure")
	private List<Entamap> entamaps;

	//bi-directional many-to-one association to OrganizationalStructure
	@OneToMany(mappedBy="typeOrganizationalStructure")
	private List<OrganizationalStructure> organizationalStructures;

	public TypeOrganizationalStructure() {
	}

	public long getIdTypePk() {
		return this.idTypePk;
	}

	public void setIdTypePk(long idTypePk) {
		this.idTypePk = idTypePk;
	}

	public String getCdType() {
		return this.cdType;
	}

	public void setCdType(String cdType) {
		this.cdType = cdType;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getMrkAuditable() {
		return this.mrkAuditable;
	}

	public void setMrkAuditable(String mrkAuditable) {
		this.mrkAuditable = mrkAuditable;
	}

	public String getTxtType() {
		return this.txtType;
	}

	public void setTxtType(String txtType) {
		this.txtType = txtType;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<Entamap> getEntamaps() {
		return this.entamaps;
	}

	public void setEntamaps(List<Entamap> entamaps) {
		this.entamaps = entamaps;
	}

	public Entamap addEntamap(Entamap entamap) {
		getEntamaps().add(entamap);
		entamap.setTypeOrganizationalStructure(this);

		return entamap;
	}

	public Entamap removeEntamap(Entamap entamap) {
		getEntamaps().remove(entamap);
		entamap.setTypeOrganizationalStructure(null);

		return entamap;
	}

	public List<OrganizationalStructure> getOrganizationalStructures() {
		return this.organizationalStructures;
	}

	public void setOrganizationalStructures(List<OrganizationalStructure> organizationalStructures) {
		this.organizationalStructures = organizationalStructures;
	}

	public OrganizationalStructure addOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		getOrganizationalStructures().add(organizationalStructure);
		organizationalStructure.setTypeOrganizationalStructure(this);

		return organizationalStructure;
	}

	public OrganizationalStructure removeOrganizationalStructure(OrganizationalStructure organizationalStructure) {
		getOrganizationalStructures().remove(organizationalStructure);
		organizationalStructure.setTypeOrganizationalStructure(null);

		return organizationalStructure;
	}

}