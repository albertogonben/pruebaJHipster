package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the MATRIX_RISK_VALUATION database table.
 * 
 */
@Entity
@Table(name="MATRIX_RISK_VALUATION")
@NamedQuery(name="MatrixRiskValuation.findAll", query="SELECT m FROM MatrixRiskValuation m")
public class MatrixRiskValuation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="MATRIX_RISK_VALUATION_IDVALUATIONPK_GENERATOR", sequenceName="MATRIX_RISK_VALUATION_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="MATRIX_RISK_VALUATION_IDVALUATIONPK_GENERATOR")
	@Column(name="ID_VALUATION_PK")
	private long idValuationPk;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="NMR_SIZE")
	private BigDecimal nmrSize;

	@Column(name="NMR_VALUATION")
	private BigDecimal nmrValuation;

	@Column(name="TXT_COMMENT")
	private String txtComment;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to FactorRisk
	@ManyToOne
	@JoinColumn(name="ID_FACTOR_FK")
	private FactorRisk factorRisk;

	//bi-directional many-to-one association to MatrixRisk
	@ManyToOne
	@JoinColumn(name="ID_MATRIX_RISK_FK")
	private MatrixRisk matrixRisk;

	//bi-directional many-to-one association to ProcessCountry
	@ManyToOne
	@JoinColumn(name="ID_PROCESS_FK")
	private ProcessCountry processCountry;

	public MatrixRiskValuation() {
	}

	public long getIdValuationPk() {
		return this.idValuationPk;
	}

	public void setIdValuationPk(long idValuationPk) {
		this.idValuationPk = idValuationPk;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getNmrSize() {
		return this.nmrSize;
	}

	public void setNmrSize(BigDecimal nmrSize) {
		this.nmrSize = nmrSize;
	}

	public BigDecimal getNmrValuation() {
		return this.nmrValuation;
	}

	public void setNmrValuation(BigDecimal nmrValuation) {
		this.nmrValuation = nmrValuation;
	}

	public String getTxtComment() {
		return this.txtComment;
	}

	public void setTxtComment(String txtComment) {
		this.txtComment = txtComment;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public FactorRisk getFactorRisk() {
		return this.factorRisk;
	}

	public void setFactorRisk(FactorRisk factorRisk) {
		this.factorRisk = factorRisk;
	}

	public MatrixRisk getMatrixRisk() {
		return this.matrixRisk;
	}

	public void setMatrixRisk(MatrixRisk matrixRisk) {
		this.matrixRisk = matrixRisk;
	}

	public ProcessCountry getProcessCountry() {
		return this.processCountry;
	}

	public void setProcessCountry(ProcessCountry processCountry) {
		this.processCountry = processCountry;
	}

}