package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the ENTAMAP database table.
 * 
 */
@Entity
@NamedQuery(name="Entamap.findAll", query="SELECT e FROM Entamap e")
public class Entamap implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ENTAMAP_IDENTITYPK_GENERATOR", sequenceName="ENTAMAP_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ENTAMAP_IDENTITYPK_GENERATOR")
	@Column(name="ID_ENTITY_PK")
	private long idEntityPk;

	@Column(name="CD_ENTITY")
	private String cdEntity;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private String mrkActive;

	@Column(name="TXT_DESCRIPTION")
	private String txtDescription;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to Country
	@ManyToOne
	@JoinColumn(name="ID_COUNTRY_FK")
	private Country country;

	//bi-directional many-to-one association to Currency
	@ManyToOne
	@JoinColumn(name="ID_CURRENCY_FK")
	private Currency currency;

	//bi-directional many-to-one association to Entamap
	@ManyToOne
	@JoinColumn(name="ID_ENTITY_FK")
	private Entamap entamap;

	//bi-directional many-to-one association to Entamap
	@OneToMany(mappedBy="entamap")
	private List<Entamap> entamaps;

	//bi-directional many-to-one association to TypeOrganizationalStructure
	@ManyToOne
	@JoinColumn(name="ID_TYPE_ORGANIZATIONAL_STRUCTURE_FK")
	private TypeOrganizationalStructure typeOrganizationalStructure;

	//bi-directional many-to-one association to UserAmap
	@OneToMany(mappedBy="entamap")
	private List<UserAmap> userAmaps;

	public Entamap() {
	}

	public long getIdEntityPk() {
		return this.idEntityPk;
	}

	public void setIdEntityPk(long idEntityPk) {
		this.idEntityPk = idEntityPk;
	}

	public String getCdEntity() {
		return this.cdEntity;
	}

	public void setCdEntity(String cdEntity) {
		this.cdEntity = cdEntity;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(String mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtDescription() {
		return this.txtDescription;
	}

	public void setTxtDescription(String txtDescription) {
		this.txtDescription = txtDescription;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public Country getCountry() {
		return this.country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Currency getCurrency() {
		return this.currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public Entamap getEntamap() {
		return this.entamap;
	}

	public void setEntamap(Entamap entamap) {
		this.entamap = entamap;
	}

	public List<Entamap> getEntamaps() {
		return this.entamaps;
	}

	public void setEntamaps(List<Entamap> entamaps) {
		this.entamaps = entamaps;
	}

	public Entamap addEntamap(Entamap entamap) {
		getEntamaps().add(entamap);
		entamap.setEntamap(this);

		return entamap;
	}

	public Entamap removeEntamap(Entamap entamap) {
		getEntamaps().remove(entamap);
		entamap.setEntamap(null);

		return entamap;
	}

	public TypeOrganizationalStructure getTypeOrganizationalStructure() {
		return this.typeOrganizationalStructure;
	}

	public void setTypeOrganizationalStructure(TypeOrganizationalStructure typeOrganizationalStructure) {
		this.typeOrganizationalStructure = typeOrganizationalStructure;
	}

	public List<UserAmap> getUserAmaps() {
		return this.userAmaps;
	}

	public void setUserAmaps(List<UserAmap> userAmaps) {
		this.userAmaps = userAmaps;
	}

	public UserAmap addUserAmap(UserAmap userAmap) {
		getUserAmaps().add(userAmap);
		userAmap.setEntamap(this);

		return userAmap;
	}

	public UserAmap removeUserAmap(UserAmap userAmap) {
		getUserAmaps().remove(userAmap);
		userAmap.setEntamap(null);

		return userAmap;
	}

}