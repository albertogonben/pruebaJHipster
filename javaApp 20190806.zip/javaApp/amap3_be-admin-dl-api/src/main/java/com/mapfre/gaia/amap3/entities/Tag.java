package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TAG database table.
 * 
 */
@Entity
@NamedQuery(name="Tag.findAll", query="SELECT t FROM Tag t")
public class Tag implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TAG_IDTAGPK_GENERATOR", sequenceName="TAG_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TAG_IDTAGPK_GENERATOR")
	@Column(name="ID_TAG_PK")
	private long idTagPk;

	@Column(name="CD_TAG")
	private String cdTag;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_LAST_USE")
	private Date dateLastUse;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="IS_GLOBAL_TAG")
	private BigDecimal isGlobalTag;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="NMR_USES")
	private BigDecimal nmrUses;

	@Column(name="TXT_DESCRIPTION")
	private String txtDescription;

	@Column(name="TXT_NAME")
	private String txtName;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to JobTag
	@OneToMany(mappedBy="tag")
	private List<JobTag> jobTags;

	public Tag() {
	}

	public long getIdTagPk() {
		return this.idTagPk;
	}

	public void setIdTagPk(long idTagPk) {
		this.idTagPk = idTagPk;
	}

	public String getCdTag() {
		return this.cdTag;
	}

	public void setCdTag(String cdTag) {
		this.cdTag = cdTag;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateLastUse() {
		return this.dateLastUse;
	}

	public void setDateLastUse(Date dateLastUse) {
		this.dateLastUse = dateLastUse;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getIsGlobalTag() {
		return this.isGlobalTag;
	}

	public void setIsGlobalTag(BigDecimal isGlobalTag) {
		this.isGlobalTag = isGlobalTag;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public BigDecimal getNmrUses() {
		return this.nmrUses;
	}

	public void setNmrUses(BigDecimal nmrUses) {
		this.nmrUses = nmrUses;
	}

	public String getTxtDescription() {
		return this.txtDescription;
	}

	public void setTxtDescription(String txtDescription) {
		this.txtDescription = txtDescription;
	}

	public String getTxtName() {
		return this.txtName;
	}

	public void setTxtName(String txtName) {
		this.txtName = txtName;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<JobTag> getJobTags() {
		return this.jobTags;
	}

	public void setJobTags(List<JobTag> jobTags) {
		this.jobTags = jobTags;
	}

	public JobTag addJobTag(JobTag jobTag) {
		getJobTags().add(jobTag);
		jobTag.setTag(this);

		return jobTag;
	}

	public JobTag removeJobTag(JobTag jobTag) {
		getJobTags().remove(jobTag);
		jobTag.setTag(null);

		return jobTag;
	}

}