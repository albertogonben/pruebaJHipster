package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_CRIQUITE_ALARM database table.
 * 
 */
@Entity
@Table(name="TYPE_CRIQUITE_ALARM")
@NamedQuery(name="TypeCriquiteAlarm.findAll", query="SELECT t FROM TypeCriquiteAlarm t")
public class TypeCriquiteAlarm implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_CRIQUITE_ALARM_IDTYPECRITIQUEALARMPK_GENERATOR", sequenceName="TYPE_CRIQUITE_ALARM_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_CRIQUITE_ALARM_IDTYPECRITIQUEALARMPK_GENERATOR")
	@Column(name="ID_TYPE_CRITIQUE_ALARM_PK")
	private long idTypeCritiqueAlarmPk;

	@Column(name="CD_TYPE_CRITIQUE_ALARM")
	private String cdTypeCritiqueAlarm;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="MRK_ACTIVE")
	private BigDecimal mrkActive;

	@Column(name="TXT_TYPE_CRITIQUE_ALARM")
	private String txtTypeCritiqueAlarm;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to UserAlarm
	@OneToMany(mappedBy="typeCriquiteAlarm")
	private List<UserAlarm> userAlarms;

	public TypeCriquiteAlarm() {
	}

	public long getIdTypeCritiqueAlarmPk() {
		return this.idTypeCritiqueAlarmPk;
	}

	public void setIdTypeCritiqueAlarmPk(long idTypeCritiqueAlarmPk) {
		this.idTypeCritiqueAlarmPk = idTypeCritiqueAlarmPk;
	}

	public String getCdTypeCritiqueAlarm() {
		return this.cdTypeCritiqueAlarm;
	}

	public void setCdTypeCritiqueAlarm(String cdTypeCritiqueAlarm) {
		this.cdTypeCritiqueAlarm = cdTypeCritiqueAlarm;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public BigDecimal getMrkActive() {
		return this.mrkActive;
	}

	public void setMrkActive(BigDecimal mrkActive) {
		this.mrkActive = mrkActive;
	}

	public String getTxtTypeCritiqueAlarm() {
		return this.txtTypeCritiqueAlarm;
	}

	public void setTxtTypeCritiqueAlarm(String txtTypeCritiqueAlarm) {
		this.txtTypeCritiqueAlarm = txtTypeCritiqueAlarm;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<UserAlarm> getUserAlarms() {
		return this.userAlarms;
	}

	public void setUserAlarms(List<UserAlarm> userAlarms) {
		this.userAlarms = userAlarms;
	}

	public UserAlarm addUserAlarm(UserAlarm userAlarm) {
		getUserAlarms().add(userAlarm);
		userAlarm.setTypeCriquiteAlarm(this);

		return userAlarm;
	}

	public UserAlarm removeUserAlarm(UserAlarm userAlarm) {
		getUserAlarms().remove(userAlarm);
		userAlarm.setTypeCriquiteAlarm(null);

		return userAlarm;
	}

}