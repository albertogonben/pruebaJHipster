package com.mapfre.gaia.amap3.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the TYPE_LEVEL_LANGUAGE database table.
 * 
 */
@Entity
@Table(name="TYPE_LEVEL_LANGUAGE")
@NamedQuery(name="TypeLevelLanguage.findAll", query="SELECT t FROM TypeLevelLanguage t")
public class TypeLevelLanguage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TYPE_LEVEL_LANGUAGE_IDTYPELEVELPK_GENERATOR", sequenceName="TYPE_LEVEL_LANGUAGE_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TYPE_LEVEL_LANGUAGE_IDTYPELEVELPK_GENERATOR")
	@Column(name="ID_TYPE_LEVEL_PK")
	private long idTypeLevelPk;

	@Column(name="CD_TYPE_LEVEL_LANGUAGE")
	private String cdTypeLevelLanguage;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_INSERT")
	private Date dateInsert;

	@Temporal(TemporalType.DATE)
	@Column(name="DATE_UPDATE")
	private Date dateUpdate;

	@Column(name="TXT_TYPE_LEVEL_LANGUAGE")
	private String txtTypeLevelLanguage;

	@Column(name="USER_INSERT")
	private String userInsert;

	@Column(name="USER_UPDATE")
	private String userUpdate;

	//bi-directional many-to-one association to UserLanguage
	@OneToMany(mappedBy="typeLevelLanguage")
	private List<UserLanguage> userLanguages;

	public TypeLevelLanguage() {
	}

	public long getIdTypeLevelPk() {
		return this.idTypeLevelPk;
	}

	public void setIdTypeLevelPk(long idTypeLevelPk) {
		this.idTypeLevelPk = idTypeLevelPk;
	}

	public String getCdTypeLevelLanguage() {
		return this.cdTypeLevelLanguage;
	}

	public void setCdTypeLevelLanguage(String cdTypeLevelLanguage) {
		this.cdTypeLevelLanguage = cdTypeLevelLanguage;
	}

	public Date getDateInsert() {
		return this.dateInsert;
	}

	public void setDateInsert(Date dateInsert) {
		this.dateInsert = dateInsert;
	}

	public Date getDateUpdate() {
		return this.dateUpdate;
	}

	public void setDateUpdate(Date dateUpdate) {
		this.dateUpdate = dateUpdate;
	}

	public String getTxtTypeLevelLanguage() {
		return this.txtTypeLevelLanguage;
	}

	public void setTxtTypeLevelLanguage(String txtTypeLevelLanguage) {
		this.txtTypeLevelLanguage = txtTypeLevelLanguage;
	}

	public String getUserInsert() {
		return this.userInsert;
	}

	public void setUserInsert(String userInsert) {
		this.userInsert = userInsert;
	}

	public String getUserUpdate() {
		return this.userUpdate;
	}

	public void setUserUpdate(String userUpdate) {
		this.userUpdate = userUpdate;
	}

	public List<UserLanguage> getUserLanguages() {
		return this.userLanguages;
	}

	public void setUserLanguages(List<UserLanguage> userLanguages) {
		this.userLanguages = userLanguages;
	}

	public UserLanguage addUserLanguage(UserLanguage userLanguage) {
		getUserLanguages().add(userLanguage);
		userLanguage.setTypeLevelLanguage(this);

		return userLanguage;
	}

	public UserLanguage removeUserLanguage(UserLanguage userLanguage) {
		getUserLanguages().remove(userLanguage);
		userLanguage.setTypeLevelLanguage(null);

		return userLanguage;
	}

}