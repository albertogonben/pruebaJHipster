package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface IOrganizationalStructureBL {

	/**
	 * Get all oganizational structures
	 */
	List<OrganizationalStructureBO> getAll();
	
	/**
	 * Add an oganizational structure
	 */
	OrganizationalStructureBO add(OrganizationalStructureBO organizationalStructureBo);

	/**
	 * Update an oganizational structure
	 */
	OrganizationalStructureBO update(Long organizationalStructureId, OrganizationalStructureBO organizationalStructureBo);

    /**
     * Delete an oganizational structure
     */
    boolean delete(Long organizationalStructureId);

}
