package com.mapfre.gaia.amap3;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface ICountryBL {

	/**
	 * Get all countries
	 */
	List<CountryBO> getAll();

	/**
	 * Add a country
	 */
	CountryBO add(CountryBO countryBO);

	/**
	 * Update a country
	 */
	CountryBO update(Long countryId, CountryBO countryBO);

	/**
	 * Delete a country
	 */
	boolean delete(Long countryId);
	
	/**
	 * Get a country
	 */
	CountryBO findCountry(Long countryId);
	
	/**
	 * Get a region for a country
	 */
	CountryRegionBO findRegionCountry(Long countryId, Long regionId);

}
