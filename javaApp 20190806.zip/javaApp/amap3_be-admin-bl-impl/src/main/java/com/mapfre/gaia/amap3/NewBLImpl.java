package com.mapfre.gaia.amap3;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mapfre.gaia.amap3.entities.New;
import com.mapfre.gaia.amap3.repositories.NewRepository;

import lombok.extern.slf4j.Slf4j;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Slf4j
@Service
@Transactional
public class NewBLImpl implements INewBL {

	private NewRepository newRepository;
	private MapperFacade mapperNew;

	@Autowired
	public NewBLImpl(NewRepository newRepository) {
		this.newRepository = newRepository;
		
		MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
		mapperFactory.classMap(New.class, NewBO.class).byDefault().register();
		mapperNew = mapperFactory.getMapperFacade();
	}

	@Override
	public List<NewBO> getAll() {
		log.debug("NewBLImpl:getAll [START]");
		List<NewBO> news = new ArrayList<NewBO>();

		List<New> newEntities = newRepository.findAll();
		for (New newEntity : newEntities) {
			news.add(mapperNew.map(newEntity, NewBO.class));
		}
		log.debug("NewBLImpl:getAll [END]");
		return news;
	}

	@Override
	public NewBO add(NewBO newBo) {
		log.debug("NewBLImpl:add [START]");
		New newEntity = mapperNew.map(newBo, New.class);
		log.debug("NewBLImpl:add [END]");
		return mapperNew.map(newRepository.save(newEntity), NewBO.class);
	}

	@Override
	public NewBO update(Long newId, NewBO newBo) {
		log.debug("NewBLImpl:update [START]");
		New newEntity = newRepository.getOne(newId);
		if (newEntity != null) {
			newEntity.setTxtNews(newBo.getTxtNews());
			//TODO Alberto Setear valores necesarios del front
			log.debug("NewBLImpl:update [END]");
			return mapperNew.map(newRepository.save(newEntity), NewBO.class);
		}
		return null;
	}

	@Override
	public boolean delete(Long newId) {
		log.debug("NewBLImpl:delete [START]");
		New newEntity = newRepository.findOne(newId);
		if (newEntity != null) {
			newRepository.delete(newId);
			log.debug("NewBLImpl:delete [END]");
			return true;
		}
		return false;
	}

}
