package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.Data;

/**
 * The business object class for the "LANGUAGE" database table.
 * 
 */
@Data
public class LanguageBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idLanguagePk;

	private String cdLanguage;

	private Date dateInsert;

	private Date dateUpdate;

	private BigDecimal mrkActive;

	private BigDecimal mrkPossibleTranslation;

	private String txtName;

	private String userInsert;

	private String userUpdate;

	public LanguageBO() {
	}

}