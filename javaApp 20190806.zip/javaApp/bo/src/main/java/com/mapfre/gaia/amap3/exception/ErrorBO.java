package com.mapfre.gaia.amap3.exception;

import java.util.List;

import lombok.Data;

@Data
public class ErrorBO {
	
	private String code;
	private String message;
	private String component;
	private String rootCause;
	private List<InfoErrorBO> info;

}
