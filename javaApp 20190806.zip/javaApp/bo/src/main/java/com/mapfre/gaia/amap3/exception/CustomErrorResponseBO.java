package com.mapfre.gaia.amap3.exception;

import java.util.List;

import lombok.Data;

@Data
public class CustomErrorResponseBO {

	private String code;
	
	private String message;
	
	private String type;
	
	private String context;
	
	private String exception;
	
	private String application;
	
	private String component;
	
	private String timestamp;
	
	private List<ErrorBO> errors;
	
	private StackTraceBO stackTrace;

}

