package com.mapfre.gaia.amap3;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The business object class for the NEWS database table.
 * 
 */
@Data
@AllArgsConstructor
public class NewBO implements Serializable {
	private static final long serialVersionUID = 1L;

	private long idNewsPk;

	private String cdNews;

	private Date dateInsert;

	private Date datePublication;

	private Date dateUpdate;

	private byte[] fileDocument;

	private BigDecimal isPrincipal;

	private String txtName;

	private String txtNews;

	private String txtUrl;

	private String typeDocument;

	private String userInsert;

	private String userUpdate;

	public NewBO() {
	}

}