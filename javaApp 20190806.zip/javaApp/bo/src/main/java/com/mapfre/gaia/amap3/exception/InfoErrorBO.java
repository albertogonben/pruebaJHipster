package com.mapfre.gaia.amap3.exception;


import lombok.Data;

@Data
public class InfoErrorBO {
	
	private Integer key;
	private String value;

}
