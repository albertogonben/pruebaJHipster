package com.mapfre.gaia.amap3;

import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;

@RestController
@Api(value = "API Users AuditMap")
public interface IUserAMapController {

	
	

}
