package com.mapfre.gaia.amap3.exception;

public class CustomException extends Exception{
	
	private static final long serialVersionUID = 1L;
	
	private int status;
	
	public CustomException(int status, String message) {
		super(message);
		this.status = status;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

}
